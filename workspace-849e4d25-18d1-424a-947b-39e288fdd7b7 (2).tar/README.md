# AI Pathfinders 2025

Plataforma educativa completa de inteligencia artificial construida con Next.js 15, TypeScript y Tailwind CSS.

## Características

- 🎯 **8 Módulos Especializados**: Desde fundamentos de IA hasta modelos generativos avanzados
- 📊 **Tendencias en Tiempo Real**: Integración con arXiv para mostrar las últimas investigaciones
- 🎨 **UI/UX Moderna**: Diseño responsivo con tema oscuro y componentes interactivos
- 📱 **Totalmente Responsivo**: Optimizado para móvil y escritorio
- 🔐 **Sistema de Autenticación**: Login y registro con manejo de progreso
- 📈 **Seguimiento de Progreso**: Guarda local del avance de cada usuario
- 🔄 **API Robusta**: Sistema de fallback para manejar errores de conexión

## Cómo Verificar Visualmente

### 1. Página Principal (/)
- **Hero Section**: Debe mostrar el título "Conviértete en Experto en IA" con el CTA "Explorar Módulos"
- **Módulos**: 8 tarjetas de módulos con scroll horizontal, cada una con imagen, título, descripción y botón "Ver Módulo"
- **Tendencias**: Grid de 3 columnas con las últimas tendencias de IA
- **Estadísticas**: Sección con números (8 módulos, 150+ lecciones, 50+ proyectos, 24/7 soporte)

### 2. Navegación a Módulos (/modules)
- **CTA Functionality**: Click en "Explorar Módulos" debe navegar a /modules
- **Módulos Grid**: Vista de cuadrícula con todas las tarjetas de módulos
- **Stats Cards**: 4 tarjetas de estadísticas en la parte superior
- **Progress Tracking**: Muestra progreso para usuarios autenticados

### 3. Navegación a Tendencias (/trends)
- **Nav Link**: Click en "Tendencias" en la navegación debe llevar a /trends
- **Retry Button**: Botón "Actualizar Tendencias" con animación de carga
- **Error Handling**: Si falla la API, debe mostrar datos locales y mensaje de error
- **External Links**: Botones "Leer Artículo" que abren enlaces externos

### 4. Páginas de Autenticación (/auth/*)
- **Login**: Formulario con campos de email/contraseña, validación básica
- **Register**: Formulario con nombre, email, contraseña y confirmación
- **Navigation**: Links entre login/register y navegación de vuelta

### 5. Verificación Mobile/Desktop
- **Mobile**: Verificar que no haya overflow horizontal y que todo sea legible
- **Desktop**: Verificar espaciado adecuado y distribución de elementos
- **Responsive**: Probar breakpoints sm:, md:, lg: para comportamiento adaptativo

## Tech Stack

- **Frontend**: Next.js 15, React 19, TypeScript
- **Estilos**: Tailwind CSS 4, shadcn/ui components
- **Estado**: React hooks, localStorage para progreso
- **API**: Next.js API Routes, arXiv integration
- **Iconos**: Lucide React
- **Fuentes**: System fonts (sin Google Fonts)

## Instalación

1. Clonar el repositorio
2. Instalar dependencias:
   ```bash
   npm install
   ```
3. Iniciar servidor de desarrollo:
   ```bash
   npm run dev
   ```

## Scripts Disponibles

- `npm run dev` - Iniciar servidor de desarrollo
- `npm run build` - Construir para producción
- `npm run start` - Iniciar servidor de producción
- `npm run lint` - Ejecutar ESLint
- `npm run typecheck` - Verificar tipos TypeScript
- `npm run e2e` - Ejecutar tests end-to-end
- `npm run test` - Ejecutar tests unitarios

## Variables de Entorno

Crear archivo `.env.local` con:

```env
NEXT_PUBLIC_FEATURE_TRENDS=true
```

## Estructura del Proyecto

```
src/
├── app/                    # Páginas y API routes
│   ├── page.tsx           # Página principal
│   ├── modules/           # Páginas de módulos
│   ├── trends/            # Página de tendencias
│   ├── auth/              # Páginas de autenticación
│   └── api/               # API routes
├── components/            # Componentes UI
│   ├── ui/                # shadcn/ui components
│   ├── NavBar.tsx
│   ├── HeroCTA.tsx
│   ├── ModuleCard.tsx
│   └── NavAuthButtons.tsx
├── lib/                   # Utilidades y configuración
├── data/                  # Datos estáticos y mock
└── app/globals.css        # Estilos globales
```

## Desarrollo

El proyecto sigue las siguientes convenciones:

- **Componentes Client**: Todos los componentes con interactividad usan `"use client"`
- **Navegación**: Usar `router.push()` para navegación programática
- **Estilos**: Tailwind classes con sistema de diseño consistente
- **Accesibilidad**: Atributos `aria-label` y `data-testid` para testing
- **Manejo de Errores**: Fallbacks para API y datos locales
- **Responsive Design**: Mobile-first con breakpoints apropiados

## Testing

### End-to-End
```bash
npm run e2e
```

### Unit Tests
```bash
npm run test
```

## Despliegue

1. Construir el proyecto:
   ```bash
   npm run build
   ```
2. Iniciar servidor de producción:
   ```bash
   npm start
   ```

## Contribución

1. Hacer fork del proyecto
2. Crear feature branch
3. Commits descriptivos
4. Push al branch
5. Crear Pull Request

## Licencia

MIT License - ver archivo LICENSE para detalles