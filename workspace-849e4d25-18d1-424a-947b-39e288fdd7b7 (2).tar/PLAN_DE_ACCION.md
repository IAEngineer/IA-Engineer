# 🎯 PLAN DE ACCIÓN - AI Pathfinders 2025

**Versión**: 1.0.0  
**Fecha**: 2025-06-17  
**Estrategia**: Mejora incremental con feature flags y rollback seguro  

---

## 📋 Resumen Estratégico

Este plan detalla la implementación de mejoras para **AI Pathfinders 2025** siguiendo un enfoque de **riesgo controlado** donde cada cambio potencialmente disruptivo se implementa detrás de **feature flags** con **estrategias de rollback** claras.

### 🎯 Principios Guía
1. **No romper lo que funciona** - Preservar UI y componentes existentes
2. **Cambios incrementales** - Tareas pequeñas y atómicas
3. **Pruebas antes de producción** - Validación en cada etapa
4. **Rollback inmediato** - Plan de reversión para cada cambio
5. **Documentación continua** - Registrar decisiones y cambios

---

## 🚦 Fases de Implementación

### 🟢 **FASE 1: Estabilización Crítica** (Semana 1)
**Objetivo**: Corregir problemas fundamentales sin cambiar funcionalidad existente
**Riesgo**: Bajo | **Impacto**: Alto | **Esfuerzo**: Bajo

#### **Tarea 1.1: Corregir Navegación**
```typescript
// Estado actual: window.location.href (problemático)
// Objetivo: Usar router.push de Next.js
```

**Archivos afectados**:
- `src/app/page.tsx`
- `src/app/login/page.tsx`
- `src/app/dashboard/page.tsx`
- `src/app/modules/[id]/page.tsx`

**Implementación**:
```typescript
// ✅ Implementación correcta
import { useRouter } from 'next/navigation';

const Component = () => {
  const router = useRouter();
  
  const handleNavigation = (path: string) => {
    router.push(path);
  };
  
  return (
    <button onClick={() => handleNavigation('/login')}>
      Iniciar Sesión
    </button>
  );
};
```

**Riesgo**: Bajo - Cambio mecánico, no afecta lógica de negocio
**Estrategia de rollback**: Revertir cambios con `git checkout -- files`
**Feature flag**: `NEXT_PUBLIC_USE_ROUTER_NAVIGATION=true`

---

#### **Tarea 1.2: Implementar Manejo de Errores con Toast**
```typescript
// Estado actual: console.error() (invisible para usuario)
// Objetivo: Mostrar notificaciones amigables al usuario
```

**Archivos afectados**:
- `src/app/page.tsx` (fetchTrends)
- `src/app/api/trends/route.ts`
- `src/app/login/page.tsx`
- `src/app/dashboard/page.tsx`

**Implementación**:
```typescript
// ✅ Implementación correcta
import { useToast } from "@/hooks/use-toast";

const Component = () => {
  const { toast } = useToast();
  
  const fetchData = async () => {
    try {
      const response = await fetch('/api/trends');
      if (!response.ok) {
        throw new Error('Error fetching data');
      }
      const data = await response.json();
      setData(data);
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudieron cargar las tendencias. Intenta de nuevo.",
        variant: "destructive",
      });
      // Fallback a datos locales
      setData(getFallbackData());
    }
  };
};
```

**Riesgo**: Bajo - Solo mejora UX, no cambia funcionalidad
**Estrategia de rollback**: Eliminar llamadas a toast()
**Feature flag**: `NEXT_PUBLIC_USE_TOAST_NOTIFICATIONS=true`

---

#### **Tarea 1.3: Mejorar Loading States**
```typescript
// Estado actual: Solo "Cargando..." básico
// Objetivo: Skeleton UI para mejor experiencia
```

**Archivos afectados**:
- `src/app/page.tsx`
- `src/app/dashboard/page.tsx`
- `src/app/modules/[id]/page.tsx`

**Implementación**:
```typescript
// ✅ Implementación correcta
import { Skeleton } from "@/components/ui/skeleton";

const TrendsSection = ({ loading, trends }) => {
  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array.from({ length: 3 }).map((_, index) => (
          <div key={index} className="flex flex-col gap-3">
            <Skeleton className="w-full aspect-square rounded-lg" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-2/3" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {trends.map((trend) => (
        // Render real data
      ))}
    </div>
  );
};
```

**Riesgo**: Bajo - Solo mejora visual
**Estrategia de rollback**: Revertir a loading states simples
**Feature flag**: `NEXT_PUBLIC_USE_SKELETON_LOADING=true`

---

### 🟡 **FASE 2: Funcionalidad Core** (Semanas 2-3)
**Objetivo**: Implementar backend real y funcionalidades básicas
**Riesgo**: Medio | **Impacto**: Alto | **Esfuerzo**: Medio

#### **Tarea 2.1: Ampliar Esquema de Base de Datos**
```prisma
// Estado actual: Solo modelos User y Post básicos
// Objetivo: Modelo completo para el sistema educativo
```

**Archivos afectados**:
- `prisma/schema.prisma`
- `src/lib/db.ts`

**Implementación**:
```prisma
// ✅ Esquema completo
model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  avatar    String?
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  // Relaciones
  progress  UserProgress[]
  achievements UserAchievement[]
  certificates Certificate[]
  
  @@map("users")
}

model Module {
  id          String   @id @default(cuid())
  title       String
  description String
  difficulty  String   // 'Principiante' | 'Intermedio' | 'Avanzado'
  duration    String   // '4 semanas'
  imageUrl    String?
  icon        String?
  color       String?
  isActive    Boolean  @default(true)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  // Relaciones
  lessons     Lesson[]
  practices   Practice[]
  exams       Exam[]
  progress    UserProgress[]
  certificates Certificate[]
  
  @@map("modules")
}

model Lesson {
  id          String   @id @default(cuid())
  moduleId    String
  title       String
  description String
  content     String   // Markdown o HTML
  duration    String   // '15 min'
  type        String   // 'video' | 'reading' | 'practice'
  videoUrl    String?
  order       Int
  isActive    Boolean  @default(true)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  // Relaciones
  module      Module   @relation(fields: [moduleId], references: [id], onDelete: Cascade)
  progress    UserProgress[]
  
  @@map("lessons")
}

model Practice {
  id          String   @id @default(cuid())
  moduleId    String
  title       String
  description String
  instructions String
  difficulty  String   // 'Fácil' | 'Medio' | 'Difícil'
  solution    String?
  order       Int
  isActive    Boolean  @default(true)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  // Relaciones
  module      Module   @relation(fields: [moduleId], references: [id], onDelete: Cascade)
  
  @@map("practices")
}

model Exam {
  id          String   @id @default(cuid())
  moduleId    String
  title       String
  description String
  questions   Int      // Número de preguntas
  timeLimit   Int      // Minutos
  passingScore Int     // Porcentaje mínimo para aprobar
  order       Int
  isActive    Boolean  @default(true)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  // Relaciones
  module      Module   @relation(fields: [moduleId], references: [id], onDelete: Cascade)
  results     ExamResult[]
  
  @@map("exams")
}

model UserProgress {
  id          String   @id @default(cuid())
  userId      String
  moduleId    String
  lessonId    String?
  completed   Boolean  @default(false)
  progress    Int      @default(0) // Porcentaje
  timeSpent   Int      @default(0) // Minutos
  lastAccessed DateTime @default(now())
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  // Relaciones
  user        User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  module      Module   @relation(fields: [moduleId], references: [id], onDelete: Cascade)
  lesson      Lesson?  @relation(fields: [lessonId], references: [id])
  
  @@unique([userId, moduleId, lessonId])
  @@map("user_progress")
}

model ExamResult {
  id          String   @id @default(cuid())
  userId      String
  examId      String
  score       Int      // Porcentaje
  passed      Boolean
  timeSpent   Int      // Minutos
  answers     String   // JSON con respuestas
  completedAt DateTime @default(now())
  
  // Relaciones
  user        User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  exam        Exam     @relation(fields: [examId], references: [id], onDelete: Cascade)
  
  @@unique([userId, examId])
  @@map("exam_results")
}

model Certificate {
  id          String   @id @default(cuid())
  userId      String
  moduleId    String
  certificateNumber String @unique
  issuedAt    DateTime @default(now())
  expiresAt   DateTime?
  fileUrl     String?  // URL del PDF en almacenamiento
  verified    Boolean  @default(false)
  
  // Relaciones
  user        User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  module      Module   @relation(fields: [moduleId], references: [id], onDelete: Cascade)
  
  @@map("certificates")
}

model UserAchievement {
  id          String   @id @default(cuid())
  userId      String
  title       String
  description String
  icon        String
  shareable   Boolean  @default(true)
  earnedAt    DateTime @default(now())
  
  // Relaciones
  user        User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  
  @@unique([userId, title])
  @@map("user_achievements")
}
```

**Riesgo**: Medio - Cambios significativos en la base de datos
**Estrategia de rollback**: 
1. Backup de base de datos antes de migrar
2. Mantener esquema anterior en rama separada
3. Script de rollback para revertir migraciones

**Comandos de rollback**:
```bash
# Revertir última migración
npx prisma migrate reset

# Restaurar desde backup
sqlite3 db/custom.db < backup.sql
```

**Feature flag**: `NEXT_PUBLIC_USE_EXTENDED_SCHEMA=true`

---

#### **Tarea 2.2: Implementar Autenticación Real con NextAuth.js**
```typescript
// Estado actual: Simulación de login
// Objetivo: Autenticación real con base de datos
```

**Archivos afectados**:
- `src/app/login/page.tsx`
- `src/app/api/auth/[...nextauth]/route.ts` (nuevo)
- `src/lib/auth.ts` (nuevo)
- `.env.local`

**Implementación**:
```typescript
// src/lib/auth.ts
import NextAuth from "next-auth";
import { PrismaAdapter } from "@next-auth/prisma-adapter";
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";
import { db } from "@/lib/db";
import bcrypt from "bcryptjs";

export const authOptions = {
  adapter: PrismaAdapter(db),
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        const user = await db.user.findUnique({
          where: {
            email: credentials.email
          }
        });

        if (!user) {
          return null;
        }

        // Para este ejemplo, asumimos que el password está hasheado
        // En producción, usar bcrypt.compare()
        return {
          id: user.id,
          email: user.email,
          name: user.name,
        };
      }
    }),
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
    // Añadir GitHub, Twitter providers
  ],
  session: {
    strategy: "jwt" as const,
  },
  pages: {
    signIn: "/login",
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.sub = user.id;
      }
      return token;
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.sub;
      }
      return session;
    },
  },
};

// src/app/api/auth/[...nextauth]/route.ts
import NextAuth from "next-auth";
import { authOptions } from "@/lib/auth";

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
```

**Riesgo**: Alto - Cambio fundamental en la autenticación
**Estrategia de rollback**:
1. Mantener versión anterior de login en rama `legacy-auth`
2. Feature flag para cambiar entre auth real y simulada
3. Script para limpiar sesiones de autenticación

**Feature flag**: `NEXT_PUBLIC_USE_REAL_AUTH=true`

---

#### **Tarea 2.3: Crear API Routes Funcionales**
```typescript
// Estado actual: Datos simulados con setTimeout
// Objetivo: APIs reales conectadas a base de datos
```

**Archivos afectados**:
- `src/app/api/modules/route.ts` (nuevo)
- `src/app/api/modules/[id]/route.ts` (nuevo)
- `src/app/api/progress/route.ts` (nuevo)
- `src/app/api/exams/route.ts` (nuevo)
- `src/app/api/certificate/route.ts` (mejora)

**Implementación**:
```typescript
// src/app/api/modules/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    const modules = await db.module.findMany({
      where: { isActive: true },
      include: {
        lessons: {
          where: { isActive: true },
          orderBy: { order: 'asc' }
        },
        _count: {
          select: {
            lessons: true,
            practices: true,
            exams: true
          }
        }
      },
      orderBy: { createdAt: 'asc' }
    });

    // Si hay usuario, incluir progreso
    if (session?.user?.id) {
      const userProgress = await db.userProgress.findMany({
        where: { userId: session.user.id },
        include: { module: true }
      });

      return NextResponse.json({
        modules,
        userProgress
      });
    }

    return NextResponse.json({ modules });
  } catch (error) {
    console.error('Error fetching modules:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// src/app/api/progress/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { moduleId, lessonId, completed, progress, timeSpent } = await request.json();

    // Actualizar o crear progreso del usuario
    const userProgress = await db.userProgress.upsert({
      where: {
        userId_moduleId_lessonId: {
          userId: session.user.id,
          moduleId,
          lessonId
        }
      },
      update: {
        completed,
        progress,
        timeSpent,
        lastAccessed: new Date()
      },
      create: {
        userId: session.user.id,
        moduleId,
        lessonId,
        completed,
        progress,
        timeSpent
      }
    });

    // Calcular progreso total del módulo
    const moduleProgress = await db.userProgress.findMany({
      where: {
        userId: session.user.id,
        moduleId
      }
    });

    const totalProgress = moduleProgress.reduce((sum, p) => sum + p.progress, 0) / moduleProgress.length;

    return NextResponse.json({
      success: true,
      progress: userProgress,
      moduleProgress: Math.round(totalProgress)
    });
  } catch (error) {
    console.error('Error updating progress:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
```

**Riesgo**: Medio - Cambios en backend que afectan a frontend
**Estrategia de rollback**:
1. Mantener endpoints simulados en paralelo
2. Feature flag para cambiar entre APIs reales y simuladas
3. Monitorear errores y rendimiento

**Feature flag**: `NEXT_PUBLIC_USE_REAL_APIS=true`

---

### 🟠 **FASE 3: Características Avanzadas** (Semanas 4-5)
**Objetivo**: Implementar funcionalidades complejas y diferenciadoras
**Riesgo**: Alto | **Impacto**: Medio | **Esfuerzo**: Alto

#### **Tarea 3.1: Sistema de Certificados Real**
```typescript
// Estado actual: API básica sin funcionalidad real
// Objetivo: Generación PDF real, envío por email
```

**Archivos afectados**:
- `src/app/api/certificate/route.ts` (mejora)
- `src/app/api/certificate/generate/route.ts` (nuevo)
- `src/lib/certificate.ts` (nuevo)
- `src/components/CertificateViewer.tsx` (nuevo)

**Implementación**:
```typescript
// src/lib/certificate.ts
import { db } from '@/lib/db';
import jsPDF from 'jspdf';
import nodemailer from 'nodemailer';

export class CertificateService {
  static async generateCertificate(userId: string, moduleId: string) {
    // Verificar si el usuario completó el módulo
    const userProgress = await db.userProgress.findMany({
      where: { userId, moduleId },
      include: { module: true }
    });

    const allLessonsCompleted = userProgress.every(p => p.completed);
    const moduleProgress = userProgress.reduce((sum, p) => sum + p.progress, 0) / userProgress.length;

    if (!allLessonsCompleted || moduleProgress < 100) {
      throw new Error('Module not completed');
    }

    // Generar número de certificado único
    const certificateNumber = `AI-PF-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    // Crear certificado en base de datos
    const certificate = await db.certificate.create({
      data: {
        userId,
        moduleId,
        certificateNumber
      }
    });

    // Generar PDF
    const pdfBuffer = await this.generatePDF(certificateNumber, userId, moduleId);

    // Guardar PDF en almacenamiento (aquí sería S3 o similar)
    const fileUrl = await this.saveToStorage(pdfBuffer, certificateNumber);

    // Actualizar certificado con URL
    await db.certificate.update({
      where: { id: certificate.id },
      data: { fileUrl }
    });

    // Enviar email
    await this.sendCertificateEmail(userId, certificateNumber, fileUrl);

    return certificate;
  }

  private static async generatePDF(certificateNumber: string, userId: string, moduleId: string) {
    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4'
    });

    // Obtener datos del usuario y módulo
    const [user, module] = await Promise.all([
      db.user.findUnique({ where: { id: userId } }),
      db.module.findUnique({ where: { id: moduleId } })
    ]);

    // Diseño del certificado
    doc.setFontSize(30);
    doc.text('Certificate of Completion', 148, 50, { align: 'center' });
    
    doc.setFontSize(20);
    doc.text('This is to certify that', 148, 80, { align: 'center' });
    
    doc.setFontSize(25);
    doc.text(user?.name || 'User Name', 148, 100, { align: 'center' });
    
    doc.setFontSize(18);
    doc.text('has successfully completed the module', 148, 120, { align: 'center' });
    
    doc.setFontSize(22);
    doc.text(module?.title || 'Module Title', 148, 140, { align: 'center' });
    
    doc.setFontSize(12);
    doc.text(`Certificate Number: ${certificateNumber}`, 148, 180, { align: 'center' });
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 148, 190, { align: 'center' });

    return doc.output('arraybuffer');
  }

  private static async saveToStorage(pdfBuffer: ArrayBuffer, certificateNumber: string): Promise<string> {
    // Implementación para S3 o almacenamiento local
    // Por ahora, guardar localmente
    const fs = require('fs');
    const path = `./certificates/${certificateNumber}.pdf`;
    fs.writeFileSync(path, Buffer.from(pdfBuffer));
    return `/api/certificate/download/${certificateNumber}`;
  }

  private static async sendCertificateEmail(userId: string, certificateNumber: string, fileUrl: string) {
    const user = await db.user.findUnique({ where: { id: userId } });
    
    if (!user?.email) return;

    const transporter = nodemailer.createTransporter({
      host: process.env.EMAIL_HOST,
      port: parseInt(process.env.EMAIL_PORT || '587'),
      secure: false,
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: user.email,
      subject: '¡Felicidades! Has completado un módulo',
      html: `
        <h2>¡Felicidades ${user.name}!</h2>
        <p>Has completado exitosamente el módulo y tu certificado está disponible.</p>
        <p><a href="${fileUrl}">Descargar Certificado</a></p>
        <p>Número de certificado: ${certificateNumber}</p>
      `
    });
  }
}
```

**Riesgo**: Alto - Dependencias externas, complejidad de implementación
**Estrategia de rollback**:
1. Mantener sistema de certificados simulado
2. Feature flag para habilitar/deshabilitar generación real
3. Monitorizar errores de generación y envío

**Feature flag**: `NEXT_PUBLIC_USE_REAL_CERTIFICATES=true`

---

#### **Tarea 3.2: Exámenes Interactivos**
```typescript
// Estado actual: Exámenes estáticos sin interacción
// Objetivo: Sistema completo de preguntas, calificaciones y retroalimentación
```

**Archivos afectados**:
- `src/app/api/exams/[id]/route.ts` (nuevo)
- `src/app/api/exams/[id]/submit/route.ts` (nuevo)
- `src/components/ExamInterface.tsx` (nuevo)
- `src/components/QuestionComponent.tsx` (nuevo)

**Implementación**:
```typescript
// src/components/ExamInterface.tsx
"use client";

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { QuestionComponent } from "./QuestionComponent";
import { useToast } from "@/hooks/use-toast";

interface Question {
  id: string;
  text: string;
  type: 'multiple-choice' | 'true-false' | 'text';
  options?: string[];
  correctAnswer: string | string[];
  points: number;
}

interface Exam {
  id: string;
  title: string;
  description: string;
  questions: Question[];
  timeLimit: number;
  passingScore: number;
}

export function ExamInterface({ examId }: { examId: string }) {
  const [exam, setExam] = useState<Exam | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [examStarted, setExamStarted] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadExam();
  }, [examId]);

  useEffect(() => {
    if (examStarted && timeLeft > 0) {
      const timer = setTimeout(() => {
        setTimeLeft(timeLeft - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && examStarted) {
      handleSubmit();
    }
  }, [timeLeft, examStarted]);

  const loadExam = async () => {
    try {
      const response = await fetch(`/api/exams/${examId}`);
      const data = await response.json();
      setExam(data);
      setTimeLeft(data.timeLimit * 60); // Convertir a segundos
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo cargar el examen",
        variant: "destructive",
      });
    }
  };

  const handleAnswer = (questionId: string, answer: any) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    try {
      const response = await fetch(`/api/exams/${examId}/submit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ answers }),
      });

      const result = await response.json();
      
      if (result.passed) {
        toast({
          title: "¡Felicidades!",
          description: `Has aprobado el examen con ${result.score}%`,
        });
      } else {
        toast({
          title: "No aprobado",
          description: `Tu puntuación es ${result.score}%. Necesitas ${exam?.passingScore}% para aprobar.`,
          variant: "destructive",
        });
      }

      // Redirigir o mostrar resultados detallados
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo enviar el examen",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const startExam = () => {
    setExamStarted(true);
  };

  if (!exam) {
    return <div>Cargando examen...</div>;
  }

  if (!examStarted) {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>{exam.title}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">{exam.description}</p>
          <div className="space-y-2 mb-6">
            <p><strong>Preguntas:</strong> {exam.questions.length}</p>
            <p><strong>Tiempo límite:</strong> {exam.timeLimit} minutos</p>
            <p><strong>Puntuación para aprobar:</strong> {exam.passingScore}%</p>
          </div>
          <Button onClick={startExam} className="w-full">
            Comenzar Examen
          </Button>
        </CardContent>
      </Card>
    );
  }

  const progress = ((currentQuestion + 1) / exam.questions.length) * 100;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-gray-600">
            Pregunta {currentQuestion + 1} de {exam.questions.length}
          </span>
          <span className="text-sm text-gray-600">
            Tiempo: {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
          </span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <QuestionComponent
        question={exam.questions[currentQuestion]}
        answer={answers[exam.questions[currentQuestion].id]}
        onAnswer={handleAnswer}
      />

      <div className="flex justify-between mt-6">
        <Button
          variant="outline"
          onClick={() => setCurrentQuestion(prev => Math.max(0, prev - 1))}
          disabled={currentQuestion === 0}
        >
          Anterior
        </Button>
        
        {currentQuestion === exam.questions.length - 1 ? (
          <Button onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting ? "Enviando..." : "Finalizar Examen"}
          </Button>
        ) : (
          <Button onClick={() => setCurrentQuestion(prev => prev + 1)}>
            Siguiente
          </Button>
        )}
      </div>
    </div>
  );
}
```

**Riesgo**: Medio-Alto - Complejidad de estado y lógica de negocio
**Estrategia de rollback**:
1. Mantener sistema de exámenes simple
2. Feature flag para habilitar interfaz interactiva
3. Monitorear estado de respuestas y envíos

**Feature flag**: `NEXT_PUBLIC_USE_INTERACTIVE_EXAMS=true`

---

### 🔵 **FASE 4: Calidad y Testing** (Semana 6)
**Objetivo**: Implementar suite completa de pruebas
**Riesgo**: Bajo | **Impacto**: Alto | **Esfuerzo**: Medio

#### **Tarea 4.1: Pruebas Unitarias**
```typescript
// Estado actual: Sin pruebas
// Objetivo: Cobertura >80% de componentes y utilidades
```

**Archivos afectados**:
- `jest.config.js` (nuevo)
- `jest.setup.js` (nuevo)
- `__tests__/components/` (nuevo)
- `__tests__/lib/` (nuevo)
- `__tests__/hooks/` (nuevo)

**Implementación**:
```javascript
// jest.config.js
module.exports = {
  testEnvironment: 'jsdom',
  setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
  testPathIgnorePatterns: [
    '<rootDir>/.next/',
    '<rootDir>/node_modules/',
  ],
  moduleNameMapping: {
    '^@/(.*)$': '<rootDir>/src/$1',
  },
  collectCoverageFrom: [
    'src/**/*.{js,jsx,ts,tsx}',
    '!src/**/*.d.ts',
    '!src/app/layout.tsx',
  ],
  coverageReporters: ['text', 'lcov', 'html'],
};

// __tests__/components/Button.test.tsx
import { render, screen } from '@testing-library/react';
import { Button } from '@/components/ui/button';

describe('Button Component', () => {
  it('renders with correct text', () => {
    render(<Button>Click me</Button>);
    expect(screen.getByText('Click me')).toBeInTheDocument();
  });

  it('handles click events', () => {
    const handleClick = jest.fn();
    render(<Button onClick={handleClick}>Click me</Button>);
    
    const button = screen.getByText('Click me');
    button.click();
    
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  it('applies variant classes correctly', () => {
    const { container } = render(<Button variant="destructive">Delete</Button>);
    const button = container.firstChild;
    
    expect(button).toHaveClass('bg-destructive');
  });
});

// __tests__/lib/utils.test.ts
import { cn } from '@/lib/utils';

describe('Utils', () => {
  describe('cn function', () => {
    it('merges class names correctly', () => {
      expect(cn('class1', 'class2')).toBe('class1 class2');
    });

    it('handles conditional classes', () => {
      expect(cn('base', true && 'active', false && 'inactive')).toBe('base active');
    });

    it('handles undefined and null values', () => {
      expect(cn('base', undefined, null, 'valid')).toBe('base valid');
    });
  });
});
```

**Riesgo**: Bajo - Las pruebas no afectan el funcionamiento
**Estrategia de rollback**: Eliminar directorio de pruebas y configuración

**Feature flag**: `NEXT_PUBLIC_RUN_TESTS=true` (para desarrollo)

---

#### **Tarea 4.2: Pruebas E2E con Playwright**
```typescript
// Estado actual: Sin pruebas E2E
// Objetivo: Flujos completos del usuario probados
```

**Archivos afectados**:
- `playwright.config.ts` (nuevo)
- `tests/e2e/auth.spec.ts` (nuevo)
- `tests/e2e/modules.spec.ts` (nuevo)
- `tests/e2e/dashboard.spec.ts` (nuevo)

**Implementación**:
```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
    {
      name: 'Mobile Chrome',
      use: { ...devices['Pixel 5'] },
    },
    {
      name: 'Mobile Safari',
      use: { ...devices['iPhone 12'] },
    },
  ],

  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
});

// tests/e2e/auth.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Authentication', () => {
  test('successful login redirects to dashboard', async ({ page }) => {
    await page.goto('/login');
    
    await page.fill('[type="email"]', 'test@example.com');
    await page.fill('[type="password"]', 'password123');
    await page.click('button:has-text("Iniciar Sesión")');
    
    await expect(page).toHaveURL('/dashboard');
    await expect(page.locator('text=Bienvenido de vuelta')).toBeVisible();
  });

  test('shows error for invalid credentials', async ({ page }) => {
    await page.goto('/login');
    
    await page.fill('[type="email"]', 'invalid@example.com');
    await page.fill('[type="password"]', 'wrongpassword');
    await page.click('button:has-text("Iniciar Sesión")');
    
    await expect(page.locator('text=Credenciales inválidas')).toBeVisible();
  });

  test('OAuth login with Google', async ({ page }) => {
    await page.goto('/login');
    
    // Mock OAuth response for testing
    await page.route('**/api/auth/signin/google', async (route) => {
      await route.fulfill({
        status: 302,
        headers: {
          'Location': '/dashboard',
        },
      });
    });
    
    await page.click('button:has-text("Continuar con Google")');
    await expect(page).toHaveURL('/dashboard');
  });
});

// tests/e2e/modules.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Module Learning Flow', () => {
  test.beforeEach(async ({ page }) => {
    // Login before each test
    await page.goto('/login');
    await page.fill('[type="email"]', 'test@example.com');
    await page.fill('[type="password"]', 'password123');
    await page.click('button:has-text("Iniciar Sesión")');
    await expect(page).toHaveURL('/dashboard');
  });

  test('navigate to module and view lessons', async ({ page }) => {
    await page.click('text=Módulos del Curso');
    await page.click('text=Ver Módulo').first();
    
    await expect(page.locator('h1')).toBeVisible();
    await expect(page.locator('text=Lecciones')).toBeVisible();
    
    // Click on first lesson
    await page.click('text=Comenzar').first();
    await expect(page.locator('text=Lección en curso')).toBeVisible();
  });

  test('complete lesson and update progress', async ({ page }) => {
    await page.goto('/modules/fundamentos');
    
    // Start first lesson
    await page.click('text=Comenzar').first();
    
    // Simulate lesson completion
    await page.click('text=Marcar como completada');
    
    // Check progress update
    await expect(page.locator('text=25%')).toBeVisible();
  });

  test('take and pass exam', async ({ page }) => {
    await page.goto('/modules/fundamentos');
    await page.click('text=Exámenes');
    await page.click('text=Comenzar');
    
    // Answer questions
    await page.click('text=Opción A');
    await page.click('text=Siguiente');
    
    // Submit exam
    await page.click('text=Finalizar Examen');
    
    await expect(page.locator('text=¡Felicidades!')).toBeVisible();
  });
});
```

**Riesgo**: Bajo - Las pruebas no afectan el funcionamiento
**Estrategia de rollback**: Eliminar configuración y tests de Playwright

**Feature flag**: `NEXT_PUBLIC_RUN_E2E_TESTS=true` (para desarrollo)

---

#### **Tarea 4.3: Pruebas Visuales**
```typescript
// Estado actual: Sin pruebas visuales
// Objetivo: Detectar regresiones visuales automáticamente
```

**Archivos afectados**:
- `tests/visual/home.spec.ts` (nuevo)
- `tests/visual/dashboard.spec.ts` (nuevo)
- `tests/visual/modules.spec.ts` (nuevo)

**Implementación**:
```typescript
// tests/visual/home.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Visual Regression Tests', () => {
  test('homepage layout', async ({ page }) => {
    await page.goto('/');
    await page.waitForSelector('text=AI Pathfinders 2025');
    
    // Wait for dynamic content to load
    await page.waitForSelector('text=Tendencias IA 2025');
    
    // Take screenshot
    await expect(page).toHaveScreenshot('homepage.png', {
      fullPage: true,
      animations: 'disabled',
    });
  });

  test('module cards layout', async ({ page }) => {
    await page.goto('/');
    await page.waitForSelector('text=Módulos del Curso');
    
    // Scroll to modules section
    await page.locator('text=Módulos del Curso').scrollIntoViewIfNeeded();
    
    // Take screenshot of modules section
    const modulesSection = page.locator('text=Módulos del Curso').locator('..');
    await expect(modulesSection).toHaveScreenshot('modules-section.png');
  });

  test('responsive design - mobile', async ({ page }) => {
    await page.goto('/');
    await page.setViewportSize({ width: 375, height: 667 });
    
    await page.waitForSelector('text=AI Pathfinders 2025');
    
    await expect(page).toHaveScreenshot('homepage-mobile.png', {
      fullPage: true,
    });
  });

  test('responsive design - tablet', async ({ page }) => {
    await page.goto('/');
    await page.setViewportSize({ width: 768, height: 1024 });
    
    await page.waitForSelector('text=AI Pathfinders 2025');
    
    await expect(page).toHaveScreenshot('homepage-tablet.png', {
      fullPage: true,
    });
  });
});

// tests/visual/dashboard.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Dashboard Visual Tests', () => {
  test.beforeEach(async ({ page }) => {
    // Mock authentication for visual tests
    await page.addInitScript(() => {
      window.localStorage.setItem('auth-token', 'mock-token');
    });
  });

  test('dashboard layout', async ({ page }) => {
    await page.goto('/dashboard');
    await page.waitForSelector('text=Bienvenido de vuelta');
    
    await expect(page).toHaveScreenshot('dashboard.png', {
      fullPage: true,
    });
  });

  test('progress cards', async ({ page }) => {
    await page.goto('/dashboard');
    await page.waitForSelector('text=Progreso General');
    
    const progressCards = page.locator('text=Progreso General').locator('..').locator('..');
    await expect(progressCards).toHaveScreenshot('progress-cards.png');
  });

  test('achievements section', async ({ page }) => {
    await page.goto('/dashboard');
    await page.waitForSelector('text=Logros Recientes');
    
    const achievementsSection = page.locator('text=Logros Recientes').locator('..').locator('..');
    await expect(achievementsSection).toHaveScreenshot('achievements-section.png');
  });
});
```

**Riesgo**: Bajo - Las pruebas no afectan el funcionamiento
**Estrategia de rollback**: Eliminar directorio de pruebas visuales

**Feature flag**: `NEXT_PUBLIC_RUN_VISUAL_TESTS=true` (para desarrollo)

---

## 🎛️ **Sistema de Feature Flags**

### **Implementación de Feature Flags**
```typescript
// src/lib/featureFlags.ts
export interface FeatureFlags {
  USE_ROUTER_NAVIGATION: boolean;
  USE_TOAST_NOTIFICATIONS: boolean;
  USE_SKELETON_LOADING: boolean;
  USE_EXTENDED_SCHEMA: boolean;
  USE_REAL_AUTH: boolean;
  USE_REAL_APIS: boolean;
  USE_REAL_CERTIFICATES: boolean;
  USE_INTERACTIVE_EXAMS: boolean;
  RUN_TESTS: boolean;
  RUN_E2E_TESTS: boolean;
  RUN_VISUAL_TESTS: boolean;
}

export const featureFlags: FeatureFlags = {
  USE_ROUTER_NAVIGATION: process.env.NEXT_PUBLIC_USE_ROUTER_NAVIGATION === 'true',
  USE_TOAST_NOTIFICATIONS: process.env.NEXT_PUBLIC_USE_TOAST_NOTIFICATIONS === 'true',
  USE_SKELETON_LOADING: process.env.NEXT_PUBLIC_USE_SKELETON_LOADING === 'true',
  USE_EXTENDED_SCHEMA: process.env.NEXT_PUBLIC_USE_EXTENDED_SCHEMA === 'true',
  USE_REAL_AUTH: process.env.NEXT_PUBLIC_USE_REAL_AUTH === 'true',
  USE_REAL_APIS: process.env.NEXT_PUBLIC_USE_REAL_APIS === 'true',
  USE_REAL_CERTIFICATES: process.env.NEXT_PUBLIC_USE_REAL_CERTIFICATES === 'true',
  USE_INTERACTIVE_EXAMS: process.env.NEXT_PUBLIC_USE_INTERACTIVE_EXAMS === 'true',
  RUN_TESTS: process.env.NEXT_PUBLIC_RUN_TESTS === 'true',
  RUN_E2E_TESTS: process.env.NEXT_PUBLIC_RUN_E2E_TESTS === 'true',
  RUN_VISUAL_TESTS: process.env.NEXT_PUBLIC_RUN_VISUAL_TESTS === 'true',
};

export const isFeatureEnabled = (feature: keyof FeatureFlags): boolean => {
  return featureFlags[feature];
};
```

### **Uso en Componentes**
```typescript
// src/components/Navigation.tsx
import { isFeatureEnabled } from '@/lib/featureFlags';

const Navigation = () => {
  const router = useRouter();
  
  const handleNavigation = (path: string) => {
    if (isFeatureEnabled('USE_ROUTER_NAVIGATION')) {
      router.push(path);
    } else {
      // Fallback a window.location
      window.location.href = path;
    }
  };
  
  return (
    <nav>
      <button onClick={() => handleNavigation('/dashboard')}>
        Dashboard
      </button>
    </nav>
  );
};
```

---

## 📊 **Matriz de Riesgo y Priorización**

| Tarea | Riesgo | Impacto | Esfuerzo | Prioridad | Depende de | Feature Flag |
|-------|--------|---------|----------|-----------|------------|--------------|
| 1.1 Navegación | Bajo | Alto | Bajo | 1 | Ninguna | USE_ROUTER_NAVIGATION |
| 1.2 Manejo de Errores | Bajo | Alto | Bajo | 1 | Ninguna | USE_TOAST_NOTIFICATIONS |
| 1.3 Loading States | Bajo | Medio | Bajo | 2 | Ninguna | USE_SKELETON_LOADING |
| 2.1 Esquema DB | Medio | Alto | Medio | 2 | Ninguna | USE_EXTENDED_SCHEMA |
| 2.2 Autenticación | Alto | Alto | Medio | 3 | 2.1 | USE_REAL_AUTH |
| 2.3 APIs Reales | Medio | Alto | Medio | 3 | 2.1, 2.2 | USE_REAL_APIS |
| 3.1 Certificados | Alto | Medio | Alto | 4 | 2.1, 2.2, 2.3 | USE_REAL_CERTIFICATES |
| 3.2 Exámenes | Medio-Alto | Medio | Alto | 4 | 2.1, 2.2, 2.3 | USE_INTERACTIVE_EXAMS |
| 4.1 Pruebas Unitarias | Bajo | Alto | Medio | 3 | Ninguna | RUN_TESTS |
| 4.2 Pruebas E2E | Bajo | Alto | Medio | 4 | 4.1 | RUN_E2E_TESTS |
| 4.3 Pruebas Visuales | Bajo | Alto | Bajo | 5 | 4.1, 4.2 | RUN_VISUAL_TESTS |

---

## 🔄 **Estrategia de Rollback Detallada**

### **Proceso de Rollback Estándar**
```bash
# 1. Identificar el problema
git log --oneline -10

# 2. Crear backup de base de datos
cp db/custom.db db/custom.db.backup.$(date +%Y%m%d_%H%M%S)

# 3. Revertir cambios específicos
git revert <commit-hash>

# 4. Deshabilitar feature flags
echo "NEXT_PUBLIC_USE_REAL_AUTH=false" >> .env

# 5. Reiniciar servicios
npm run dev
```

### **Rollback por Fase**

#### **Fase 1 - Rollback Simple**
```bash
# Revertir cambios de navegación
git checkout src/app/page.tsx src/app/login/page.tsx
git reset HEAD~1

# Deshabilitar feature flags
sed -i 's/NEXT_PUBLIC_USE_ROUTER_NAVIGATION=true/NEXT_PUBLIC_USE_ROUTER_NAVIGATION=false/' .env
sed -i 's/NEXT_PUBLIC_USE_TOAST_NOTIFICATIONS=true/NEXT_PUBLIC_USE_TOAST_NOTIFICATIONS=false/' .env
```

#### **Fase 2 - Rollback Base de Datos**
```bash
# Restaurar backup de base de datos
cp db/custom.db.backup db/custom.db

# Revertir migraciones
npx prisma migrate reset --force

# Deshabilitar feature flags
echo "NEXT_PUBLIC_USE_EXTENDED_SCHEMA=false" >> .env
echo "NEXT_PUBLIC_USE_REAL_AUTH=false" >> .env
echo "NEXT_PUBLIC_USE_REAL_APIS=false" >> .env
```

#### **Fase 3 - Rollback Características**
```bash
# Revertir commits de características complejas
git revert <certificate-commit-hash>
git revert <exams-commit-hash>

# Limpiar archivos generados
rm -rf certificates/
rm -rf uploads/

# Deshabilitar feature flags
echo "NEXT_PUBLIC_USE_REAL_CERTIFICATES=false" >> .env
echo "NEXT_PUBLIC_USE_INTERACTIVE_EXAMS=false" >> .env
```

#### **Fase 4 - Rollback Testing**
```bash
# Eliminar configuración de pruebas
rm -rf __tests__/
rm -rf tests/
rm jest.config.js
rm playwright.config.ts

# Actualizar package.json
npm uninstall jest @testing-library/react @playwright/test

# Deshabilitar feature flags
echo "NEXT_PUBLIC_RUN_TESTS=false" >> .env
echo "NEXT_PUBLIC_RUN_E2E_TESTS=false" >> .env
echo "NEXT_PUBLIC_RUN_VISUAL_TESTS=false" >> .env
```

---

## 📈 **Métricas de Monitoreo**

### **Métricas Técnicas**
```typescript
// src/lib/monitoring.ts
export class MonitoringService {
  static trackMetric(name: string, value: number) {
    // Implementar con servicio de monitoreo
    console.log(`Metric: ${name} = ${value}`);
  }

  static trackError(error: Error, context?: any) {
    // Implementar con servicio de error tracking
    console.error('Error tracked:', error, context);
  }

  static trackPerformance(operation: string, duration: number) {
    // Implementar con APM
    console.log(`Performance: ${operation} took ${duration}ms`);
  }
}
```

### **KPIs a Monitorear**
1. **Tiempo de respuesta de APIs** < 1000ms
2. **Tasa de errores** < 1%
3. **Tiempo de carga de páginas** < 3s
4. **Coverage de pruebas** > 80%
5. **Uptime del servicio** > 99.9%

---

## 🎯 **Criterios de Aceptación**

### **Fase 1 - Estabilización**
- [ ] Todos los enlaces navegan correctamente
- [ ] Los errores muestran notificaciones amigables
- [ ] Los loading states usan skeleton UI
- [ ] No hay errores en consola en navegación

### **Fase 2 - Funcionalidad Core**
- [ ] Esquema de base de datos completo y migrado
- [ ] Login/registro funcionan con base de datos real
- [ ] APIs retornan datos dinámicos (no simulados)
- [ ] Progreso de usuario se guarda correctamente

### **Fase 3 - Características Avanzadas**
- [ ] Certificados se generan y envían por email
- [ ] Exámenes son interactivos y califican correctamente
- [ ] Sistema de logros funciona
- [ ] Integración social completa

### **Fase 4 - Calidad**
- [ ] Pruebas unitarias con >80% de cobertura
- [ ] Pruebas E2E para flujos principales
- [ ] Pruebas visuales pasando
- [ ] Documentación completa y actualizada

---

## 📝 **Conclusión**

Este plan de acción proporciona una **hoja de ruta clara** para transformar **AI Pathfinders 2025** de un prototipo funcional a una **aplicación production-ready**. La implementación por fases con **feature flags** y **estrategias de rollback** asegura que podemos:

1. **Minimizar riesgos** - Cambios incrementales y reversibles
2. **Mantener estabilidad** - No romper funcionalidad existente
3. **Medir progreso** - Criterios de aceptación claros
4. **Responder rápidamente** - Planes de rollback detallados

Con este enfoque, esperamos tener una **versión estable y completa** en **6 semanas**, con **calidad production-ready** y **documentación completa** para mantenimiento futuro.