import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import ProgressManager, { 
  UserProgress, 
  ModuleProgress, 
  LessonProgress, 
  PracticeProgress, 
  ExamProgress 
} from '../src/lib/progress';

describe('ProgressManager', () => {
  let mockUser: UserProgress;
  let mockModuleProgress: ModuleProgress;

  beforeEach(() => {
    // Clear localStorage before each test
    localStorage.clear();
    
    mockUser = {
      userId: 'test-user-123',
      modules: [],
      totalStudyTime: 0,
      achievements: []
    };

    mockModuleProgress = {
      moduleId: 'test-module',
      startedAt: '2025-01-01T00:00:00Z',
      lastAccessed: '2025-01-01T00:00:00Z',
      lessons: [],
      practices: [],
      exams: [],
      overallProgress: 0
    };
  });

  afterEach(() => {
    localStorage.clear();
  });

  describe('getProgress', () => {
    it('should return null when no progress exists', () => {
      const progress = ProgressManager.getProgress();
      expect(progress).toBeNull();
    });

    it('should return saved progress', () => {
      localStorage.setItem('ai-pathfinders-progress', JSON.stringify(mockUser));
      const progress = ProgressManager.getProgress();
      expect(progress).toEqual(mockUser);
    });

    it('should handle corrupted localStorage data', () => {
      localStorage.setItem('ai-pathfinders-progress', 'invalid-json');
      const progress = ProgressManager.getProgress();
      expect(progress).toBeNull();
    });
  });

  describe('saveProgress', () => {
    it('should save progress to localStorage', () => {
      ProgressManager.saveProgress(mockUser);
      const stored = localStorage.getItem('ai-pathfinders-progress');
      expect(stored).toBe(JSON.stringify(mockUser));
    });

    it('should handle localStorage errors gracefully', () => {
      // Mock localStorage.setItem to throw an error
      const originalSetItem = localStorage.setItem;
      localStorage.setItem = () => {
        throw new Error('Storage quota exceeded');
      };

      expect(() => ProgressManager.saveProgress(mockUser)).not.toThrow();

      // Restore original method
      localStorage.setItem = originalSetItem;
    });
  });

  describe('initializeProgress', () => {
    it('should create new progress with default values', () => {
      const progress = ProgressManager.initializeProgress('test-user');
      expect(progress.userId).toBe('test-user');
      expect(progress.modules).toEqual([]);
      expect(progress.totalStudyTime).toBe(0);
      expect(progress.achievements).toEqual([]);
    });

    it('should save initialized progress', () => {
      const progress = ProgressManager.initializeProgress('test-user');
      const stored = ProgressManager.getProgress();
      expect(stored).toEqual(progress);
    });
  });

  describe('updateLessonProgress', () => {
    it('should create new module progress if not exists', () => {
      ProgressManager.updateLessonProgress('lesson-1', 'module-1', true, 15);
      const progress = ProgressManager.getProgress();
      
      expect(progress).not.toBeNull();
      expect(progress!.modules).toHaveLength(1);
      expect(progress!.modules[0].moduleId).toBe('module-1');
      expect(progress!.modules[0].lessons).toHaveLength(1);
      expect(progress!.modules[0].lessons[0].lessonId).toBe('lesson-1');
      expect(progress!.modules[0].lessons[0].completed).toBe(true);
      expect(progress!.modules[0].lessons[0].timeSpent).toBe(15);
    });

    it('should update existing lesson progress', () => {
      // First create a lesson
      ProgressManager.updateLessonProgress('lesson-1', 'module-1', false, 10);
      
      // Then update it
      ProgressManager.updateLessonProgress('lesson-1', 'module-1', true, 25);
      
      const progress = ProgressManager.getProgress();
      const lesson = progress!.modules[0].lessons[0];
      
      expect(lesson.completed).toBe(true);
      expect(lesson.timeSpent).toBe(25);
      expect(lesson.completedAt).toBeDefined();
    });

    it('should calculate overall progress correctly', () => {
      // Add multiple lessons and practices
      ProgressManager.updateLessonProgress('lesson-1', 'module-1', true, 15);
      ProgressManager.updateLessonProgress('lesson-2', 'module-1', false, 10);
      ProgressManager.updatePracticeProgress('practice-1', 'module-1', true, 85);
      
      const progress = ProgressManager.getProgress();
      const moduleProgress = progress!.modules[0];
      
      // 2 lessons + 1 practice = 3 total items
      // 1 completed lesson + 1 completed practice = 2 completed items
      // 2/3 = 66.67%
      expect(moduleProgress.overallProgress).toBe(67);
    });

    it('should update lastAccessed timestamp', () => {
      ProgressManager.updateLessonProgress('lesson-1', 'module-1', true, 15);
      
      const progress = ProgressManager.getProgress();
      const lastAccessed = progress!.modules[0].lastAccessed;
      
      expect(lastAccessed).toBeDefined();
      expect(new Date(lastAccessed).getTime()).toBeGreaterThan(Date.now() - 1000);
    });
  });

  describe('updatePracticeProgress', () => {
    it('should create new practice progress', () => {
      ProgressManager.updatePracticeProgress('practice-1', 'module-1', true, 95);
      const progress = ProgressManager.getProgress();
      
      expect(progress).not.toBeNull();
      expect(progress!.modules[0].practices).toHaveLength(1);
      expect(progress!.modules[0].practices[0].practiceId).toBe('practice-1');
      expect(progress!.modules[0].practices[0].completed).toBe(true);
      expect(progress!.modules[0].practices[0].score).toBe(95);
    });

    it('should update existing practice progress', () => {
      ProgressManager.updatePracticeProgress('practice-1', 'module-1', false, 75);
      ProgressManager.updatePracticeProgress('practice-1', 'module-1', true, 85);
      
      const progress = ProgressManager.getProgress();
      const practice = progress!.modules[0].practices[0];
      
      expect(practice.completed).toBe(true);
      expect(practice.score).toBe(85);
      expect(practice.completedAt).toBeDefined();
    });
  });

  describe('updateExamProgress', () => {
    it('should create new exam progress', () => {
      const answers = { 'q1': 0, 'q2': 1 };
      ProgressManager.updateExamProgress('exam-1', 'module-1', 80, true, answers);
      
      const progress = ProgressManager.getProgress();
      expect(progress).not.toBeNull();
      expect(progress!.modules[0].exams).toHaveLength(1);
      expect(progress!.modules[0].exams[0].examId).toBe('exam-1');
      expect(progress!.modules[0].exams[0].score).toBe(80);
      expect(progress!.modules[0].exams[0].passed).toBe(true);
      expect(progress!.modules[0].exams[0].answers).toEqual(answers);
    });

    it('should add achievement for perfect score', () => {
      const answers = { 'q1': 0, 'q2': 1 };
      ProgressManager.updateExamProgress('exam-1', 'module-1', 95, true, answers);
      
      const progress = ProgressManager.getProgress();
      expect(progress!.achievements).toContain('perfect_score_exam-1');
    });

    it('should not add achievement for non-perfect score', () => {
      const answers = { 'q1': 0, 'q2': 1 };
      ProgressManager.updateExamProgress('exam-1', 'module-1', 85, true, answers);
      
      const progress = ProgressManager.getProgress();
      expect(progress!.achievements).not.toContain('perfect_score_exam-1');
    });
  });

  describe('addAchievement', () => {
    it('should add new achievement', () => {
      ProgressManager.initializeProgress('test-user');
      ProgressManager.addAchievement('first-lesson');
      
      const progress = ProgressManager.getProgress();
      expect(progress!.achievements).toContain('first-lesson');
    });

    it('should not add duplicate achievements', () => {
      ProgressManager.initializeProgress('test-user');
      ProgressManager.addAchievement('first-lesson');
      ProgressManager.addAchievement('first-lesson');
      
      const progress = ProgressManager.getProgress();
      expect(progress!.achievements.filter(a => a === 'first-lesson')).toHaveLength(1);
    });
  });

  describe('clearProgress', () => {
    it('should remove all progress from localStorage', () => {
      ProgressManager.initializeProgress('test-user');
      ProgressManager.updateLessonProgress('lesson-1', 'module-1', true, 15);
      
      ProgressManager.clearProgress();
      
      const progress = ProgressManager.getProgress();
      expect(progress).toBeNull();
    });
  });

  describe('getModuleProgress', () => {
    it('should return null for non-existent module', () => {
      const progress = ProgressManager.getModuleProgress('non-existent');
      expect(progress).toBeNull();
    });

    it('should return module progress for existing module', () => {
      ProgressManager.updateLessonProgress('lesson-1', 'module-1', true, 15);
      
      const progress = ProgressManager.getModuleProgress('module-1');
      expect(progress).not.toBeNull();
      expect(progress!.moduleId).toBe('module-1');
    });
  });

  describe('calculateModuleProgress', () => {
    it('should handle empty module', () => {
      const progress = ProgressManager['calculateModuleProgress'](mockModuleProgress);
      expect(progress).toBe(0);
    });

    it('should calculate progress with mixed completion', () => {
      mockModuleProgress.lessons = [
        { lessonId: '1', moduleId: 'test', completed: true, timeSpent: 10 },
        { lessonId: '2', moduleId: 'test', completed: false, timeSpent: 5 }
      ];
      mockModuleProgress.practices = [
        { practiceId: '1', moduleId: 'test', completed: true, score: 80 }
      ];
      mockModuleProgress.exams = [
        { examId: '1', moduleId: 'test', completed: false, score: 0, passed: false, answers: {} }
      ];

      const progress = ProgressManager['calculateModuleProgress'](mockModuleProgress);
      // 2 completed out of 4 total = 50%
      expect(progress).toBe(50);
    });

    it('should handle 100% completion', () => {
      mockModuleProgress.lessons = [
        { lessonId: '1', moduleId: 'test', completed: true, timeSpent: 10 },
        { lessonId: '2', moduleId: 'test', completed: true, timeSpent: 15 }
      ];
      mockModuleProgress.practices = [
        { practiceId: '1', moduleId: 'test', completed: true, score: 90 }
      ];
      mockModuleProgress.exams = [
        { examId: '1', moduleId: 'test', completed: true, score: 85, passed: true, answers: {} }
      ];

      const progress = ProgressManager['calculateModuleProgress'](mockModuleProgress);
      expect(progress).toBe(100);
    });
  });
});