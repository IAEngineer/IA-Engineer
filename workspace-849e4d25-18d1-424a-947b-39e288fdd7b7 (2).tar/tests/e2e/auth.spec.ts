import { test, expect } from '@playwright/test';

test.describe('Authentication Flow', () => {
  test.beforeEach(async ({ page }) => {
    // Clear localStorage before each test
    await page.goto('/');
    await page.evaluate(() => {
      localStorage.clear();
    });
  });

  test('should display login page and navigate to register', async ({ page }) => {
    await page.goto('/auth/login');
    
    // Check login page elements
    await expect(page).toHaveTitle(/Iniciar Sesión/);
    await expect(page.locator('text=Iniciar Sesión')).toBeVisible();
    await expect(page.locator('input[type="email"]')).toBeVisible();
    await expect(page.locator('input[type="password"]')).toBeVisible();
    await expect(page.locator('button:has-text("Iniciar Sesión")')).toBeVisible();
    
    // Navigate to register
    await page.click('button:has-text("Crear Cuenta")');
    await expect(page).toHaveURL(/\/auth\/register/);
    await expect(page.locator('text=Crear Cuenta')).toBeVisible();
  });

  test('should show validation errors for invalid login', async ({ page }) => {
    await page.goto('/auth/login');
    
    // Try to submit with empty fields
    await page.click('button:has-text("Iniciar Sesión")');
    
    // Check for validation (form should not submit)
    await expect(page).toHaveURL(/\/auth\/login/);
  });

  test('should successfully login with valid credentials', async ({ page }) => {
    await page.goto('/auth/login');
    
    // Fill in valid credentials
    await page.fill('input[type="email"]', 'test@example.com');
    await page.fill('input[type="password"]', 'password123');
    
    // Submit form
    await page.click('button:has-text("Iniciar Sesión")');
    
    // Wait for navigation to dashboard
    await expect(page).toHaveURL(/\/dashboard/);
    await expect(page.locator('text=Bienvenido de vuelta')).toBeVisible();
  });

  test('should successfully register new user', async ({ page }) => {
    await page.goto('/auth/register');
    
    // Fill in registration form
    await page.fill('input[name="name"]', 'Juan Pérez');
    await page.fill('input[type="email"]', 'newuser@example.com');
    await page.fill('input[type="password"]', 'password123');
    await page.fill('input[type="password"]', 'password123'); // Confirm password
    
    // Accept terms
    await page.check('input[type="checkbox"]');
    
    // Submit form
    await page.click('button:has-text("Crear Cuenta")');
    
    // Wait for navigation to dashboard
    await expect(page).toHaveURL(/\/dashboard/);
    await expect(page.locator('text=Bienvenido de vuelta')).toBeVisible();
  });

  test('should show password visibility toggle', async ({ page }) => {
    await page.goto('/auth/login');
    
    const passwordInput = page.locator('input[type="password"]');
    const toggleButton = page.locator('button:has-text("Ocultar contraseña")').first();
    
    // Initially password should be hidden
    await expect(passwordInput).toHaveAttribute('type', 'password');
    
    // Click toggle to show password
    await toggleButton.click();
    await expect(passwordInput).toHaveAttribute('type', 'text');
    
    // Click again to hide password
    await toggleButton.click();
    await expect(passwordInput).toHaveAttribute('type', 'password');
  });

  test('should persist login state across page refresh', async ({ page }) => {
    // First login
    await page.goto('/auth/login');
    await page.fill('input[type="email"]', 'test@example.com');
    await page.fill('input[type="password"]', 'password123');
    await page.click('button:has-text("Iniciar Sesión")');
    
    // Wait for dashboard
    await expect(page).toHaveURL(/\/dashboard/);
    
    // Refresh page
    await page.reload();
    
    // Should still be on dashboard (logged in)
    await expect(page).toHaveURL(/\/dashboard/);
    await expect(page.locator('text=Bienvenido de vuelta')).toBeVisible();
  });

  test('should handle keyboard navigation', async ({ page }) => {
    await page.goto('/auth/login');
    
    // Tab through form fields
    await page.keyboard.press('Tab');
    await expect(page.locator('input[type="email"]')).toBeFocused();
    
    await page.keyboard.press('Tab');
    await expect(page.locator('input[type="password"]')).toBeFocused();
    
    await page.keyboard.press('Tab');
    await expect(page.locator('input[type="checkbox"]')).toBeFocused();
    
    // Submit with Enter key
    await page.fill('input[type="email"]', 'test@example.com');
    await page.fill('input[type="password"]', 'password123');
    await page.keyboard.press('Enter');
    
    await expect(page).toHaveURL(/\/dashboard/);
  });
});