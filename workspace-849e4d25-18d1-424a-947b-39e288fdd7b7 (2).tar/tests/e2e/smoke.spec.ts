import { test, expect } from '@playwright/test';

test.describe('AI Pathfinders 2025 - Smoke Tests', () => {
  test.beforeEach(async ({ page }) => {
    // Navigate to the home page
    await page.goto('/');
  });

  test('home page loads correctly', async ({ page }) => {
    // Check that the page loads
    await expect(page).toHaveTitle(/AI Pathfinders 2025/);
    
    // Check main elements are visible
    await expect(page.locator('h1')).toBeVisible();
    await expect(page.locator('text=Conviértete en Experto en IA')).toBeVisible();
    
    // Check navigation is present
    await expect(page.locator('header')).toBeVisible();
    await expect(page.locator('text=Módulos')).toBeVisible();
    await expect(page.locator('text=Tendencias')).toBeVisible();
  });

  test('navigation links work correctly', async ({ page }) => {
    // Test Modules link
    await page.click('text=Módulos');
    await expect(page).toHaveURL('/modules');
    await expect(page.locator('text=Módulos de Aprendizaje')).toBeVisible();
    
    // Go back to home
    await page.click('text=Volver');
    await expect(page).toHaveURL('/');
    
    // Test Trends link
    await page.click('text=Tendencias');
    await expect(page).toHaveURL('/trends');
    await expect(page.locator('text=Tendencias IA 2025')).toBeVisible();
    
    // Go back to home
    await page.click('text=Inicio');
    await expect(page).toHaveURL('/');
  });

  test('CTA buttons work correctly', async ({ page }) => {
    // Test main CTA button
    await page.click('text=Explorar Módulos');
    await expect(page).toHaveURL('/modules');
    
    // Check modules page loaded
    await expect(page.locator('text=Módulos de Aprendizaje')).toBeVisible();
    
    // Test module cards are present
    const moduleCards = page.locator('.bg-[#1e202f]').filter({ hasText: 'Fundamentos de IA' });
    await expect(moduleCards).toBeVisible();
    
    // Test individual module button
    await page.locator('text=Ver Módulo').first().click();
    await expect(page).toHaveURL(/\/modules\/.+/);
  });

  test('modules page loads and displays data', async ({ page }) => {
    // Navigate to modules page
    await page.click('text=Módulos');
    await expect(page).toHaveURL('/modules');
    
    // Check modules are loaded from API
    await expect(page.locator('text=Módulos de Aprendizaje')).toBeVisible();
    
    // Wait for modules to load
    await page.waitForSelector('text=Fundamentos de IA', { state: 'visible' });
    
    // Check that modules are displayed
    const modules = page.locator('.grid > div > .bg-[#1e202f]');
    await expect(modules).toHaveCount(1);
    
    // Check module details are visible
    await expect(page.locator('text=Lecciones')).toBeVisible();
    await expect(page.locator('text=Prácticas')).toBeVisible();
    await expect(page.locator('text=Preguntas')).toBeVisible();
  });

  test('trends page loads and displays data', async ({ page }) => {
    // Navigate to trends page
    await page.click('text=Tendencias');
    await expect(page).toHaveURL('/trends');
    
    // Check trends page loaded
    await expect(page.locator('text=Tendencias IA 2025')).toBeVisible();
    
    // Wait for trends to load or show error
    await page.waitForSelector('text=Artículos', { state: 'visible', timeout: 10000 });
    
    // Check that trends are displayed or error message is shown
    const trendsGrid = page.locator('.grid > div > .bg-[#1e202f]');
    const errorMessage = page.locator('text=Error al cargar tendencias');
    
    // Either trends should be visible or error message
    const trendsVisible = await trendsGrid.count() > 0;
    const errorVisible = await errorMessage.isVisible();
    
    expect(trendsVisible || errorVisible).toBeTruthy();
    
    // Test retry button if error is shown
    if (await errorMessage.isVisible()) {
      await expect(page.locator('text=Reintentar')).toBeVisible();
    }
  });

  test('responsive design works on mobile', async ({ page }) => {
    // Set mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });
    
    // Check home page is responsive
    await expect(page.locator('h1')).toBeVisible();
    await expect(page.locator('text=Explorar Módulos')).toBeVisible();
    
    // Test navigation on mobile
    await page.click('text=Módulos');
    await expect(page).toHaveURL('/modules');
    
    // Check modules are accessible on mobile
    await expect(page.locator('text=Módulos de Aprendizaje')).toBeVisible();
    
    // Go back to trends
    await page.click('text=Tendencias');
    await expect(page).toHaveURL('/trends');
    
    // Check trends are accessible on mobile
    await expect(page.locator('text=Tendencias IA 2025')).toBeVisible();
  });

  test('login and register buttons work', async ({ page }) => {
    // Test register button
    await page.click('text=Registrarse');
    await expect(page).toHaveURL('/auth/register');
    await expect(page.locator('text=Crear Cuenta')).toBeVisible();
    
    // Go back to home
    await page.click('text=Volver');
    await expect(page).toHaveURL('/');
    
    // Test login button
    await page.click('text=Iniciar Sesión');
    await expect(page).toHaveURL('/auth/login');
    await expect(page.locator('text=Iniciar Sesión')).toBeVisible();
  });

  test('page layout and containers are consistent', async ({ page }) => {
    // Check main container exists
    const mainContainer = page.locator('.mx-auto.max-w-screen-xl');
    await expect(mainContainer).toBeVisible();
    
    // Check padding is consistent
    const containerWithPadding = page.locator('.px-4.sm\\:px-6.lg\\:px-8');
    await expect(containerWithPadding).toHaveCount(1);
    
    // Test on modules page
    await page.click('text=Módulos');
    const modulesContainer = page.locator('.mx-auto.max-w-screen-xl');
    await expect(modulesContainer).toBeVisible();
    
    // Test on trends page
    await page.click('text=Tendencias');
    const trendsContainer = page.locator('.mx-auto.max-w-screen-xl');
    await expect(trendsContainer).toBeVisible();
  });

  test('no pointer events blocked', async ({ page }) => {
    // Test that interactive elements are clickable
    await expect(page.locator('text=Explorar Módulos')).toBeVisible();
    await expect(page.locator('text=Módulos')).toBeVisible();
    await expect(page.locator('text=Tendencias')).toBeVisible();
    await expect(page.locator('text=Registrarse')).toBeVisible();
    await expect(page.locator('text=Iniciar Sesión')).toBeVisible();
    
    // Test clicking multiple elements
    await page.click('text=Módulos');
    await expect(page).toHaveURL('/modules');
    
    await page.click('text=Tendencias');
    await expect(page).toHaveURL('/trends');
    
    await page.click('text=Inicio');
    await expect(page).toHaveURL('/');
  });

  test.afterEach(async ({ page }) => {
    // Clean up by going back to home page
    await page.goto('/');
  });
});