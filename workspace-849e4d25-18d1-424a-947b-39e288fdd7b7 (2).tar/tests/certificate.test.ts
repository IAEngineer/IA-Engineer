import { describe, it, expect, beforeEach } from 'vitest';
import { CertificateGenerator, CertificateData } from '../src/lib/certificate';

describe('CertificateGenerator', () => {
  let mockCertificateData: CertificateData;

  beforeEach(() => {
    mockCertificateData = {
      userName: 'Juan Pérez',
      moduleName: 'Fundamentos de IA',
      completionDate: '2025-01-15T00:00:00Z',
      score: 85,
      certificateId: 'cert-12345'
    };
  });

  describe('generateCertificateSVG', () => {
    it('should generate valid SVG string', () => {
      const svg = CertificateGenerator.generateCertificateSVG(mockCertificateData);
      
      expect(svg).toContain('<svg');
      expect(svg).toContain('Juan Pérez');
      expect(svg).toContain('Fundamentos de IA');
      expect(svg).toContain('85%');
      expect(svg).toContain('cert-12345');
    });

    it('should include required elements', () => {
      const svg = CertificateGenerator.generateCertificateSVG(mockCertificateData);
      
      expect(svg).toContain('AI Pathfinders 2025');
      expect(svg).toContain('CERTIFICADO DE COMPLETACIÓN');
      expect(svg).toContain('Ha completado exitosamente el módulo');
      expect(svg).toContain('Con una puntuación de');
    });

    it('should include decorative elements', () => {
      const svg = CertificateGenerator.generateCertificateSVG(mockCertificateData);
      
      expect(svg).toContain('linearGradient');
      expect(svg).toContain('circle');
      expect(svg).toContain('rect');
    });

    it('should handle special characters in user name', () => {
      const dataWithSpecialChars = {
        ...mockCertificateData,
        userName: 'María José García'
      };
      
      const svg = CertificateGenerator.generateCertificateSVG(dataWithSpecialChars);
      expect(svg).toContain('María José García');
    });

    it('should handle long module names', () => {
      const dataWithLongName = {
        ...mockCertificateData,
        moduleName: 'Módulo muy largo con un nombre extremadamente extenso que debería ser manejado correctamente'
      };
      
      const svg = CertificateGenerator.generateCertificateSVG(dataWithLongName);
      expect(svg).toContain(dataWithLongName.moduleName);
    });
  });

  describe('generateCertificateCanvas', () => {
    it('should create canvas element', () => {
      const canvas = CertificateGenerator.generateCertificateCanvas(mockCertificateData);
      
      expect(canvas).toBeInstanceOf(HTMLCanvasElement);
      expect(canvas.width).toBe(800);
      expect(canvas.height).toBe(600);
    });

    it('should have 2d context', () => {
      const canvas = CertificateGenerator.generateCertificateCanvas(mockCertificateData);
      const ctx = canvas.getContext('2d');
      
      expect(ctx).not.toBeNull();
    });

    it('should throw error if context cannot be obtained', () => {
      // Mock canvas to return null context
      const originalCreateElement = document.createElement;
      document.createElement = (tagName: string) => {
        if (tagName === 'canvas') {
          const canvas = originalCreateElement.call(document, tagName) as HTMLCanvasElement;
          canvas.getContext = () => null;
          return canvas;
        }
        return originalCreateElement.call(document, tagName);
      };

      expect(() => {
        CertificateGenerator.generateCertificateCanvas(mockCertificateData);
      }).toThrow('Could not get canvas context');

      // Restore original method
      document.createElement = originalCreateElement;
    });
  });

  describe('downloadCertificate', () => {
    it('should create download link and trigger download', () => {
      const mockCreateElement = vi.fn();
      const mockAppendChild = vi.fn();
      const mockRemoveChild = vi.fn();
      const mockClick = vi.fn();
      const mockRevokeObjectURL = vi.fn();

      // Mock DOM methods
      global.Blob = vi.fn().mockImplementation((content) => ({ size: content[0].length }));
      global.URL = {
        createObjectURL: vi.fn().mockReturnValue('blob:mock-url'),
        revokeObjectURL: mockRevokeObjectURL
      };

      const mockLink = {
        href: '',
        download: '',
        click: mockClick,
        style: {}
      };

      document.createElement = mockCreateElement.mockReturnValue(mockLink);
      document.body = {
        appendChild: mockAppendChild,
        removeChild: mockRemoveChild
      } as any;

      CertificateGenerator.downloadCertificate(mockCertificateData);

      expect(mockCreateElement).toHaveBeenCalledWith('a');
      expect(mockAppendChild).toHaveBeenCalledWith(mockLink);
      expect(mockClick).toHaveBeenCalled();
      expect(mockRemoveChild).toHaveBeenCalledWith(mockLink);
      expect(mockRevokeObjectURL).toHaveBeenCalledWith('blob:mock-url');

      // Cleanup
      delete global.Blob;
      delete global.URL;
    });
  });

  describe('downloadCertificateAsPNG', () => {
    it('should create canvas and trigger PNG download', () => {
      const mockCreateElement = vi.fn();
      const mockAppendChild = vi.fn();
      const mockRemoveChild = vi.fn();
      const mockClick = vi.fn();
      const mockToDataURL = vi.fn().mockReturnValue('data:image/png;base64,mock-data');

      // Mock canvas
      const mockCanvas = {
        width: 800,
        height: 600,
        getContext: () => ({}),
        toDataURL: mockToDataURL
      } as HTMLCanvasElement;

      // Mock DOM methods
      document.createElement = mockCreateElement.mockReturnValue(mockCanvas);
      global.URL = {
        createObjectURL: vi.fn().mockReturnValue('blob:mock-url'),
        revokeObjectURL: vi.fn()
      };

      const mockLink = {
        href: '',
        download: '',
        click: mockClick,
        style: {}
      };

      mockCreateElement.mockReturnValueOnce(mockCanvas).mockReturnValueOnce(mockLink);
      document.body = {
        appendChild: mockAppendChild,
        removeChild: mockRemoveChild
      } as any;

      CertificateGenerator.downloadCertificateAsPNG(mockCertificateData);

      expect(mockCreateElement).toHaveBeenCalledWith('canvas');
      expect(mockToDataURL).toHaveBeenCalledWith('image/png');
      expect(mockCreateElement).toHaveBeenCalledWith('a');
      expect(mockAppendChild).toHaveBeenCalledWith(mockLink);
      expect(mockClick).toHaveBeenCalled();
      expect(mockRemoveChild).toHaveBeenCalledWith(mockLink);

      // Cleanup
      delete global.URL;
    });
  });

  describe('shareCertificate', () => {
    it('should open Twitter share intent', () => {
      const mockWindowOpen = vi.fn();
      global.window = {
        ...global.window,
        open: mockWindowOpen,
        location: { origin: 'https://example.com' }
      } as any;

      CertificateGenerator.shareCertificate(mockCertificateData);

      expect(mockWindowOpen).toHaveBeenCalledWith(
        expect.stringContaining('twitter.com/intent/tweet'),
        '_blank',
        expect.any(Object)
      );

      expect(mockWindowOpen.mock.calls[0][0]).toContain('He completado el módulo');
      expect(mockWindowOpen.mock.calls[0][0]).toContain('Fundamentos de IA');
      expect(mockWindowOpen.mock.calls[0][0]).toContain('85%');
    });

    it('should include proper encoding', () => {
      const mockWindowOpen = vi.fn();
      global.window = {
        ...global.window,
        open: mockWindowOpen,
        location: { origin: 'https://example.com' }
      } as any;

      const dataWithSpecialChars = {
        ...mockCertificateData,
        userName: 'María José',
        moduleName: 'IA & Machine Learning'
      };

      CertificateGenerator.shareCertificate(dataWithSpecialChars);

      expect(mockWindowOpen.mock.calls[0][0]).toContain('Mar%C3%ADa%20Jos%C3%A9');
      expect(mockWindowOpen.mock.calls[0][0]).toContain('IA%20%26%20Machine%20Learning');
    });
  });

  describe('edge cases', () => {
    it('should handle empty user name', () => {
      const emptyData = {
        ...mockCertificateData,
        userName: ''
      };

      const svg = CertificateGenerator.generateCertificateSVG(emptyData);
      expect(svg).toContain('name: ""');
    });

    it('should handle maximum score', () => {
      const perfectScoreData = {
        ...mockCertificateData,
        score: 100
      };

      const svg = CertificateGenerator.generateCertificateSVG(perfectScoreData);
      expect(svg).toContain('100%');
    });

    it('should handle minimum score', () => {
      const minimumScoreData = {
        ...mockCertificateData,
        score: 0
      };

      const svg = CertificateGenerator.generateCertificateSVG(minimumScoreData);
      expect(svg).toContain('0%');
    });

    it('should handle special certificate ID', () => {
      const specialIdData = {
        ...mockCertificateData,
        certificateId: 'cert-with-special-chars_123!@#$%'
      };

      const svg = CertificateGenerator.generateCertificateSVG(specialIdData);
      expect(svg).toContain('cert-with-special-chars_123!@#$%');
    });
  });
});