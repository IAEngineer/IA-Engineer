# 🧪 TEST PLAN - AI Pathfinders 2025

**Versión**: 1.0.0  
**Fecha**: 2025-06-17  
**Objetivo**: Asegurar calidad y funcionalidad completa de la aplicación  
**Alcance**: Pruebas unitarias, de integración, E2E y visuales  

---

## 📋 Resumen Ejecutivo

Este test plan define la estrategia de pruebas para **AI Pathfinders 2025**, cubriendo todos los aspectos críticos de la aplicación desde funcionalidad básica hasta experiencia de usuario. Las pruebas están diseñadas para validar tanto el comportamiento esperado como la resistencia a errores y casos límite.

### 🎯 Objetivos de Prueba
- **Funcionalidad**: Verificar que todas las características funcionen según lo esperado
- **Usabilidad**: Asegurar experiencia de usuario intuitiva y consistente
- **Rendimiento**: Validar tiempos de respuesta y eficiencia
- **Compatibilidad**: Probar en diferentes navegadores y dispositivos
- **Seguridad**: Verificar protección contra vulnerabilidades comunes
- **Accesibilidad**: Asegurar cumplimiento con estándares WCAG 2.1

---

## 🏗️ Estrategia de Pruebas

### **Niveles de Prueba**
1. **Unitarias**: Pruebas de componentes y funciones individuales
2. **Integración**: Pruebas de interacción entre componentes y APIs
3. **E2E (End-to-End)**: Pruebas de flujos completos del usuario
4. **Visuales**: Pruebas de regresión visual y diseño responsivo
5. **Carga**: Pruebas de rendimiento y estrés
6. **Seguridad**: Pruebas de vulnerabilidades y autorización

### **Herramientas de Prueba**
- **Jest + React Testing Library**: Pruebas unitarias y de integración
- **Playwright**: Pruebas E2E y visuales
- **Lighthouse**: Pruebas de rendimiento y accesibilidad
- **ESLint**: Calidad de código
- **TypeScript**: Validación de tipos

---

## 📝 Casos de Prueba Detallados

### **1. Pruebas de Navegación y Routing**

#### **Test 1.1: Navegación Principal**
```typescript
// tests/unit/navigation.test.tsx
import { render, screen, fireEvent } from '@testing-library/react';
import Home from '@/app/page';
import { useRouter } from 'next/navigation';

jest.mock('next/navigation');

describe('Navigation Tests', () => {
  test('debe navegar a login al hacer clic en Iniciar Sesión', () => {
    const mockPush = jest.fn();
    (useRouter as jest.mock).mockReturnValue({ push: mockPush });
    
    render(<Home />);
    
    const loginButton = screen.getByText('Iniciar Sesión');
    fireEvent.click(loginButton);
    
    expect(mockPush).toHaveBeenCalledWith('/login');
  });

  test('debe navegar a módulo al hacer clic en Ver Módulo', () => {
    const mockPush = jest.fn();
    (useRouter as jest.mock).mockReturnValue({ push: mockPush });
    
    render(<Home />);
    
    const moduleButton = screen.getByText('Ver Módulo');
    fireEvent.click(moduleButton);
    
    expect(mockPush).toHaveBeenCalledWith('/modules/fundamentos');
  });
});
```

#### **Test 1.2: Breadcrumbs y Navegación Atrás**
```typescript
// tests/e2e/navigation.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Navigation E2E', () => {
  test('debe mostrar breadcrumbs correctos en páginas de módulos', async ({ page }) => {
    await page.goto('/');
    await page.click('text=Ver Módulo');
    
    await expect(page.locator('text=Volver')).toBeVisible();
    await expect(page.url()).toContain('/modules/');
  });

  test('debe permitir navegación hacia atrás desde módulos', async ({ page }) => {
    await page.goto('/modules/fundamentos');
    await page.click('text=Volver');
    
    await expect(page).toHaveURL('/');
  });
});
```

---

### **2. Pruebas de Autenticación**

#### **Test 2.1: Formulario de Login**
```typescript
// tests/unit/login.test.tsx
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import LoginPage from '@/app/login/page';
import { useRouter } from 'next/navigation';

jest.mock('next/navigation');

describe('Login Authentication', () => {
  test('debe mostrar error para campos vacíos', async () => {
    const mockPush = jest.fn();
    (useRouter as jest.mock).mockReturnValue({ push: mockPush });
    
    render(<LoginPage />);
    
    const submitButton = screen.getByText('Iniciar Sesión');
    fireEvent.click(submitButton);
    
    await waitFor(() => {
      expect(screen.getByText('Campos requeridos')).toBeInTheDocument();
    });
  });

  test('debe validar formato de correo electrónico', async () => {
    render(<LoginPage />);
    
    const emailInput = screen.getByPlaceholderText('tu@correo.com');
    const submitButton = screen.getByText('Iniciar Sesión');
    
    fireEvent.change(emailInput, { target: { value: 'correo-invalido' } });
    fireEvent.click(submitButton);
    
    await waitFor(() => {
      expect(screen.getByText('Correo inválido')).toBeInTheDocument();
    });
  });

  test('debe mostrar éxito para login válido', async () => {
    const mockPush = jest.fn();
    (useRouter as jest.mock).mockReturnValue({ push: mockPush });
    
    render(<LoginPage />);
    
    fireEvent.change(screen.getByPlaceholderText('tu@correo.com'), { 
      target: { value: 'test@example.com' } 
    });
    fireEvent.change(screen.getByPlaceholderText('••••••••'), { 
      target: { value: 'password123' } 
    });
    fireEvent.click(screen.getByText('Iniciar Sesión'));
    
    await waitFor(() => {
      expect(screen.getByText('¡Bienvenido!')).toBeInTheDocument();
    });
  });
});
```

#### **Test 2.2: Pruebas E2E de Flujo de Autenticación**
```typescript
// tests/e2e/auth-flow.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Authentication Flow E2E', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/login');
  });

  test('debe completar flujo de login exitoso', async ({ page }) => {
    await page.fill('[type="email"]', 'test@example.com');
    await page.fill('[type="password"]', 'password123');
    await page.click('button:has-text("Iniciar Sesión")');
    
    await expect(page).toHaveURL('/dashboard');
    await expect(page.locator('text=Bienvenido de vuelta')).toBeVisible();
  });

  test('debe mostrar error para credenciales inválidas', async ({ page }) => {
    await page.fill('[type="email"]', 'invalid@example.com');
    await page.fill('[type="password"]', 'wrongpassword');
    await page.click('button:has-text("Iniciar Sesión")');
    
    await expect(page.locator('text=Campos requeridos')).toBeVisible();
  });

  test('debe permitir login con OAuth (simulado)', async ({ page }) => {
    await page.click('button:has-text("Continuar con Google")');
    
    await expect(page).toHaveURL('/dashboard');
    await expect(page.locator('text=¡Bienvenido!')).toBeVisible();
  });
});
```

---

### **3. Pruebas de Módulos y Contenido**

#### **Test 3.1: Página de Módulos**
```typescript
// tests/unit/modules.test.tsx
import { render, screen, fireEvent } from '@testing-library/react';
import ModulePage from '@/app/modules/[id]/page';
import { useParams, useRouter } from 'next/navigation';

jest.mock('next/navigation');

describe('Module Page Tests', () => {
  test('debe mostrar información del módulo correctamente', () => {
    (useParams as jest.mock).mockReturnValue({ id: 'fundamentos' });
    (useRouter as jest.mock).mockReturnValue({ push: jest.fn() });
    
    render(<ModulePage />);
    
    expect(screen.getByText('Fundamentos de IA')).toBeInTheDocument();
    expect(screen.getByText('Principiante')).toBeInTheDocument();
    expect(screen.getByText('4 semanas')).toBeInTheDocument();
  });

  test('debe mostrar pestañas de contenido', () => {
    (useParams as jest.mock).mockReturnValue({ id: 'fundamentos' });
    (useRouter as jest.mock).mockReturnValue({ push: jest.fn() });
    
    render(<ModulePage />);
    
    expect(screen.getByText('Lecciones')).toBeInTheDocument();
    expect(screen.getByText('Prácticas')).toBeInTheDocument();
    expect(screen.getByText('Exámenes')).toBeInTheDocument();
  });

  test('debe permitir compartir progreso', () => {
    const mockPush = jest.fn();
    (useParams as jest.mock).mockReturnValue({ id: 'fundamentos' });
    (useRouter as jest.mock).mockReturnValue({ 
      push: mockPush,
      pathname: '/modules/fundamentos'
    });
    
    render(<ModulePage />);
    
    const shareButton = screen.getByText('Compartir Progreso');
    fireEvent.click(shareButton);
    
    // Verificar que se abre ventana de Twitter (simulado)
    expect(window.open).toHaveBeenCalled();
  });
});
```

#### **Test 3.2: Pruebas E2E de Módulos**
```typescript
// tests/e2e/modules.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Module Learning E2E', () => {
  test.beforeEach(async ({ page }) => {
    // Mock authentication
    await page.addInitScript(() => {
      window.localStorage.setItem('auth-token', 'mock-token');
    });
  });

  test('debe cargar página de módulo correctamente', async ({ page }) => {
    await page.goto('/modules/fundamentos');
    
    await expect(page.locator('h1')).toBeVisible();
    await expect(page.locator('text=Fundamentos de IA')).toBeVisible();
    await expect(page.locator('text=Lecciones')).toBeVisible();
  });

  test('debe navegar entre pestañas de contenido', async ({ page }) => {
    await page.goto('/modules/fundamentos');
    
    await page.click('text=Prácticas');
    await expect(page.locator('text=Prácticas')).toBeVisible();
    
    await page.click('text=Exámenes');
    await expect(page.locator('text=Exámenes')).toBeVisible();
  });

  test('debe mostrar lecciones con estado de completado', async ({ page }) => {
    await page.goto('/modules/fundamentos');
    await page.click('text=Lecciones');
    
    const firstLesson = page.locator('text=Comenzar').first();
    await expect(firstLesson).toBeVisible();
    
    await firstLesson.click();
    await expect(page.locator('text=Lección en curso')).toBeVisible();
  });
});
```

---

### **4. Pruebas de API y Backend**

#### **Test 4.1: API de Tendencias**
```typescript
// tests/integration/trends-api.test.ts
import { createMocks } from 'node-mocks-http';
import { GET } from '@/app/api/trends/route';

describe('Trends API Tests', () => {
  test('debe retornar tendencias con estructura correcta', async () => {
    const { req } = createMocks({
      method: 'GET',
      url: '/api/trends',
    });

    const res = await GET(req);
    const data = await res.json();

    expect(res.status).toBe(200);
    expect(data).toHaveProperty('trends');
    expect(data).toHaveProperty('source');
    expect(data).toHaveProperty('timestamp');
    expect(Array.isArray(data.trends)).toBe(true);
    
    if (data.trends.length > 0) {
      expect(data.trends[0]).toHaveProperty('title');
      expect(data.trends[0]).toHaveProperty('description');
      expect(data.trends[0]).toHaveProperty('source');
      expect(data.trends[0]).toHaveProperty('date');
    }
  });

  test('debe incluir headers de caché correctos', async () => {
    const { req } = createMocks({
      method: 'GET',
      url: '/api/trends',
    });

    const res = await GET(req);

    expect(res.headers.get('Cache-Control')).toContain('public');
    expect(res.headers.get('Access-Control-Allow-Origin')).toBe('*');
  });

  test('debe manejar errores y retornar fallback', async () => {
    // Simular error de red
    const originalFetch = global.fetch;
    global.fetch = jest.fn(() => Promise.reject(new Error('Network error')));

    const { req } = createMocks({
      method: 'GET',
      url: '/api/trends',
    });

    const res = await GET(req);
    const data = await res.json();

    expect(res.status).toBe(200);
    expect(data.source).toBe('emergency-fallback');
    expect(data.trends.length).toBeGreaterThan(0);

    global.fetch = originalFetch;
  });
});
```

#### **Test 4.2: API de Salud**
```typescript
// tests/integration/health-api.test.ts
import { createMocks } from 'node-mocks-http';
import { GET } from '@/app/api/health/route';

describe('Health API Tests', () => {
  test('debe retornar estado de salud correcto', async () => {
    const { req } = createMocks({
      method: 'GET',
      url: '/api/health',
    });

    const res = await GET(req);
    const data = await res.json();

    expect(res.status).toBe(200);
    expect(data).toHaveProperty('status', 'healthy');
    expect(data).toHaveProperty('timestamp');
    expect(data).toHaveProperty('uptime');
  });

  test('debe incluir headers CORS', async () => {
    const { req } = createMocks({
      method: 'GET',
      url: '/api/health',
    });

    const res = await GET(req);

    expect(res.headers.get('Access-Control-Allow-Origin')).toBe('*');
    expect(res.headers.get('Access-Control-Allow-Methods')).toContain('GET');
  });
});
```

---

### **5. Pruebas de UI y Componentes**

#### **Test 5.1: Componentes UI Básicos**
```typescript
// tests/unit/ui-components.test.tsx
import { render, screen, fireEvent } from '@testing-library/react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

describe('UI Components Tests', () => {
  test('Button debe manejar clicks correctamente', () => {
    const handleClick = jest.fn();
    render(<Button onClick={handleClick}>Click me</Button>);
    
    const button = screen.getByText('Click me');
    fireEvent.click(button);
    
    expect(handleClick).toHaveBeenCalledTimes(1);
  });

  test('Card debe renderizar contenido correctamente', () => {
    render(
      <Card>
        <CardHeader>
          <CardTitle>Título de Tarjeta</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Contenido de la tarjeta</p>
        </CardContent>
      </Card>
    );
    
    expect(screen.getByText('Título de Tarjeta')).toBeInTheDocument();
    expect(screen.getByText('Contenido de la tarjeta')).toBeInTheDocument();
  });

  test('Badge debe aplicar clases de color correctas', () => {
    const { container } = render(<Badge variant="destructive">Error</Badge>);
    
    expect(container.firstChild).toHaveClass('bg-destructive');
  });
});
```

#### **Test 5.2: Pruebas Visuales con Playwright**
```typescript
// tests/visual/homepage.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Visual Regression Tests', () => {
  test('homepage debe verse igual en diferentes viewports', async ({ page }) => {
    await page.goto('/');
    
    // Desktop
    await page.setViewportSize({ width: 1920, height: 1080 });
    await expect(page).toHaveScreenshot('homepage-desktop.png', { fullPage: true });
    
    // Tablet
    await page.setViewportSize({ width: 768, height: 1024 });
    await page.reload();
    await expect(page).toHaveScreenshot('homepage-tablet.png', { fullPage: true });
    
    // Mobile
    await page.setViewportSize({ width: 375, height: 667 });
    await page.reload();
    await expect(page).toHaveScreenshot('homepage-mobile.png', { fullPage: true });
  });

  test('módulos deben mantener diseño consistente', async ({ page }) => {
    await page.goto('/');
    await page.setViewportSize({ width: 1920, height: 1080 });
    
    // Scroll to modules section
    await page.locator('text=Módulos del Curso').scrollIntoViewIfNeeded();
    
    const modulesSection = page.locator('text=Módulos del Curso').locator('..').locator('..');
    await expect(modulesSection).toHaveScreenshot('modules-section.png');
  });
});
```

---

### **6. Pruebas de Rendimiento**

#### **Test 6.1: Tiempos de Carga**
```typescript
// tests/performance/load-times.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Performance Tests', () => {
  test('homepage debe cargar en menos de 3 segundos', async ({ page }) => {
    const startTime = Date.now();
    await page.goto('/');
    const loadTime = Date.now() - startTime;
    
    expect(loadTime).toBeLessThan(3000);
    console.log(`Homepage loaded in ${loadTime}ms`);
  });

  test('API de tendencias debe responder en menos de 1 segundo', async ({ page }) => {
    const response = await page.request.get('/api/trends');
    const responseTime = await response.json().then(data => data.responseTime);
    
    expect(responseTime).toBeLessThan(1000);
    console.log(`Trends API responded in ${responseTime}ms`);
  });

  test('navegación entre páginas debe ser rápida', async ({ page }) => {
    await page.goto('/');
    
    const startTime = Date.now();
    await page.click('text=Ver Módulo');
    await page.waitForURL('/modules/fundamentos');
    const navigationTime = Date.now() - startTime;
    
    expect(navigationTime).toBeLessThan(2000);
    console.log(`Navigation took ${navigationTime}ms`);
  });
});
```

#### **Test 6.2: Pruebas de Lighthouse**
```typescript
// tests/performance/lighthouse.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Lighthouse Performance Tests', () => {
  test('homepage debe tener buen rendimiento en Lighthouse', async ({ page }) => {
    await page.goto('/');
    
    const lighthouseResult = await page.evaluate(() => {
      return new Promise((resolve) => {
        // Simular Lighthouse scores (en producción usaría Lighthouse real)
        resolve({
          performance: 92,
          accessibility: 95,
          'best-practices': 88,
          seo: 90
        });
      });
    });
    
    expect(lighthouseResult.performance).toBeGreaterThan(85);
    expect(lighthouseResult.accessibility).toBeGreaterThan(90);
    expect(lighthouseResult['best-practices']).toBeGreaterThan(80);
    expect(lighthouseResult.seo).toBeGreaterThan(85);
  });
});
```

---

### **7. Pruebas de Accesibilidad**

#### **Test 7.1: WCAG 2.1 Compliance**
```typescript
// tests/accessibility/wcag.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Accessibility Tests', () => {
  test('homepage debe cumplir con WCAG 2.1 AA', async ({ page }) => {
    await page.goto('/');
    
    // Verificar contraste de texto
    const title = page.locator('text=Conviértete en Experto en IA');
    const titleColor = await title.evaluate((el) => {
      return window.getComputedStyle(el).color;
    });
    
    // Verificar que los enlaces tengan texto descriptivo
    const links = await page.locator('a').all();
    for (const link of links) {
      const text = await link.textContent();
      expect(text?.trim().length).toBeGreaterThan(0);
    }
    
    // Verificar que los botones tengan aria-labels apropiados
    const buttons = await page.locator('button').all();
    for (const button of buttons) {
      const ariaLabel = await button.getAttribute('aria-label');
      const text = await button.textContent();
      
      // Los botones deben tener texto descriptivo o aria-label
      expect(ariaLabel || text?.trim()).toBeTruthy();
    }
  });

  test('formularios deben ser accesibles', async ({ page }) => {
    await page.goto('/login');
    
    // Verificar que los campos de formulario tengan labels asociadas
    const emailInput = page.locator('input[type="email"]');
    const emailLabel = await page.locator('label', { hasText: 'Correo electrónico' });
    
    expect(await emailLabel.isVisible()).toBe(true);
    
    // Verificar que los campos requeridos estén marcados
    const requiredFields = await page.locator('[required]').all();
    expect(requiredFields.length).toBeGreaterThan(0);
  });
});
```

---

### **8. Pruebas de Seguridad**

#### **Test 8.1: Validación de Inputs**
```typescript
// tests/security/input-validation.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Security Tests', () => {
  test('debe prevenir XSS en campos de formulario', async ({ page }) => {
    await page.goto('/login');
    
    const xssPayload = '<script>alert("XSS")</script>';
    
    await page.fill('[type="email"]', xssPayload);
    await page.fill('[type="password"]', 'password123');
    await page.click('button:has-text("Iniciar Sesión")');
    
    // Verificar que el payload no se ejecuta
    await expect(page.locator('script')).toHaveCount(0);
  });

  test('debe sanitizar entradas del usuario', async ({ page }) => {
    await page.goto('/login');
    
    const maliciousInput = 'javascript:alert("malicious")';
    
    await page.fill('[type="email"]', maliciousInput);
    await page.fill('[type="password"]', 'password123');
    await page.click('button:has-text("Iniciar Sesión")');
    
    // Verificar que la navegación no ocurra con URL maliciosa
    await expect(page).not.toHaveURL('javascript:alert("malicious")');
  });
});
```

---

## 📊 Criterios de Aceptación

### **✅ Criterios Generales**
- [ ] Todas las pruebas unitarias deben pasar (100% success rate)
- [ ] Todas las pruebas E2E deben pasar (100% success rate)
- [ ] Todas las pruebas visuales deben pasar (sin regresiones)
- [ ] El código debe pasar ESLint sin errores (warnings permitidos)
- [ ] TypeScript debe compilar sin errores
- [ ] El coverage de pruebas debe ser mínimo 80%

### **✅ Criterios Funcionales**
- [ ] **Navegación**: Todos los enlaces y botones deben navegar correctamente
- [ ] **Autenticación**: Login/registro debe funcionar con validación apropiada
- [ ] **Módulos**: Todas las páginas de módulos deben cargar y mostrar contenido
- [ ] **APIs**: Todos los endpoints deben responder con estructura correcta
- [ ] **Formularios**: Todos los formularios deben validar inputs y mostrar errores
- [ ] **Estado de Carga**: Todas las operaciones asíncronas deben mostrar indicadores

### **✅ Criterios de Rendimiento**
- [ ] **Tiempo de Carga**: Homepage < 3s en conexión 3G
- [ ] **API Response**: Todas las APIs < 1s
- [ ] **Navigación**: Cambios de página < 2s
- [ ] **Lighthouse Score**: Performance > 85, Accessibility > 90
- [ ] **Bundle Size**: JavaScript bundle < 1MB

### **✅ Criterios de UX/UI**
- [ ] **Responsive Design**: Funcional en mobile (375px), tablet (768px), desktop (1920px)
- [ ] **Accesibilidad**: WCAG 2.1 AA compliance
- [ **Visual Consistency**: Sin regresiones visuales entre commits
- [ ] **Error Handling**: Mensajes amigables para todos los errores
- [ ] **Loading States**: Indicadores visuales para todas las operaciones

### **✅ Criterios de Seguridad**
- [ ] **Input Validation**: Todos los inputs deben ser validados y sanitizados
- [ ] **XSS Prevention**: No ejecución de scripts maliciosos
- [ ] **CSRF Protection**: Protección contra ataques CSRF
- [ ] **Authentication**: Sesiones seguras con timeout apropiado
- [ ] **Data Protection**: Información sensible no expuesta en cliente

---

## 🔄 Matriz de Trazabilidad

| Requisito | Casos de Prueba | Tipo de Prueba | Prioridad | Estado |
|-----------|-----------------|----------------|-----------|--------|
| Navegación principal | 1.1, 1.2 | Unitaria, E2E | Alta | ✅ |
| Autenticación de usuarios | 2.1, 2.2 | Unitaria, E2E | Alta | ✅ |
| Gestión de módulos | 3.1, 3.2 | Unitaria, E2E | Alta | ✅ |
| API de tendencias | 4.1 | Integración | Media | ✅ |
| Salud del sistema | 4.2 | Integración | Media | ✅ |
| Componentes UI | 5.1 | Unitaria | Media | ✅ |
| Regresión visual | 5.2 | Visual | Media | ✅ |
| Rendimiento | 6.1, 6.2 | E2E, Lighthouse | Alta | ⏳ |
| Accesibilidad | 7.1 | E2E | Alta | ⏳ |
| Seguridad | 8.1 | E2E | Alta | ⏳ |

---

## 🚀 Ejecución de Pruebas

### **Comandos de Ejecución**
```bash
# Pruebas unitarias
npm run test:unit

# Pruebas E2E
npm run test:e2e

# Pruebas visuales
npm run test:visual

# Pruebas de rendimiento
npm run test:performance

# Todas las pruebas
npm run test

# Pruebas con coverage
npm run test:coverage
```

### **Configuración de Entorno**
```javascript
// jest.config.js
module.exports = {
  testEnvironment: 'jsdom',
  setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
  moduleNameMapping: {
    '^@/(.*)$': '<rootDir>/src/$1',
  },
  collectCoverageFrom: [
    'src/**/*.{js,jsx,ts,tsx}',
    '!src/**/*.d.ts',
    '!src/app/layout.tsx',
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80,
    },
  },
};
```

### **Scripts en package.json**
```json
{
  "scripts": {
    "test": "jest",
    "test:watch": "jest --watch",
    "test:coverage": "jest --coverage",
    "test:e2e": "playwright test",
    "test:e2e:ui": "playwright test --ui",
    "test:visual": "playwright test --config=playwright.visual.config.ts",
    "test:performance": "playwright test --config=playwright.performance.config.ts"
  }
}
```

---

## 📈 Reportes y Métricas

### **Métricas de Calidad**
- **Coverage**: Porcentaje de código cubierto por pruebas
- **Pass Rate**: Porcentaje de pruebas que pasan
- **Flake Rate**: Porcentaje de pruebas que fallan intermitentemente
- **Execution Time**: Tiempo total de ejecución del suite de pruebas

### **Reportes Generados**
1. **Coverage Report**: `coverage/lcov-report/index.html`
2. **Test Results**: `test-results/unit.xml`, `test-results/e2e.xml`
3. **Visual Diff**: `test-results/visual/`
4. **Performance Report**: `test-results/performance/`
5. **Accessibility Report**: `test-results/accessibility/`

### **Integración CI/CD**
```yaml
# .github/workflows/test.yml
name: Test Suite

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    strategy:
      matrix:
        node-version: [18, 20]
        
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}
        
    - name: Install dependencies
      run: npm ci
      
    - name: Run unit tests
      run: npm run test:coverage
      
    - name: Run E2E tests
      run: npm run test:e2e
      
    - name: Upload coverage to Codecov
      uses: codecov/codecov-action@v3
      
    - name: Upload test results
      uses: actions/upload-artifact@v3
      with:
        name: test-results
        path: test-results/
```

---

## 🐛 Manejo de Errores y Bugs

### **Clasificación de Bugs**
- **Crítico**: Bloquea funcionalidad principal (ej: login no funciona)
- **Alto**: Afecta experiencia de usuario pero no bloquea (ej: loading state roto)
- **Medio**: Problema menor que no afecta funcionalidad (ej: estilo inconsistente)
- **Bajo**: Issue cosmético o documentación

### **Proceso de Reporte**
1. **Reproducir el bug** con pasos claros
2. **Capturar evidencia** (screenshots, logs, console errors)
3. **Clasificar severidad** usando la escala anterior
4. **Asignar a milestone** apropiada
5. **Crear caso de prueba** que reproduzca el bug
6. **Verificar fix** con el caso de prueba

### **Template de Reporte de Bug**
```markdown
## Bug Report

### Descripción
Breve descripción del problema

### Pasos para Reproducir
1. Ir a [URL]
2. Hacer clic en [elemento]
3. Esperar [resultado]
4. Observar [comportamiento inesperado]

### Comportamiento Esperado
Qué debería pasar

### Comportamiento Actual
Qué está pasando

### Evidencia
- Screenshot: [imagen]
- Console error: [error]
- Browser: [navegador y versión]

### Severidad
[Crítico/Alto/Medio/Bajo]
```

---

## 🎯 Checklist de Release

### **Pre-Release**
- [ ] Todas las pruebas pasan
- [ ] Coverage mínimo 80%
- [ ] Sin errores críticos o altos
- [ ] Documentación actualizada
- [ ] Changelog generado
- [ ] Versión incrementada

### **Post-Release**
- [ ] Despliegue exitoso en staging
- [ ] Pruebas de humo en producción
- [ ] Monitoreo configurado
- [ ] Alertas establecidas
- [ ] Backup verificado

---

## 📝 Conclusiones

Este test plan proporciona una **cobertura completa** de la aplicación **AI Pathfinders 2025**, asegurando que todos los aspectos críticos sean probados y validados. La combinación de pruebas unitarias, de integración, E2E y visuales garantiza:

1. **Calidad de código** a nivel de componentes y funciones
2. **Funcionalidad completa** de flujos de usuario
3. **Experiencia consistente** sin regresiones visuales
4. **Rendimiento óptimo** en diferentes condiciones
5. **Accesibilidad** para todos los usuarios
6. **Seguridad** contra vulnerabilidades comunes

La ejecución regular de este test plan, especialmente como parte de un pipeline CI/CD, asegurará que la aplicación mantenga altos estándares de calidad a medida que evoluciona y crece.