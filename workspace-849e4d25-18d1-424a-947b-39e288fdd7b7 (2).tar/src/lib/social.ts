'use client';

export interface SocialShareData {
  title: string;
  description: string;
  url: string;
  hashtags?: string[];
  via?: string;
}

export class SocialShareManager {
  static shareOnTwitter(data: SocialShareData): void {
    const { title, description, url, hashtags, via } = data;
    const text = `${title} - ${description}`;
    const hashtagString = hashtags ? `#${hashtags.join(' #')}` : '';
    const viaString = via ? `&via=${via}` : '';
    
    const tweetText = `${text} ${hashtagString}`;
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(tweetText)}&url=${encodeURIComponent(url)}${viaString}`;
    
    window.open(twitterUrl, '_blank', 'width=550,height=420,resizable=yes,scrollbars=yes');
  }

  static shareOnLinkedIn(data: SocialShareData): void {
    const { title, description, url } = data;
    
    const linkedInUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}&summary=${encodeURIComponent(description)}`;
    
    window.open(linkedInUrl, '_blank', 'width=550,height=420,resizable=yes,scrollbars=yes');
  }

  static shareOnFacebook(data: SocialShareData): void {
    const { url } = data;
    
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
    
    window.open(facebookUrl, '_blank', 'width=550,height=420,resizable=yes,scrollbars=yes');
  }

  static shareOnWhatsApp(data: SocialShareData): void {
    const { title, description, url } = data;
    const text = `${title} - ${description} ${url}`;
    
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
    
    window.open(whatsappUrl, '_blank');
  }

  static shareOnTelegram(data: SocialShareData): void {
    const { title, description, url } = data;
    const text = `${title} - ${description} ${url}`;
    
    const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
    
    window.open(telegramUrl, '_blank');
  }

  static copyToClipboard(data: SocialShareData): Promise<void> {
    const { title, description, url } = data;
    const text = `${title} - ${description} ${url}`;
    
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    } else {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      
      return new Promise((resolve, reject) => {
        try {
          document.execCommand('copy');
          resolve();
        } catch (err) {
          reject(err);
        } finally {
          document.body.removeChild(textArea);
        }
      });
    }
  }

  static shareByEmail(data: SocialShareData): void {
    const { title, description, url } = data;
    const subject = encodeURIComponent(title);
    const body = encodeURIComponent(`${description}\n\n${url}`);
    
    const emailUrl = `mailto:?subject=${subject}&body=${body}`;
    
    window.location.href = emailUrl;
  }

  static generateShareLinks(data: SocialShareData): Record<string, string> {
    const { title, description, url, hashtags, via } = data;
    const text = `${title} - ${description}`;
    const hashtagString = hashtags ? `#${hashtags.join(' #')}` : '';
    const viaString = via ? `&via=${via}` : '';
    
    return {
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}${viaString}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}&summary=${encodeURIComponent(description)}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
      whatsapp: `https://wa.me/?text=${encodeURIComponent(`${text} ${url}`)}`,
      telegram: `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`,
      email: `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(`${description}\n\n${url}`)}`
    };
  }

  static getSocialCounts(url: string): Promise<Record<string, number>> {
    // This would typically require API keys and backend services
    // For now, we'll return mock data
    return Promise.resolve({
      twitter: 0,
      linkedin: 0,
      facebook: 0
    });
  }
}