'use client';

export interface CertificateData {
  userName: string;
  moduleName: string;
  completionDate: string;
  score: number;
  certificateId: string;
}

export class CertificateGenerator {
  static generateCertificateSVG(data: CertificateData): string {
    const { userName, moduleName, completionDate, score, certificateId } = data;
    
    return `
      <svg width="800" height="600" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="bgGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:#1e202f;stop-opacity:1" />
            <stop offset="100%" style="stop-color:#2f2f32;stop-opacity:1" />
          </linearGradient>
          <linearGradient id="borderGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:#4FBDBA;stop-opacity:1" />
            <stop offset="100%" style="stop-color:#FFB703;stop-opacity:1" />
          </linearGradient>
          <filter id="shadow">
            <feDropShadow dx="2" dy="2" stdDeviation="3" flood-color="#000" flood-opacity="0.3"/>
          </filter>
        </defs>
        
        <!-- Background -->
        <rect width="800" height="600" fill="url(#bgGradient)"/>
        
        <!-- Border -->
        <rect x="20" y="20" width="760" height="560" fill="none" stroke="url(#borderGradient)" stroke-width="4" rx="10"/>
        
        <!-- Inner Border -->
        <rect x="40" y="40" width="720" height="520" fill="none" stroke="#4FBDBA" stroke-width="2" rx="5" opacity="0.5"/>
        
        <!-- Header -->
        <text x="400" y="100" text-anchor="middle" fill="#4FBDBA" font-family="Arial, sans-serif" font-size="28" font-weight="bold">
          AI Pathfinders 2025
        </text>
        
        <!-- Title -->
        <text x="400" y="150" text-anchor="middle" fill="white" font-family="Arial, sans-serif" font-size="36" font-weight="bold">
          CERTIFICADO DE COMPLETACIÓN
        </text>
        
        <!-- Subtitle -->
        <text x="400" y="190" text-anchor="middle" fill="#a7a8ae" font-family="Arial, sans-serif" font-size="18">
          Se certifica que
        </text>
        
        <!-- User Name -->
        <text x="400" y="250" text-anchor="middle" fill="white" font-family="Arial, sans-serif" font-size="32" font-weight="bold" filter="url(#shadow)">
          ${userName}
        </text>
        
        <!-- Achievement Text -->
        <text x="400" y="300" text-anchor="middle" fill="#a7a8ae" font-family="Arial, sans-serif" font-size="16">
          Ha completado exitosamente el módulo
        </text>
        
        <!-- Module Name -->
        <text x="400" y="340" text-anchor="middle" fill="#FFB703" font-family="Arial, sans-serif" font-size="24" font-weight="bold">
          "${moduleName}"
        </text>
        
        <!-- Score -->
        <text x="400" y="380" text-anchor="middle" fill="#4FBDBA" font-family="Arial, sans-serif" font-size="18">
          Con una puntuación de ${score}%
        </text>
        
        <!-- Date -->
        <text x="400" y="420" text-anchor="middle" fill="#a7a8ae" font-family="Arial, sans-serif" font-size="16">
          El ${new Date(completionDate).toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          })}
        </text>
        
        <!-- Decorative Elements -->
        <circle cx="100" cy="100" r="30" fill="none" stroke="#4FBDBA" stroke-width="2" opacity="0.5"/>
        <circle cx="700" cy="100" r="30" fill="none" stroke="#FFB703" stroke-width="2" opacity="0.5"/>
        <circle cx="100" cy="500" r="30" fill="none" stroke="#FFB703" stroke-width="2" opacity="0.5"/>
        <circle cx="700" cy="500" r="30" fill="none" stroke="#4FBDBA" stroke-width="2" opacity="0.5"/>
        
        <!-- Certificate ID -->
        <text x="400" y="520" text-anchor="middle" fill="#666" font-family="Arial, sans-serif" font-size="12">
          ID: ${certificateId}
        </text>
        
        <!-- Signature Lines -->
        <line x1="200" y1="480" x2="350" y2="480" stroke="#4FBDBA" stroke-width="2"/>
        <text x="275" y="500" text-anchor="middle" fill="#a7a8ae" font-family="Arial, sans-serif" font-size="12">
          Director Académico
        </text>
        
        <line x1="450" y1="480" x2="600" y2="480" stroke="#4FBDBA" stroke-width="2"/>
        <text x="525" y="500" text-anchor="middle" fill="#a7a8ae" font-family="Arial, sans-serif" font-size="12">
          Instructor
        </text>
      </svg>
    `;
  }

  static downloadCertificate(data: CertificateData): void {
    const svg = this.generateCertificateSVG(data);
    const blob = new Blob([svg], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `certificado-${data.certificateId}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    URL.revokeObjectURL(url);
  }

  static shareCertificate(data: CertificateData): void {
    const text = `¡He completado el módulo "${data.moduleName}" en AI Pathfinders 2025 con ${data.score}% de puntuación! 🎓`;
    const url = window.location.origin;
    
    // Share on Twitter
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
    window.open(twitterUrl, '_blank');
  }

  static generateCertificateCanvas(data: CertificateData): HTMLCanvasElement {
    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 600;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) {
      throw new Error('Could not get canvas context');
    }

    // Background gradient
    const gradient = ctx.createLinearGradient(0, 0, 800, 600);
    gradient.addColorStop(0, '#1e202f');
    gradient.addColorStop(1, '#2f2f32');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 800, 600);

    // Border
    ctx.strokeStyle = '#4FBDBA';
    ctx.lineWidth = 4;
    ctx.strokeRect(20, 20, 760, 560);

    // Header
    ctx.fillStyle = '#4FBDBA';
    ctx.font = 'bold 28px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('AI Pathfinders 2025', 400, 100);

    // Title
    ctx.fillStyle = 'white';
    ctx.font = 'bold 36px Arial';
    ctx.fillText('CERTIFICADO DE COMPLETACIÓN', 400, 150);

    // User name
    ctx.fillStyle = 'white';
    ctx.font = 'bold 32px Arial';
    ctx.fillText(data.userName, 400, 250);

    // Module name
    ctx.fillStyle = '#FFB703';
    ctx.font = 'bold 24px Arial';
    ctx.fillText(`"${data.moduleName}"`, 400, 340);

    // Score
    ctx.fillStyle = '#4FBDBA';
    ctx.font = '18px Arial';
    ctx.fillText(`Con una puntuación de ${data.score}%`, 400, 380);

    // Date
    ctx.fillStyle = '#a7a8ae';
    ctx.font = '16px Arial';
    ctx.fillText(`El ${new Date(data.completionDate).toLocaleDateString('es-ES')}`, 400, 420);

    return canvas;
  }

  static downloadCertificateAsPNG(data: CertificateData): void {
    const canvas = this.generateCertificateCanvas(data);
    const url = canvas.toDataURL('image/png');
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `certificado-${data.certificateId}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}