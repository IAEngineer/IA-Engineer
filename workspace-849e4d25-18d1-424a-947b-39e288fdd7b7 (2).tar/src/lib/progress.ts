'use client';

export interface LessonProgress {
  lessonId: string;
  moduleId: string;
  completed: boolean;
  completedAt?: string;
  timeSpent: number; // in minutes
}

export interface PracticeProgress {
  practiceId: string;
  moduleId: string;
  completed: boolean;
  score?: number;
  completedAt?: string;
}

export interface ExamProgress {
  examId: string;
  moduleId: string;
  completed: boolean;
  score: number;
  passed: boolean;
  completedAt?: string;
  answers: Record<string, number>; // questionId -> selectedOption
}

export interface ModuleProgress {
  moduleId: string;
  startedAt: string;
  lastAccessed: string;
  lessons: LessonProgress[];
  practices: PracticeProgress[];
  exams: ExamProgress[];
  overallProgress: number; // 0-100
}

export interface UserProgress {
  userId: string;
  modules: ModuleProgress[];
  totalStudyTime: number; // in minutes
  achievements: string[];
}

class ProgressManager {
  private static STORAGE_KEY = 'ai-pathfinders-progress';

  static getProgress(): UserProgress | null {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch (error) {
      console.error('Error loading progress:', error);
      return null;
    }
  }

  static saveProgress(progress: UserProgress): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(progress));
    } catch (error) {
      console.error('Error saving progress:', error);
    }
  }

  static initializeProgress(userId: string): UserProgress {
    const progress: UserProgress = {
      userId,
      modules: [],
      totalStudyTime: 0,
      achievements: []
    };
    this.saveProgress(progress);
    return progress;
  }

  static getModuleProgress(moduleId: string): ModuleProgress | null {
    const progress = this.getProgress();
    if (!progress) return null;
    
    return progress.modules.find(m => m.moduleId === moduleId) || null;
  }

  static updateLessonProgress(lessonId: string, moduleId: string, completed: boolean, timeSpent: number = 0): void {
    const progress = this.getProgress() || this.initializeProgress('default');
    
    let moduleProgress = progress.modules.find(m => m.moduleId === moduleId);
    if (!moduleProgress) {
      moduleProgress = {
        moduleId,
        startedAt: new Date().toISOString(),
        lastAccessed: new Date().toISOString(),
        lessons: [],
        practices: [],
        exams: [],
        overallProgress: 0
      };
      progress.modules.push(moduleProgress);
    }

    const lessonIndex = moduleProgress.lessons.findIndex(l => l.lessonId === lessonId);
    const lessonProgress: LessonProgress = {
      lessonId,
      moduleId,
      completed,
      timeSpent,
      ...(completed && { completedAt: new Date().toISOString() })
    };

    if (lessonIndex >= 0) {
      moduleProgress.lessons[lessonIndex] = lessonProgress;
    } else {
      moduleProgress.lessons.push(lessonProgress);
    }

    moduleProgress.lastAccessed = new Date().toISOString();
    moduleProgress.overallProgress = this.calculateModuleProgress(moduleProgress);
    
    this.saveProgress(progress);
  }

  static updatePracticeProgress(practiceId: string, moduleId: string, completed: boolean, score?: number): void {
    const progress = this.getProgress() || this.initializeProgress('default');
    
    let moduleProgress = progress.modules.find(m => m.moduleId === moduleId);
    if (!moduleProgress) {
      moduleProgress = {
        moduleId,
        startedAt: new Date().toISOString(),
        lastAccessed: new Date().toISOString(),
        lessons: [],
        practices: [],
        exams: [],
        overallProgress: 0
      };
      progress.modules.push(moduleProgress);
    }

    const practiceIndex = moduleProgress.practices.findIndex(p => p.practiceId === practiceId);
    const practiceProgress: PracticeProgress = {
      practiceId,
      moduleId,
      completed,
      score,
      ...(completed && { completedAt: new Date().toISOString() })
    };

    if (practiceIndex >= 0) {
      moduleProgress.practices[practiceIndex] = practiceProgress;
    } else {
      moduleProgress.practices.push(practiceProgress);
    }

    moduleProgress.lastAccessed = new Date().toISOString();
    moduleProgress.overallProgress = this.calculateModuleProgress(moduleProgress);
    
    this.saveProgress(progress);
  }

  static updateExamProgress(examId: string, moduleId: string, score: number, passed: boolean, answers: Record<string, number>): void {
    const progress = this.getProgress() || this.initializeProgress('default');
    
    let moduleProgress = progress.modules.find(m => m.moduleId === moduleId);
    if (!moduleProgress) {
      moduleProgress = {
        moduleId,
        startedAt: new Date().toISOString(),
        lastAccessed: new Date().toISOString(),
        lessons: [],
        practices: [],
        exams: [],
        overallProgress: 0
      };
      progress.modules.push(moduleProgress);
    }

    const examIndex = moduleProgress.exams.findIndex(e => e.examId === examId);
    const examProgress: ExamProgress = {
      examId,
      moduleId,
      completed: true,
      score,
      passed,
      completedAt: new Date().toISOString(),
      answers
    };

    if (examIndex >= 0) {
      moduleProgress.exams[examIndex] = examProgress;
    } else {
      moduleProgress.exams.push(examProgress);
    }

    moduleProgress.lastAccessed = new Date().toISOString();
    moduleProgress.overallProgress = this.calculateModuleProgress(moduleProgress);
    
    // Add achievement if passed
    if (passed && score >= 90) {
      progress.achievements.push(`perfect_score_${examId}`);
    }
    
    this.saveProgress(progress);
  }

  private static calculateModuleProgress(moduleProgress: ModuleProgress): number {
    const totalItems = moduleProgress.lessons.length + moduleProgress.practices.length + moduleProgress.exams.length;
    if (totalItems === 0) return 0;

    const completedItems = moduleProgress.lessons.filter(l => l.completed).length +
                         moduleProgress.practices.filter(p => p.completed).length +
                         moduleProgress.exams.filter(e => e.completed).length;

    return Math.round((completedItems / totalItems) * 100);
  }

  static addAchievement(achievementId: string): void {
    const progress = this.getProgress() || this.initializeProgress('default');
    if (!progress.achievements.includes(achievementId)) {
      progress.achievements.push(achievementId);
      this.saveProgress(progress);
    }
  }

  static clearProgress(): void {
    localStorage.removeItem(this.STORAGE_KEY);
  }
}

export default ProgressManager;