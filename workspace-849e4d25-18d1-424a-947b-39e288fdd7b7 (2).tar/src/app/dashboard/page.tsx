"use client";

import { useState, useEffect } from "react";
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth.tsx";
import { 
  BookOpen, 
  Award, 
  TrendingUp, 
  Clock, 
  Users, 
  Bell,
  Share2,
  LogOut,
  Settings,
  BarChart3,
  Target,
  CheckCircle
} from "lucide-react";

interface ModuleProgress {
  id: string;
  title: string;
  progress: number;
  completedLessons: number;
  totalLessons: number;
  difficulty: string;
  status: "completed" | "in-progress" | "not-started";
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  date: string;
  shareable: boolean;
}

export default function DashboardPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user, logout } = useAuth();
  const [userProgress, setUserProgress] = useState<ModuleProgress[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in
    if (!user) {
      router.push("/login");
      return;
    }

    // Simulate loading user data
    setTimeout(() => {
      setUserProgress([
        {
          id: "fundamentos",
          title: "Fundamentos de IA",
          progress: 100,
          completedLessons: 12,
          totalLessons: 12,
          difficulty: "Principiante",
          status: "completed"
        },
        {
          id: "python-sql",
          title: "Python + SQL",
          progress: 75,
          completedLessons: 14,
          totalLessons: 18,
          difficulty: "Principiante",
          status: "in-progress"
        },
        {
          id: "ml-clasico",
          title: "ML Clásico",
          progress: 45,
          completedLessons: 11,
          totalLessons: 24,
          difficulty: "Intermedio",
          status: "in-progress"
        },
        {
          id: "deep-learning",
          title: "Deep Learning",
          progress: 0,
          completedLessons: 0,
          totalLessons: 30,
          difficulty: "Avanzado",
          status: "not-started"
        }
      ]);

      setAchievements([
        {
          id: "first-module",
          title: "Primer Módulo Completado",
          description: "Completaste el módulo de Fundamentos de IA",
          icon: "🎯",
          date: "2025-06-10",
          shareable: true
        },
        {
          id: "streak-7",
          title: "Racha de 7 días",
          description: "Estudiaste durante 7 días consecutivos",
          icon: "🔥",
          date: "2025-06-12",
          shareable: true
        },
        {
          id: "first-exam",
          title: "Primer Examen Aprobado",
          description: "Aprobaste tu primer examen con 90% o más",
          icon: "📝",
          date: "2025-06-14",
          shareable: true
        }
      ]);

      setLoading(false);
    }, 1000);
  }, [user, router]);

  const handleLogout = () => {
    logout();
    toast({
      title: "Sesión cerrada",
      description: "Has cerrado tu sesión correctamente.",
    });
    router.push("/");
  };

  const shareAchievement = (achievement: Achievement) => {
    const text = `¡Acabo de conseguir un logro en AI Pathfinders 2025: ${achievement.title}! 🚀`;
    const url = window.location.href;
    
    // Share on Twitter
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
    window.open(twitterUrl, '_blank');
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Principiante": return "bg-green-100 text-green-800";
      case "Intermedio": return "bg-yellow-100 text-yellow-800";
      case "Avanzado": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "text-green-500";
      case "in-progress": return "text-yellow-500";
      case "not-started": return "text-gray-500";
      default: return "text-gray-500";
    }
  };

  const overallProgress = userProgress.length > 0 
    ? Math.round(userProgress.reduce((sum, module) => sum + module.progress, 0) / userProgress.length)
    : 0;

  if (loading) {
    return (
      <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden" style={{ fontFamily: '"Work Sans", "Noto Sans", sans-serif' }}>
        <div className="flex items-center justify-center h-screen">
          <div className="text-white">Cargando...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden" style={{ fontFamily: '"Work Sans", "Noto Sans", sans-serif' }}>
      <div className="layout-container flex h-full grow flex-col">
        {/* Navigation */}
        <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#2f2f32] px-10 py-3">
          <div className="flex items-center gap-4 text-white">
            <div className="size-4">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 45.8096C19.6865 45.8096 15.4698 44.5305 11.8832 42.134C8.29667 39.7376 5.50128 36.3314 3.85056 32.3462C2.19985 28.361 1.76794 23.9758 2.60947 19.7452C3.451 15.5145 5.52816 11.6284 8.57829 8.5783C11.6284 5.52817 15.5145 3.45101 19.7452 2.60948C23.9758 1.76795 28.361 2.19986 32.3462 3.85057C36.3314 5.50129 39.7376 8.29668 42.134 11.8833C44.5305 15.4698 45.8096 19.6865 45.8096 24L24 24L24 45.8096Z" fill="currentColor"></path>
              </svg>
            </div>
            <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">AI Pathfinders 2025</h2>
          </div>
          <div className="flex flex-1 justify-end gap-8">
            <div className="flex items-center gap-9">
              <a className="text-white text-sm font-medium leading-normal" href="/">Inicio</a>
              <a className="text-white text-sm font-medium leading-normal" href="#">Módulos</a>
              <a className="text-white text-sm font-medium leading-normal" href="#">Comunidad</a>
              <a className="text-white text-sm font-medium leading-normal" href="#">Recursos</a>
            </div>
            <button className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 bg-[#2f2f32] text-white gap-2 text-sm font-bold leading-normal tracking-[0.015em] min-w-0 px-2.5">
              <Bell className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-4">
              <Avatar className="h-8 w-8">
                <AvatarImage src="https://github.com/shadcn.png" alt="User" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleLogout}
                className="text-[#a7a8ae] hover:text-white"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Salir
              </Button>
            </div>
          </div>
        </header>

        <div className="px-4 sm:px-6 lg:px-8 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col max-w-[1200px] flex-1 w-full space-y-6">
            {/* Welcome Section */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h1 className="text-white text-3xl font-bold leading-tight mb-2">
                  ¡Bienvenido de vuelta, {user?.name || 'Estudiante'}!
                </h1>
                <p className="text-[#a7a8ae] text-base">
                  Continúa tu viaje para convertirte en experto en IA
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" className="bg-[#2f2f32] border-[#45454a] text-white">
                  <Settings className="w-4 h-4 mr-2" />
                  Configuración
                </Button>
                <Button className="bg-[#4FBDBA] hover:bg-[#4FBDBA]/90 text-white">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Continuar Aprendiendo
                </Button>
              </div>
            </div>

            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[#a7a8ae] text-sm">Progreso General</p>
                      <p className="text-white text-2xl font-bold">{overallProgress}%</p>
                    </div>
                    <BarChart3 className="h-8 w-8 text-[#4FBDBA]" />
                  </div>
                  <Progress value={overallProgress} className="mt-2" />
                </CardContent>
              </Card>

              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[#a7a8ae] text-sm">Módulos Completados</p>
                      <p className="text-white text-2xl font-bold">
                        {userProgress.filter(m => m.status === "completed").length}/8
                      </p>
                    </div>
                    <CheckCircle className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[#a7a8ae] text-sm">Horas de Estudio</p>
                      <p className="text-white text-2xl font-bold">45</p>
                    </div>
                    <Clock className="h-8 w-8 text-[#FFB703]" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[#a7a8ae] text-sm">Logros</p>
                      <p className="text-white text-2xl font-bold">{achievements.length}</p>
                    </div>
                    <Award className="h-8 w-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Module Progress */}
            <Card className="bg-[#1e202f] border-[#2f2f32]">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Progreso de Módulos
                </CardTitle>
                <CardDescription className="text-[#a7a8ae]">
                  Tu avance en cada módulo del curso
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {userProgress.map((module) => (
                  <div key={module.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <h3 className="text-white font-medium">{module.title}</h3>
                        <Badge className={getDifficultyColor(module.difficulty)}>
                          {module.difficulty}
                        </Badge>
                        <Badge variant="outline" className={`border-current ${getStatusColor(module.status)}`}>
                          {module.status === "completed" ? "Completado" : 
                           module.status === "in-progress" ? "En progreso" : "No iniciado"}
                        </Badge>
                      </div>
                      <span className="text-white text-sm font-medium">{module.progress}%</span>
                    </div>
                    <Progress value={module.progress} className="h-2" />
                    <div className="flex justify-between text-xs text-[#a7a8ae]">
                      <span>{module.completedLessons} de {module.totalLessons} lecciones completadas</span>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => router.push(`/modules/${module.id}`)}
                        className="text-[#4FBDBA] hover:text-[#4FBDBA]/80 p-0 h-auto"
                      >
                        {module.status === "completed" ? "Repasar" : 
                         module.status === "in-progress" ? "Continuar" : "Comenzar"}
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Achievements */}
            <Card className="bg-[#1e202f] border-[#2f2f32]">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Logros Recientes
                </CardTitle>
                <CardDescription className="text-[#a7a8ae]">
                  Comparte tus logros en redes sociales
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {achievements.map((achievement) => (
                    <Card key={achievement.id} className="bg-[#2f2f32] border-[#45454a]">
                      <CardContent className="p-4 text-center">
                        <div className="text-4xl mb-2">{achievement.icon}</div>
                        <h3 className="text-white font-medium mb-1">{achievement.title}</h3>
                        <p className="text-[#a7a8ae] text-sm mb-3">{achievement.description}</p>
                        <p className="text-[#a7a8ae] text-xs mb-3">{new Date(achievement.date).toLocaleDateString()}</p>
                        {achievement.shareable && (
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => shareAchievement(achievement)}
                            className="bg-[#1e202f] border-[#45454a] text-white hover:bg-[#45454a] w-full"
                          >
                            <Share2 className="w-4 h-4 mr-2" />
                            Compartir
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}