"use client";

import { useState, useEffect } from "react";
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { BookOpen, TrendingUp, Award, Users, Star, Clock, Video, Code, File, Bookmark, Users as UsersIcon, ArrowLeft, Bell } from "lucide-react";

interface Module {
  id: string;
  title: string;
  description: string;
  difficulty: "Principiante" | "Intermedio" | "Avanzado";
  duration: string;
  lessons: number;
  icon: string;
  color: string;
  imageUrl: string;
}

interface Trend {
  title: string;
  description: string;
  source: string;
  url: string;
  date: string;
  imageUrl: string;
}

const modules: Module[] = [
  {
    id: "fundamentos",
    title: "Fundamentos de IA",
    description: "Introducción a los conceptos básicos de inteligencia artificial y machine learning",
    difficulty: "Principiante",
    duration: "4 semanas",
    lessons: 12,
    icon: "🧠",
    color: "bg-blue-500",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuA7QGQMfqIqNREvsDqwZoxzjWBm5TQV86FNlnjJ5bszszXSnvdrvc1twEi0Nv7dFII_9rSBnoHfMIKiUWDpKl2LnXT7OLzpkBkUPc5d1toX8qFAI2usroeaP4MR_KFoCHlgwLK_z-_6gzeX7JijmS5X0RaRkN6WVsY2etTu6Z5Ox7aHRq_k8xkuON4sE3OZXdWezj7xvi_g1SGD0NUgwV9Zt-GhphFpv7mYlMvoFHLwy251Zv6ev_lrPXKYe5SmybKCwUWv2fW-jFs"
  },
  {
    id: "python-sql",
    title: "Python + SQL",
    description: "Programación en Python y manejo de bases de datos con SQL para IA",
    difficulty: "Principiante",
    duration: "6 semanas",
    lessons: 18,
    icon: "🐍",
    color: "bg-green-500",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuC0KralFQTOF1F84LxgIl9_Q4MpTb9-ZDGh5szo1-msBeUud4AU78QWA0ehAXuAR82AG92c4IFA3z2CxuEFn2FYA-Mg2pgk3YTStrXCHcfGeYcTeUrl12gAgVz3gVTxPKgl5SKO2oed_dZQmqhbdc9wedj1FHoT4G1ZlJL50E1lXaJt8iAfAiYn664Ic93I46NH6xprajExMmKmLwZd5rU_weH8swyfY1zFfQ_snKOFNuqrpU2S-pjcaUt7pmBRi2QTC608WyXWTT8"
  },
  {
    id: "ml-clasico",
    title: "ML Clásico",
    description: "Algoritmos de machine learning clásico: regresión, clasificación y clustering",
    difficulty: "Intermedio",
    duration: "8 semanas",
    lessons: 24,
    icon: "📊",
    color: "bg-purple-500",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAqtGg1czDF4JlpX0NmpPDFdzRf-67uA2jNH-2GELgQiqONNUaDjCzFdSgehNrFg6hBTsdFRtDEuidamNsNya8o1_vZcuu6MLYyHg4ZXVeV31LYcUNtjIiDMpDzKte3JgoyHHCrD-FClzxskhUtNDf-8S1nWj0ra_GrRkhALIjYtQUChPdEeSN5MV5QPKNlmVcQ3SjJilUckRn0iuIiwrgrf5m7MLsohlcvslD6gx_s_v1wWFHhxwcs1b4hkNzooJ-8zCMtOreEEoI"
  },
  {
    id: "deep-learning",
    title: "Deep Learning",
    description: "Redes neuronales profundas, CNN, RNN y transformadores",
    difficulty: "Avanzado",
    duration: "10 semanas",
    lessons: 30,
    icon: "🔥",
    color: "bg-red-500",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDKNojEB7IrgO19p_jcISWVhAobqTVXbApo4ihZMTrhGTiy9vzrEANvC8-qxDROAwFNUqbvJ2dv5PRfg5leL0yJAIx6r-ucditgrIrYLPenvH_dRlJRFw7C9tvVTb7dLrPGo665MG19xAS_5me0NzCeCQ0vp0E0Olp6z2vpvHaGI-40gOj3H73kJcv_49qa0rtNLcVR0O7bcmhiVrtswhHyNCatSRGQcctSDT7ICJxiZH4Jcu0K8KShnheOq4gvQvagnq_gluo3GxY"
  },
  {
    id: "nlp-cv",
    title: "NLP & Computer Vision",
    description: "Procesamiento de lenguaje natural y visión por computadora",
    difficulty: "Avanzado",
    duration: "8 semanas",
    lessons: 24,
    icon: "👁️",
    color: "bg-indigo-500",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuDtbxFl-O1dm2mJX6eGbG-9Dl9BAyKTU31-n7Gy4fhcmG7ZBV1KOAwGf3Cjl80p7JrV4W27DHm7eOupOuUGTKHR5XV19AhSzWldceRM89lXpGM_mf7ePySf6dsSKtaVendMQAnS0d4xAB1e-0h07HINZPDjr4ROVRPL0tb_1oJVAPcqe4etFYbE17RkpQ9nBodNINpy-F9ZUFRaJQCBP35u_hlbSXVOwsfR8rUw2vdPQVAohie6hhYKGrAGTJ6SkanNE1a0qvae0N0"
  },
  {
    id: "mlops",
    title: "MLOps & Despliegue",
    description: "Implementación y despliegue de modelos de IA en producción",
    difficulty: "Intermedio",
    duration: "6 semanas",
    lessons: 18,
    icon: "⚙️",
    color: "bg-yellow-500",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuClZSyKr4Np0BYKKwZePSv2Dq-J3iMfSN7Za3fdwkl3btGCiiApNe0LHBGhoFx125JU3pRIkbTs7jUTDrz-8xCAdGAogZ1uJeWTH4TWzHQgP83AALUTIW4nkv_BnHSBAaxFzBepq-x7P45XdpRUZuoUbpGOTNvXM1fMph0jHVbnZrdcrynzOTxJnBgzYRVF-auqWMu51GSrREcfV3rXsI7_ulRnbANSyT62m2K0G-_kPYjzXrxggUtCW3gd8s_fvTL_VRLnh-j1Ps0"
  },
  {
    id: "etica",
    title: "Ética en IA",
    description: "Consideraciones éticas, sesgos y responsabilidad en IA",
    difficulty: "Intermedio",
    duration: "4 semanas",
    lessons: 12,
    icon: "⚖️",
    color: "bg-pink-500",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuCja2y7HB4PA2KsS6JrEW_FTZvtuUD8SFp___N_4qpw4VRUR5qRRqwlakfoNvZlxdSgAFqXnpu2BBbaiD0bZ6TZvOdR_4FeqD9wIVdhB7cQdPGJcRAZyxYDlv_do2EIk7m1w7jzdD67Mcg8cLMNlDms-L7tEAfCLVRSkWBb-zvIFbtxnY1M9EezEwpYy8MmpLFpv2G226faXeZMROhOZPgLQl32g7kCsizYe3gIWPH1Sci03EoK7PlCGiW-TLok4zxUjUXNN5OM_sY"
  },
  {
    id: "generative-ai",
    title: "Generative AI Avanzada",
    description: "Modelos generativos: GANs, VAEs y modelos de lenguaje grandes",
    difficulty: "Avanzado",
    duration: "8 semanas",
    lessons: 24,
    icon: "🎨",
    color: "bg-teal-500",
    imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAtZ9jz4P1ER9Bw-tC2x8TrBGCy8ixz0BrOclfBKneTjQqyiMnQOTyUyhKwADmEn57sIo_wfmbDi9TTpiMtNsNUY0zqBoXrUDFqXJoB9KV9pmDiiyThW2VwGWouho7LeKMJrxH7mmsfq9YivWquEJfJCPKD_x5Hc6HaV8paHIa-TZjb4dFmWB71yToOsjepfPNOu5EbuExgn2ORNvNspL8ejLLN_sC3kd1lErsL88DrcOVz6JfOyEAly65DyNtgYSq7MsIHfYNF1Us"
  }
];

export default function Home() {
  const router = useRouter();
  const { toast } = useToast();
  const [trends, setTrends] = useState<Trend[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTrends();
  }, []);

  const fetchTrends = async () => {
    try {
      const response = await fetch("/api/trends");
      if (response.ok) {
        const data = await response.json();
        // Handle new API response format
        if (data.trends && Array.isArray(data.trends)) {
          setTrends(data.trends);
          console.log(`Loaded ${data.trends.length} trends from ${data.source}`);
        } else {
          // Fallback data with image URLs
          setTrends([
            {
              title: "Avances en Modelos de Lenguaje Grandes",
              description: "Los LLMs continúan revolucionando la industria con capacidades de razonamiento mejoradas",
              source: "AI Trends 2025",
              url: "#",
              date: "2025-06-15",
              imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuC_T1jPffr74xemHVklqWmgxgwfewOE5jBHoIcbRCmBdpvZ7zzWbykpzPM68CaRQpRW0O8ebqEYtwlCZV3VOeWKap_BxOrgmL2HC8TGpcprT3SPPtHI6CN0DihbNsKXXdD4mQgAsFZWqwdGBAXVFj-sUrzSqLkgV9g_sJ7Zuc951ChprFd79aerSYrz3zwDoC9nBCPHkF5GE3RHU6aeHnlpMmELQUCb7OelSRF7ifuGji9t_5-1CLzggZ0BZajRDvOnVHCrYkWh7GE"
            },
            {
              title: "IA Multimodal: El Futuro de la Interacción",
              description: "La integración de texto, imagen y audio en un solo modelo está cambiando la UX",
              source: "Tech Report",
              url: "#",
              date: "2025-06-14",
              imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuCCIqR0v67q_gvJLdHCvFuU2vmaYaLmROoM9TlJJz1ccT9BuKoWN5SWateF7eMYqZUV5teGayIe8d3r3MaR65keFKnjHXuWKZJ2lbFi3v5iUes7zRFZeTAEdh_6N-FzdLXida5FWBQEaCX8hny4daJzVPwR7X2Oaj4JO_t0FsoO20As6LTvdn5cC0Iq7uwieAMZTdMVb-TUC-yCeEImG4mglzo2TpmjaufQcjf2_LQzaM7P995LUuVtPumg0uxibarJLDWq8iJ18FU"
            },
            {
              title: "MLOps: Escalando Modelos en Producción",
              description: "Nuevas herramientas y prácticas para desplegar modelos de IA a escala",
              source: "DevOps Weekly",
              url: "#",
              date: "2025-06-13",
              imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuC0zetaPbSSIClbqvxuynXjO_hIlfwWqExDhs_9ZG24fDn51la3jrMkDQkPf-WtPFNpruW_UaDwvoqOWB0VFK_ulLiY3TLvtfwP7PjJSDE1g9qgm0xgXYKgCaHcL_sGrEfYNGak4kjb_pJTmerBy4C6uiIGjAH3CZbWq5BP_rk0vN39tap1ykV08Z2MIcTHGBQeKuP7cVrQOYsHB1fw5Sm3Bu4Uc0NyCZ_v-wBtTR7ucos2VI0yJbqOafWJ6ux4BzQxInZdyrsiAxo"
            }
          ]);
        }
      } else {
        // Fallback data with image URLs
        setTrends([
          {
            title: "Avances en Modelos de Lenguaje Grandes",
            description: "Los LLMs continúan revolucionando la industria con capacidades de razonamiento mejoradas",
            source: "AI Trends 2025",
            url: "#",
            date: "2025-06-15",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuC_T1jPffr74xemHVklqWmgxgwfewOE5jBHoIcbRCmBdpvZ7zzWbykpzPM68CaRQpRW0O8ebqEYtwlCZV3VOeWKap_BxOrgmL2HC8TGpcprT3SPPtHI6CN0DihbNsKXXdD4mQgAsFZWqwdGBAXVFj-sUrzSqLkgV9g_sJ7Zuc951ChprFd79aerSYrz3zwDoC9nBCPHkF5GE3RHU6aeHnlpMmELQUCb7OelSRF7ifuGji9t_5-1CLzggZ0BZajRDvOnVHCrYkWh7GE"
          },
          {
            title: "IA Multimodal: El Futuro de la Interacción",
            description: "La integración de texto, imagen y audio en un solo modelo está cambiando la UX",
            source: "Tech Report",
            url: "#",
            date: "2025-06-14",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuCCIqR0v67q_gvJLdHCvFuU2vmaYaLmROoM9TlJJz1ccT9BuKoWN5SWateF7eMYqZUV5teGayIe8d3r3MaR65keFKnjHXuWKZJ2lbFi3v5iUes7zRFZeTAEdh_6N-FzdLXida5FWBQEaCX8hny4daJzVPwR7X2Oaj4JO_t0FsoO20As6LTvdn5cC0Iq7uwieAMZTdMVb-TUC-yCeEImG4mglzo2TpmjaufQcjf2_LQzaM7P995LUuVtPumg0uxibarJLDWq8iJ18FU"
          },
          {
            title: "MLOps: Escalando Modelos en Producción",
            description: "Nuevas herramientas y prácticas para desplegar modelos de IA a escala",
            source: "DevOps Weekly",
            url: "#",
            date: "2025-06-13",
            imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuC0zetaPbSSIClbqvxuynXjO_hIlfwWqExDhs_9ZG24fDn51la3jrMkDQkPf-WtPFNpruW_UaDwvoqOWB0VFK_ulLiY3TLvtfwP7PjJSDE1g9qgm0xgXYKgCaHcL_sGrEfYNGak4kjb_pJTmerBy4C6uiIGjAH3CZbWq5BP_rk0vN39tap1ykV08Z2MIcTHGBQeKuP7cVrQOYsHB1fw5Sm3Bu4Uc0NyCZ_v-wBtTR7ucos2VI0yJbqOafWJ6ux4BzQxInZdyrsiAxo"
          }
        ]);
      }
    } catch (error) {
      console.error("Error fetching trends:", error);
      toast({
        title: "Error de carga",
        description: "No se pudieron cargar las tendencias de IA. Mostrando contenido local.",
        variant: "destructive",
      });
      // Fallback data even on error
      setTrends([
        {
          title: "Avances en Modelos de Lenguaje Grandes",
          description: "Los LLMs continúan revolucionando la industria con capacidades de razonamiento mejoradas",
          source: "AI Trends 2025",
          url: "#",
          date: "2025-06-15",
          imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuC_T1jPffr74xemHVklqWmgxgwfewOE5jBHoIcbRCmBdpvZ7zzWbykpzPM68CaRQpRW0O8ebqEYtwlCZV3VOeWKap_BxOrgmL2HC8TGpcprT3SPPtHI6CN0DihbNsKXXdD4mQgAsFZWqwdGBAXVFj-sUrzSqLkgV9g_sJ7Zuc951ChprFd79aerSYrz3zwDoC9nBCPHkF5GE3RHU6aeHnlpMmELQUCb7OelSRF7ifuGji9t_5-1CLzggZ0BZajRDvOnVHCrYkWh7GE"
        },
        {
          title: "IA Multimodal: El Futuro de la Interacción",
          description: "La integración de texto, imagen y audio en un solo modelo está cambiando la UX",
          source: "Tech Report",
          url: "#",
          date: "2025-06-14",
          imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuCCIqR0v67q_gvJLdHCvFuU2vmaYaLmROoM9TlJJz1ccT9BuKoWN5SWateF7eMYqZUV5teGayIe8d3r3MaR65keFKnjHXuWKZJ2lbFi3v5iUes7zRFZeTAEdh_6N-FzdLXida5FWBQEaCX8hny4daJzVPwR7X2Oaj4JO_t0FsoO20As6LTvdn5cC0Iq7uwieAMZTdMVb-TUC-yCeEImG4mglzo2TpmjaufQcjf2_LQzaM7P995LUuVtPumg0uxibarJLDWq8iJ18FU"
        },
        {
          title: "MLOps: Escalando Modelos en Producción",
          description: "Nuevas herramientas y prácticas para desplegar modelos de IA a escala",
          source: "DevOps Weekly",
          url: "#",
          date: "2025-06-13",
          imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuC0zetaPbSSIClbqvxuynXjO_hIlfwWqExDhs_9ZG24fDn51la3jrMkDQkPf-WtPFNpruW_UaDwvoqOWB0VFK_ulLiY3TLvtfwP7PjJSDE1g9qgm0xgXYKgCaHcL_sGrEfYNGak4kjb_pJTmerBy4C6uiIGjAH3CZbWq5BP_rk0vN39tap1ykV08Z2MIcTHGBQeKuP7cVrQOYsHB1fw5Sm3Bu4Uc0NyCZ_v-wBtTR7ucos2VI0yJbqOafWJ6ux4BzQxInZdyrsiAxo"
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Principiante": return "bg-green-100 text-green-800";
      case "Intermedio": return "bg-yellow-100 text-yellow-800";
      case "Avanzado": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden font-sans">
      <div className="flex h-full grow flex-col">
        {/* Navigation */}
        <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#2f2f32] px-4 sm:px-6 lg:px-10 py-3">
          <div className="flex items-center gap-4 text-white">
            <div className="size-4">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 45.8096C19.6865 45.8096 15.4698 44.5305 11.8832 42.134C8.29667 39.7376 5.50128 36.3314 3.85056 32.3462C2.19985 28.361 1.76794 23.9758 2.60947 19.7452C3.451 15.5145 5.52816 11.6284 8.57829 8.5783C11.6284 5.52817 15.5145 3.45101 19.7452 2.60948C23.9758 1.76795 28.361 2.19986 32.3462 3.85057C36.3314 5.50129 39.7376 8.29668 42.134 11.8833C44.5305 15.4698 45.8096 19.6865 45.8096 24L24 24L24 45.8096Z" fill="currentColor"></path>
              </svg>
            </div>
            <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">AI Pathfinders 2025</h2>
          </div>
          <div className="flex flex-1 justify-end gap-4 sm:gap-8">
            <div className="flex items-center gap-4 sm:gap-9">
              <button 
                onClick={() => router.push('/modules')}
                className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors cursor-pointer pointer-events-auto"
                data-testid="nav-modules"
              >
                Módulos
              </button>
              <button 
                onClick={() => router.push('/trends')}
                className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors cursor-pointer pointer-events-auto"
                data-testid="nav-trends"
              >
                Tendencias
              </button>
              <a className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors" href="#">Comunidad</a>
              <a className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors" href="#">Recursos</a>
            </div>
            <button className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 bg-[#2f2f32] text-white gap-2 text-sm font-bold leading-normal tracking-[0.015em] min-w-0 px-2.5">
              <Bell className="w-5 h-5" />
            </button>
            <div className="flex gap-2">
              <button 
                onClick={() => router.push('/auth/register')}
                className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#1e202f] text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-[#2f2f32] transition-colors"
                data-testid="nav-register"
              >
                <span className="truncate">Registrarse</span>
              </button>
              <button 
                onClick={() => router.push('/auth/login')}
                className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#2f2f32] text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-[#1e202f] transition-colors"
                data-testid="nav-login"
              >
                <span className="truncate">Iniciar Sesión</span>
              </button>
            </div>
          </div>
        </header>

        <div className="mx-auto max-w-screen-xl px-4 sm:px-6 lg:px-8 flex flex-1 justify-center py-5">
          <div className="flex flex-col max-w-[1200px] flex-1 w-full">
            <div className="@container">
              <div className="@[480px]:p-4">
                <div className="flex min-h-[480px] flex-col gap-6 bg-cover bg-center bg-no-repeat @[480px]:gap-8 @[480px]:rounded-lg items-center justify-center p-4" style={{backgroundImage: "linear-gradient(rgba(0, 0, 0, 0.1) 0%, rgba(0, 0, 0, 0.4) 100%), url(\"https://lh3.googleusercontent.com/aida-public/AB6AXuCXesk37GK6ywrmwha0IEc6Q1TlmaaOr5YSp2r2xTgctPlWYZj9mKy-sPRb8xUvuENRayyNktrBURnweFFC3wOeFsqrvPSGIwnanD1xx7Yz_r3f_yCt_XbKJ6aO_uOS1NXumOTOmtUknoa06IaAQ4PQ8-YOGNiM08LwCEl5wOX1YLezY-Gd0_eI1ALI0MGLiuosOIqerI4PdYk8yU1kByZIWTIY_IEvjBq0xeiAFTB5b3rbF2AX761p5w50tFz-TPGyFQwjKqi_8UQ\")"}}>
                  <div className="flex flex-col gap-2 text-center">
                    <h1 className="text-white text-4xl font-black leading-tight tracking-[-0.033em] @[480px]:text-5xl @[480px]:font-black @[480px]:leading-tight @[480px]:tracking-[-0.033em]">Conviértete en<span className="text-[#4FBDBA] block"> Experto en IA</span></h1>
                    <h2 className="text-white text-sm font-normal leading-normal @[480px]:text-base @[480px]:font-normal @[480px]:leading-normal">Domina las tecnologías más demandadas de la inteligencia artificial con nuestro programa educativo modular y práctico diseñado para 2025.</h2>
                  </div>
                  <button 
                    onClick={() => router.push('/modules')}
                    className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 @[480px]:h-12 @[480px]:px-5 bg-[#1e202f] text-white text-sm font-bold leading-normal tracking-[0.015em] @[480px]:text-base @[480px]:font-bold @[480px]:leading-normal @[480px]:tracking-[0.015em] hover:bg-[#4FBDBA] transition-colors pointer-events-auto"
                    data-testid="cta-explorar"
                  >
                    <span className="truncate">Explorar Módulos</span>
                  </button>
                </div>
              </div>
            </div>
            
            <div className="mx-auto max-w-screen-xl px-4 sm:px-6 lg:px-8">
              <h2 className="text-white text-[22px] font-bold leading-tight tracking-[-0.015em] pb-3 pt-5">Módulos del Curso</h2>
              <div className="flex overflow-x-auto [-ms-scrollbar-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
                <div className="flex items-stretch gap-4 pb-4">
                  {modules.map((module) => (
                    <div key={module.id} className="flex flex-col gap-4 rounded-lg min-w-[280px] max-w-[320px] flex-shrink-0">
                      <div className="w-full bg-center bg-no-repeat aspect-square bg-cover rounded-lg flex flex-col" style={{backgroundImage: `url("${module.imageUrl}")`}}></div>
                      <div className="flex flex-col gap-2">
                        <p className="text-white text-base font-medium leading-normal break-words">{module.title}</p>
                        <p className="text-[#a7a8ae] text-sm font-normal leading-normal line-clamp-2 break-words">{module.description}</p>
                        <div className="flex items-center justify-between mt-2">
                          <span data-slot="badge" className="inline-flex items-center justify-center rounded-md border px-2 py-0.5 text-xs font-medium w-fit whitespace-nowrap shrink-nowrap [&>svg]:size-3 gap-1 [&>svg]:pointer-events-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive transition-[color,box-shadow] overflow-hidden border-transparent [a&]:hover:bg-primary/90 bg-green-100 text-green-800">
                            {module.difficulty}
                          </span>
                          <span className="text-[#a7a8ae] text-xs">{module.duration}</span>
                        </div>
                        <button 
                          onClick={() => router.push(`/modules/${module.id}`)}
                          className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#1e202f] text-white text-sm font-bold leading-normal tracking-[0.015em] w-full mt-2 hover:bg-[#4FBDBA] transition-colors pointer-events-auto"
                        >
                          <span className="truncate">Ver Módulo</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <h2 className="text-white text-[22px] font-bold leading-tight tracking-[-0.015em] pb-3 pt-5">Tendencias IA 2025</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pb-8">
                {loading ? (
                  <>
                    <div className="flex flex-col gap-3 pb-3">
                      <div data-slot="skeleton" className="bg-accent animate-pulse w-full aspect-square rounded-lg"></div>
                      <div>
                        <div data-slot="skeleton" className="bg-accent animate-pulse rounded-md h-4 w-3/4 mb-2"></div>
                        <div data-slot="skeleton" className="bg-accent animate-pulse rounded-md h-4 w-full"></div>
                      </div>
                    </div>
                    <div className="flex flex-col gap-3 pb-3">
                      <div data-slot="skeleton" className="bg-accent animate-pulse w-full aspect-square rounded-lg"></div>
                      <div>
                        <div data-slot="skeleton" className="bg-accent animate-pulse rounded-md h-4 w-3/4 mb-2"></div>
                        <div data-slot="skeleton" className="bg-accent animate-pulse rounded-md h-4 w-full"></div>
                      </div>
                    </div>
                    <div className="flex flex-col gap-3 pb-3">
                      <div data-slot="skeleton" className="bg-accent animate-pulse w-full aspect-square rounded-lg"></div>
                      <div>
                        <div data-slot="skeleton" className="bg-accent animate-pulse rounded-md h-4 w-3/4 mb-2"></div>
                        <div data-slot="skeleton" className="bg-accent animate-pulse rounded-md h-4 w-full"></div>
                      </div>
                    </div>
                  </>
                ) : (
                  trends.map((trend, index) => (
                    <div key={index} className="flex flex-col gap-3 pb-3">
                      <div className="w-full bg-center bg-no-repeat aspect-square bg-cover rounded-lg flex flex-col" style={{backgroundImage: `url("${trend.imageUrl}")`}}></div>
                      <div>
                        <h3 className="text-white text-base font-medium leading-normal mb-2 break-words">{trend.title}</h3>
                        <p className="text-[#a7a8ae] text-sm font-normal leading-normal line-clamp-3 break-words">{trend.description}</p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-[#a7a8ae] text-xs break-words">{trend.source}</span>
                          <span className="text-[#a7a8ae] text-xs">{new Date(trend.date).toLocaleDateString('es-ES')}</span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
            </div>
            
            </div>
            
            <div className="py-12 px-4 sm:px-6 lg:px-8 bg-[#1E1E2F] text-white rounded-lg mx-4 sm:mx-6 lg:mx-8 my-8">
              <div className="max-w-4xl mx-auto">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                  <div>
                    <div className="text-4xl font-bold text-[#4FBDBA] mb-2">8</div>
                    <div className="text-slate-300 break-words">Módulos</div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-[#FFB703] mb-2">150+</div>
                    <div className="text-slate-300 break-words">Lecciones</div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-[#4FBDBA] mb-2">50+</div>
                    <div className="text-slate-300 break-words">Proyectos</div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-[#FFB703] mb-2">24/7</div>
                    <div className="text-slate-300 break-words">Soporte</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="py-12 px-4 sm:px-6 lg:px-8">
              <div className="max-w-4xl mx-auto text-center">
                <h3 className="text-3xl font-bold text-white mb-4 break-words">¿Lista para Transformar tu Carrera?</h3>
                <p className="text-lg text-[#a7a8ae] mb-8 break-words">Únete a miles de estudiantes que ya están construyendo el futuro con IA</p>
                <button 
                  onClick={() => router.push('/modules')}
                  className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 px-6 bg-[#4FBDBA] text-white text-lg font-bold leading-normal tracking-[0.015em] mx-auto hover:bg-[#4FBDBA]/90 transition-colors pointer-events-auto"
                >
                  <span className="truncate">Comenzar tu Viaje en IA</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}