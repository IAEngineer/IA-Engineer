"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Share2, ArrowLeft, Award } from "lucide-react";
import { CertificateGenerator, CertificateData } from "@/lib/certificate";
import { useAuth } from "@/lib/auth.tsx";

export default function CertificatePage() {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const attemptId = params.attemptId as string;
  
  const [certificateData, setCertificateData] = useState<CertificateData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load certificate data (in real app, this would come from API)
    const loadCertificate = async () => {
      // Mock certificate data
      const mockData: CertificateData = {
        userName: user?.name || "Estudiante",
        moduleName: "Fundamentos de IA",
        completionDate: new Date().toISOString(),
        score: 85,
        certificateId: attemptId
      };

      setCertificateData(mockData);
      setLoading(false);
    };

    loadCertificate();
  }, [attemptId, user]);

  const handleDownloadSVG = () => {
    if (certificateData) {
      CertificateGenerator.downloadCertificate(certificateData);
    }
  };

  const handleDownloadPNG = () => {
    if (certificateData) {
      CertificateGenerator.downloadCertificateAsPNG(certificateData);
    }
  };

  const handleShare = () => {
    if (certificateData) {
      CertificateGenerator.shareCertificate(certificateData);
    }
  };

  if (loading) {
    return (
      <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden" style={{ fontFamily: '"Work Sans", "Noto Sans", sans-serif' }}>
        <div className="flex items-center justify-center h-screen">
          <div className="text-white">Cargando certificado...</div>
        </div>
      </div>
    );
  }

  if (!certificateData) {
    return (
      <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden" style={{ fontFamily: '"Work Sans", "Noto Sans", sans-serif' }}>
        <div className="flex items-center justify-center h-screen">
          <div className="text-white">Certificado no encontrado</div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden" style={{ fontFamily: '"Work Sans", "Noto Sans", sans-serif' }}>
      <div className="layout-container flex h-full grow flex-col">
        {/* Navigation */}
        <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#2f2f32] px-10 py-3">
          <div className="flex items-center gap-4 text-white">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => router.back()}
              className="text-[#a7a8ae] hover:text-white p-0"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver
            </Button>
            <div className="size-4">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 45.8096C19.6865 45.8096 15.4698 44.5305 11.8832 42.134C8.29667 39.7376 5.50128 36.3314 3.85056 32.3462C2.19985 28.361 1.76794 23.9758 2.60947 19.7452C3.451 15.5145 5.52816 11.6284 8.57829 8.5783C11.6284 5.52817 15.5145 3.45101 19.7452 2.60948C23.9758 1.76795 28.361 2.19986 32.3462 3.85057C36.3314 5.50129 39.7376 8.29668 42.134 11.8833C44.5305 15.4698 45.8096 19.6865 45.8096 24L24 24L24 45.8096Z" fill="currentColor"></path>
              </svg>
            </div>
            <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">AI Pathfinders 2025</h2>
          </div>
        </header>

        <div className="px-4 sm:px-6 lg:px-8 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col max-w-[1000px] flex-1 w-full space-y-6">
            {/* Certificate Preview */}
            <Card className="bg-[#1e202f] border-[#2f2f32] text-white">
              <CardHeader className="text-center">
                <div className="w-16 h-16 mx-auto bg-[#4FBDBA] rounded-full flex items-center justify-center mb-4">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-2xl text-[#4FBDBA]">¡Felicidades!</CardTitle>
                <CardDescription>
                  Has completado exitosamente el módulo y obtuviste tu certificado
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Certificate Info */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-[#4FBDBA]">{certificateData.score}%</div>
                    <div className="text-sm text-[#a7a8ae]">Puntuación</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-[#FFB703]">{certificateData.moduleName}</div>
                    <div className="text-sm text-[#a7a8ae]">Módulo</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-green-500">Aprobado</div>
                    <div className="text-sm text-[#a7a8ae]">Estado</div>
                  </div>
                </div>

                {/* Certificate Preview */}
                <div className="border border-[#2f2f32] rounded-lg p-4 bg-[#141415]">
                  <div 
                    className="w-full h-96 bg-cover bg-center rounded-lg flex items-center justify-center"
                    style={{ 
                      backgroundImage: `url("data:image/svg+xml,${encodeURIComponent(CertificateGenerator.generateCertificateSVG(certificateData))}")`,
                      backgroundSize: 'contain',
                      backgroundRepeat: 'no-repeat',
                      backgroundPosition: 'center'
                    }}
                  >
                    <div className="text-white text-center">
                      <div className="text-lg font-bold mb-2">Vista Previa del Certificado</div>
                      <div className="text-sm text-[#a7a8ae]">Certificado de AI Pathfinders 2025</div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button
                    onClick={handleDownloadSVG}
                    className="bg-[#4FBDBA] hover:bg-[#4FBDBA]/90 text-white"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Descargar SVG
                  </Button>
                  
                  <Button
                    onClick={handleDownloadPNG}
                    variant="outline"
                    className="bg-[#2f2f32] border-[#45454a] text-white hover:bg-[#45454a]"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Descargar PNG
                  </Button>
                  
                  <Button
                    onClick={handleShare}
                    variant="outline"
                    className="bg-[#2f2f32] border-[#45454a] text-white hover:bg-[#45454a]"
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Compartir
                  </Button>
                </div>

                {/* Certificate Details */}
                <div className="border-t border-[#2f2f32] pt-4">
                  <h3 className="text-lg font-semibold mb-3">Detalles del Certificado</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-[#a7a8ae]">ID del Certificado:</span>
                      <span className="text-white ml-2">{certificateData.certificateId}</span>
                    </div>
                    <div>
                      <span className="text-[#a7a8ae]">Fecha de Emisión:</span>
                      <span className="text-white ml-2">
                        {new Date(certificateData.completionDate).toLocaleDateString('es-ES', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </span>
                    </div>
                    <div>
                      <span className="text-[#a7a8ae]">Nombre del Estudiante:</span>
                      <span className="text-white ml-2">{certificateData.userName}</span>
                    </div>
                    <div>
                      <span className="text-[#a7a8ae]">Módulo Completado:</span>
                      <span className="text-white ml-2">{certificateData.moduleName}</span>
                    </div>
                  </div>
                </div>

                {/* Verification Note */}
                <div className="bg-[#2f2f32] rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className="bg-green-600">Verificable</Badge>
                    <span className="text-sm text-white">Este certificado puede ser verificado</span>
                  </div>
                  <p className="text-xs text-[#a7a8ae]">
                    El certificado incluye un identificador único que permite verificar su autenticidad. 
                    Guarda este documento como prueba de tu logro académico.
                  </p>
                </div>

                {/* Navigation */}
                <div className="flex gap-4">
                  <Button
                    variant="outline"
                    onClick={() => router.push('/dashboard')}
                    className="flex-1 bg-[#2f2f32] border-[#45454a] text-white hover:bg-[#45454a]"
                  >
                    Ir al Dashboard
                  </Button>
                  <Button
                    onClick={() => router.push('/modules/fundamentos')}
                    className="flex-1 bg-[#4FBDBA] hover:bg-[#4FBDBA]/90 text-white"
                  >
                    Continuar Aprendiendo
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}