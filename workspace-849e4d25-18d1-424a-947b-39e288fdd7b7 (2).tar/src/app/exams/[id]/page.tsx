"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { CheckCircle, XCircle, Clock, ArrowLeft, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Question {
  id: string;
  question: string;
  type: "multiple-choice";
  options: string[];
  correct: number;
  explanation: string;
}

interface Exam {
  id: string;
  title: string;
  description: string;
  timeLimit: string;
  questions: Question[];
}

interface ExamResult {
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  passed: boolean;
  answers: Record<string, number>;
  timeSpent: number;
}

export default function ExamPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const examId = params.id as string;
  
  const [exam, setExam] = useState<Exam | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<ExamResult | null>(null);
  const [startTime] = useState(Date.now());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load exam data (in real app, this would come from API)
    const loadExam = async () => {
      // Mock exam data
      const mockExam: Exam = {
        id: examId,
        title: "Examen Final: Fundamentos de IA",
        description: "Evalúa tus conocimientos sobre los conceptos fundamentales",
        timeLimit: "60 min",
        questions: [
          {
            id: "1",
            question: "¿Qué es la Inteligencia Artificial?",
            type: "multiple-choice",
            options: [
              "La capacidad de las máquinas para pensar como humanos",
              "La simulación de procesos de inteligencia humana por máquinas",
              "La programación de robots para tareas específicas",
              "El uso de algoritmos para procesar datos"
            ],
            correct: 1,
            explanation: "La IA es la simulación de procesos de inteligencia humana por máquinas, especialmente sistemas informáticos."
          },
          {
            id: "2",
            question: "¿Cuál es la diferencia entre Machine Learning y Deep Learning?",
            type: "multiple-choice",
            options: [
              "Deep Learning usa más datos",
              "Deep Learning es un subconjunto de ML que usa redes neuronales profundas",
              "Machine Learning es más antiguo que Deep Learning",
              "No hay diferencia, son sinónimos"
            ],
            correct: 1,
            explanation: "Deep Learning es un subconjunto de Machine Learning que utiliza redes neuronales con múltiples capas."
          },
          {
            id: "3",
            question: "¿Qué es el sobreajuste (overfitting) en Machine Learning?",
            type: "multiple-choice",
            options: [
              "Cuando el modelo no aprende nada",
              "Cuando el modelo memoriza los datos de entrenamiento pero no generaliza",
              "Cuando el modelo es demasiado simple",
              "Cuando el modelo requiere mucho tiempo de entrenamiento"
            ],
            correct: 1,
            explanation: "El sobreajuste ocurre cuando el modelo aprende demasiado bien los datos de entrenamiento pero no puede generalizar a datos nuevos."
          }
        ]
      };

      setExam(mockExam);
      setTimeLeft(60 * 60); // 60 minutes in seconds
      setLoading(false);
    };

    loadExam();
  }, [examId]);

  useEffect(() => {
    if (timeLeft > 0 && !result) {
      const timer = setTimeout(() => {
        setTimeLeft(timeLeft - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !result) {
      handleSubmitExam();
    }
  }, [timeLeft, result]);

  const handleAnswerSelect = (questionId: string, answerIndex: number) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answerIndex
    }));
  };

  const handleSubmitExam = async () => {
    if (!exam) return;

    setIsSubmitting(true);
    
    // Calculate results
    let correctAnswers = 0;
    const processedAnswers: Record<string, number> = {};
    
    exam.questions.forEach(question => {
      const userAnswer = answers[question.id];
      if (userAnswer !== undefined) {
        processedAnswers[question.id] = userAnswer;
        if (userAnswer === question.correct) {
          correctAnswers++;
        }
      }
    });

    const score = Math.round((correctAnswers / exam.questions.length) * 100);
    const passed = score >= 70;
    const timeSpent = Math.floor((Date.now() - startTime) / 1000);

    const examResult: ExamResult = {
      score,
      totalQuestions: exam.questions.length,
      correctAnswers,
      passed,
      answers: processedAnswers,
      timeSpent
    };

    setResult(examResult);
    setIsSubmitting(false);

    // Save progress
    if (typeof window !== 'undefined') {
      const progressManager = (await import('@/lib/progress')).default;
      progressManager.updateExamProgress(examId, 'module-id', score, passed, processedAnswers);
    }

    if (passed) {
      toast({
        title: "¡Felicidades!",
        description: `Has aprobado el examen con ${score}% de aciertos.`,
      });
    } else {
      toast({
        title: "No aprobado",
        description: `Tu puntuación es ${score}%. Necesitas 70% para aprobar.`,
        variant: "destructive",
      });
    }
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleRetry = () => {
    setResult(null);
    setAnswers({});
    setCurrentQuestion(0);
    setTimeLeft(60 * 60);
  };

  if (loading) {
    return (
      <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden" style={{ fontFamily: '"Work Sans", "Noto Sans", sans-serif' }}>
        <div className="flex items-center justify-center h-screen">
          <div className="text-white">Cargando examen...</div>
        </div>
      </div>
    );
  }

  if (!exam) {
    return (
      <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden" style={{ fontFamily: '"Work Sans", "Noto Sans", sans-serif' }}>
        <div className="flex items-center justify-center h-screen">
          <div className="text-white">Examen no encontrado</div>
        </div>
      </div>
    );
  }

  if (result) {
    return (
      <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden" style={{ fontFamily: '"Work Sans", "Noto Sans", sans-serif' }}>
        <div className="layout-container flex h-full grow flex-col">
          {/* Navigation */}
          <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#2f2f32] px-10 py-3">
            <div className="flex items-center gap-4 text-white">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => router.back()}
                className="text-[#a7a8ae] hover:text-white p-0"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Volver
              </Button>
              <div className="size-4">
                <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M24 45.8096C19.6865 45.8096 15.4698 44.5305 11.8832 42.134C8.29667 39.7376 5.50128 36.3314 3.85056 32.3462C2.19985 28.361 1.76794 23.9758 2.60947 19.7452C3.451 15.5145 5.52816 11.6284 8.57829 8.5783C11.6284 5.52817 15.5145 3.45101 19.7452 2.60948C23.9758 1.76795 28.361 2.19986 32.3462 3.85057C36.3314 5.50129 39.7376 8.29668 42.134 11.8833C44.5305 15.4698 45.8096 19.6865 45.8096 24L24 24L24 45.8096Z" fill="currentColor"></path>
                </svg>
              </div>
              <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">AI Pathfinders 2025</h2>
            </div>
          </header>

          <div className="px-4 sm:px-6 lg:px-8 flex flex-1 justify-center py-5">
            <div className="layout-content-container flex flex-col max-w-[800px] flex-1 w-full space-y-6">
              <Card className="bg-[#1e202f] border-[#2f2f32] text-white">
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center ${result.passed ? 'bg-green-500' : 'bg-red-500'}`}>
                    {result.passed ? (
                      <CheckCircle className="w-8 h-8 text-white" />
                    ) : (
                      <XCircle className="w-8 h-8 text-white" />
                    )}
                  </div>
                  <CardTitle className={`text-2xl ${result.passed ? 'text-green-500' : 'text-red-500'}`}>
                    {result.passed ? '¡Examen Aprobado!' : 'Examen No Aprobado'}
                  </CardTitle>
                  <CardDescription>
                    Tu puntuación: {result.score}% ({result.correctAnswers}/{result.totalQuestions} respuestas correctas)
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-[#4FBDBA]">{result.score}%</div>
                      <div className="text-sm text-[#a7a8ae]">Puntuación</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-[#FFB703]">{Math.floor(result.timeSpent / 60)}m {result.timeSpent % 60}s</div>
                      <div className="text-sm text-[#a7a8ae]">Tiempo</div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Resumen de Respuestas</h3>
                    {exam.questions.map((question, index) => {
                      const userAnswer = result.answers[question.id];
                      const isCorrect = userAnswer === question.correct;
                      
                      return (
                        <div key={question.id} className="border border-[#2f2f32] rounded-lg p-4">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-medium">{index + 1}. {question.question}</h4>
                            <div className="flex items-center gap-2">
                              {isCorrect ? (
                                <CheckCircle className="w-5 h-5 text-green-500" />
                              ) : (
                                <XCircle className="w-5 h-5 text-red-500" />
                              )}
                              <Badge variant={isCorrect ? "default" : "destructive"}>
                                {isCorrect ? 'Correcta' : 'Incorrecta'}
                              </Badge>
                            </div>
                          </div>
                          <div className="space-y-2 text-sm">
                            <div>
                              <span className="text-[#a7a8ae]">Tu respuesta: </span>
                              <span className={isCorrect ? 'text-green-500' : 'text-red-500'}>
                                {userAnswer !== undefined ? question.options[userAnswer] : 'No respondida'}
                              </span>
                            </div>
                            {!isCorrect && (
                              <div>
                                <span className="text-[#a7a8ae]">Respuesta correcta: </span>
                                <span className="text-green-500">{question.options[question.correct]}</span>
                              </div>
                            )}
                            <div className="text-[#a7a8ae] italic">{question.explanation}</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="flex gap-4">
                    <Button 
                      onClick={handleRetry}
                      className="flex-1 bg-[#4FBDBA] hover:bg-[#4FBDBA]/90 text-white"
                    >
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Reintentar
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => router.push('/modules/fundamentos')}
                      className="flex-1 bg-[#2f2f32] border-[#45454a] text-white hover:bg-[#45454a]"
                    >
                      Volver al Módulo
                    </Button>
                  </div>

                  {result.passed && (
                    <Button 
                      onClick={() => router.push(`/certificate/${examId}`)}
                      className="w-full bg-green-600 hover:bg-green-700 text-white"
                    >
                      Ver Certificado
                    </Button>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const question = exam.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / exam.questions.length) * 100;

  return (
    <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden" style={{ fontFamily: '"Work Sans", "Noto Sans", sans-serif' }}>
      <div className="layout-container flex h-full grow flex-col">
        {/* Navigation */}
        <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#2f2f32] px-10 py-3">
          <div className="flex items-center gap-4 text-white">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => router.back()}
              className="text-[#a7a8ae] hover:text-white p-0"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver
            </Button>
            <div className="size-4">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 45.8096C19.6865 45.8096 15.4698 44.5305 11.8832 42.134C8.29667 39.7376 5.50128 36.3314 3.85056 32.3462C2.19985 28.361 1.76794 23.9758 2.60947 19.7452C3.451 15.5145 5.52816 11.6284 8.57829 8.5783C11.6284 5.52817 15.5145 3.45101 19.7452 2.60948C23.9758 1.76795 28.361 2.19986 32.3462 3.85057C36.3314 5.50129 39.7376 8.29668 42.134 11.8833C44.5305 15.4698 45.8096 19.6865 45.8096 24L24 24L24 45.8096Z" fill="currentColor"></path>
              </svg>
            </div>
            <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">AI Pathfinders 2025</h2>
          </div>
          <div className="flex items-center gap-4 text-white">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span className="font-mono">{formatTime(timeLeft)}</span>
            </div>
          </div>
        </header>

        <div className="px-4 sm:px-6 lg:px-8 flex flex-1 justify-center py-5">
          <div className="layout-content-container flex flex-col max-w-[800px] flex-1 w-full space-y-6">
            {/* Progress */}
            <Card className="bg-[#1e202f] border-[#2f2f32]">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-white font-medium">Progreso del Examen</h3>
                  <span className="text-white text-sm font-medium">
                    Pregunta {currentQuestion + 1} de {exam.questions.length}
                  </span>
                </div>
                <Progress value={progress} className="h-2" />
              </CardContent>
            </Card>

            {/* Question */}
            <Card className="bg-[#1e202f] border-[#2f2f32]">
              <CardHeader>
                <CardTitle className="text-white">
                  {currentQuestion + 1}. {question.question}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <RadioGroup
                  value={answers[question.id]?.toString() || ""}
                  onValueChange={(value) => handleAnswerSelect(question.id, parseInt(value))}
                >
                  {question.options.map((option, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                      <Label htmlFor={`option-${index}`} className="text-white cursor-pointer">
                        {option}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Navigation */}
            <div className="flex justify-between">
              <Button
                variant="outline"
                onClick={() => setCurrentQuestion(prev => Math.max(0, prev - 1))}
                disabled={currentQuestion === 0}
                className="bg-[#2f2f32] border-[#45454a] text-white hover:bg-[#45454a]"
              >
                Anterior
              </Button>
              
              {currentQuestion === exam.questions.length - 1 ? (
                <Button
                  onClick={handleSubmitExam}
                  disabled={isSubmitting}
                  className="bg-[#4FBDBA] hover:bg-[#4FBDBA]/90 text-white"
                >
                  {isSubmitting ? "Enviando..." : "Finalizar Examen"}
                </Button>
              ) : (
                <Button
                  onClick={() => setCurrentQuestion(prev => Math.min(exam.questions.length - 1, prev + 1))}
                  className="bg-[#4FBDBA] hover:bg-[#4FBDBA]/90 text-white"
                >
                  Siguiente
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}