"use client";

import { useState, useEffect } from "react";
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth.tsx";
import { BookOpen, Clock, Users, Star, ArrowLeft, Play, Award } from "lucide-react";

interface Module {
  id: string;
  title: string;
  description: string;
  difficulty: "Principiante" | "Intermedio" | "Avanzado";
  duration: string;
  lessons: Array<{
    id: string;
    title: string;
    description: string;
    duration: string;
    type: string;
    content: string;
  }>;
  practices: Array<{
    id: string;
    title: string;
    description: string;
    difficulty: string;
    instructions: string;
  }>;
  exam: {
    id: string;
    title: string;
    description: string;
    timeLimit: string;
    questions: Array<{
      id: string;
      question: string;
      type: string;
      options: string[];
      correct: number;
      explanation: string;
    }>;
  };
}

interface ModuleProgress {
  moduleId: string;
  overallProgress: number;
  completed: boolean;
  lastAccessed: string;
}

export default function ModulesPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user } = useAuth();
  const [modules, setModules] = useState<Module[]>([]);
  const [progress, setProgress] = useState<Record<string, ModuleProgress>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchModules();
    fetchProgress();
  }, []);

  const fetchModules = async () => {
    try {
      const response = await fetch("/api/modules");
      if (response.ok) {
        const data = await response.json();
        setModules(data.modules || []);
      } else {
        throw new Error("Failed to load modules");
      }
    } catch (error) {
      console.error("Error fetching modules:", error);
      toast({
        title: "Error de carga",
        description: "No se pudieron cargar los módulos. Por favor intenta nuevamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchProgress = () => {
    if (typeof window !== 'undefined') {
      const savedProgress = localStorage.getItem('ai-pathfinders-progress');
      if (savedProgress) {
        try {
          const progressData = JSON.parse(savedProgress);
          const progressMap: Record<string, ModuleProgress> = {};
          
          progressData.modules?.forEach((moduleProgress: any) => {
            progressMap[moduleProgress.moduleId] = {
              moduleId: moduleProgress.moduleId,
              overallProgress: moduleProgress.overallProgress || 0,
              completed: moduleProgress.overallProgress === 100,
              lastAccessed: moduleProgress.lastAccessed
            };
          });
          
          setProgress(progressMap);
        } catch (error) {
          console.error("Error parsing progress:", error);
        }
      }
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Principiante": return "bg-green-100 text-green-800";
      case "Intermedio": return "bg-yellow-100 text-yellow-800";
      case "Avanzado": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getDifficultyIcon = (difficulty: string) => {
    switch (difficulty) {
      case "Principiante": return "🌱";
      case "Intermedio": return "🌿";
      case "Avanzado": return "🌳";
      default: return "📚";
    }
  };

  const startModule = (moduleId: string) => {
    if (!user) {
      toast({
        title: "Inicia sesión",
        description: "Por favor inicia sesión para acceder a los módulos.",
        variant: "destructive",
      });
      router.push('/auth/login');
      return;
    }
    router.push(`/modules/${moduleId}`);
  };

  const viewCertificate = (moduleId: string) => {
    router.push(`/certificate/${moduleId}-attempt-1`);
  };

  if (loading) {
    return (
      <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden font-sans">
        <div className="flex h-full grow flex-col">
          {/* Navigation */}
          <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#2f2f32] px-4 sm:px-6 lg:px-10 py-3">
            <div className="flex items-center gap-4 text-white">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => router.back()}
                className="text-[#a7a8ae] hover:text-white p-0 pointer-events-auto"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Volver
              </Button>
              <div className="size-4">
                <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M24 45.8096C19.6865 45.8096 15.4698 44.5305 11.8832 42.134C8.29667 39.7376 5.50128 36.3314 3.85056 32.3462C2.19985 28.361 1.76794 23.9758 2.60947 19.7452C3.451 15.5145 5.52816 11.6284 8.57829 8.5783C11.6284 5.52817 15.5145 3.45101 19.7452 2.60948C23.9758 1.76795 28.361 2.19986 32.3462 3.85057C36.3314 5.50129 39.7376 8.29668 42.134 11.8833C44.5305 15.4698 45.8096 19.6865 45.8096 24L24 24L24 45.8096Z" fill="currentColor"></path>
                </svg>
              </div>
              <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">AI Pathfinders 2025</h2>
            </div>
          </header>

          <div className="mx-auto max-w-screen-xl px-4 sm:px-6 lg:px-8 flex flex-1 justify-center py-5">
            <div className="flex flex-col max-w-[1200px] flex-1 w-full space-y-6">
              <div className="text-center mb-8">
                <h1 className="text-white text-4xl font-bold leading-tight mb-4">Módulos de Aprendizaje</h1>
                <p className="text-[#a7a8ae] text-lg">Cargando módulos...</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {Array.from({ length: 6 }).map((_, index) => (
                  <Card key={index} className="bg-[#1e202f] border-[#2f2f32]">
                    <CardHeader>
                      <Skeleton className="h-6 w-3/4 bg-[#2f2f32]" />
                      <Skeleton className="h-4 w-full bg-[#2f2f32]" />
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <Skeleton className="h-4 w-full bg-[#2f2f32]" />
                        <Skeleton className="h-4 w-5/6 bg-[#2f2f32]" />
                        <div className="flex gap-2">
                          <Skeleton className="h-6 w-20 bg-[#2f2f32]" />
                          <Skeleton className="h-6 w-24 bg-[#2f2f32]" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden font-sans">
      <div className="flex h-full grow flex-col">
        {/* Navigation */}
        <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#2f2f32] px-4 sm:px-6 lg:px-10 py-3">
          <div className="flex items-center gap-4 text-white">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => router.back()}
              className="text-[#a7a8ae] hover:text-white p-0 pointer-events-auto"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver
            </Button>
            <div className="size-4">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 45.8096C19.6865 45.8096 15.4698 44.5305 11.8832 42.134C8.29667 39.7376 5.50128 36.3314 3.85056 32.3462C2.19985 28.361 1.76794 23.9758 2.60947 19.7452C3.451 15.5145 5.52816 11.6284 8.57829 8.5783C11.6284 5.52817 15.5145 3.45101 19.7452 2.60948C23.9758 1.76795 28.361 2.19986 32.3462 3.85057C36.3314 5.50129 39.7376 8.29668 42.134 11.8833C44.5305 15.4698 45.8096 19.6865 45.8096 24L24 24L24 45.8096Z" fill="currentColor"></path>
              </svg>
            </div>
            <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">AI Pathfinders 2025</h2>
          </div>
          <div className="flex flex-1 justify-end gap-4 sm:gap-8">
            <div className="flex items-center gap-4 sm:gap-9">
              <button 
                onClick={() => router.push('/')}
                className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors cursor-pointer pointer-events-auto"
              >
                Inicio
              </button>
              <button 
                onClick={() => router.push('/modules')}
                className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors cursor-pointer pointer-events-auto"
              >
                Módulos
              </button>
              <button 
                onClick={() => router.push('/trends')}
                className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors cursor-pointer pointer-events-auto"
              >
                Tendencias
              </button>
              <a className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors" href="#">Comunidad</a>
              <a className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors" href="#">Recursos</a>
            </div>
          </div>
        </header>

        <div className="mx-auto max-w-screen-xl px-4 sm:px-6 lg:px-8 flex flex-1 justify-center py-5">
          <div className="flex flex-col max-w-[1200px] flex-1 w-full space-y-6">
            {/* Header */}
            <div className="text-center mb-8">
              <h1 className="text-white text-4xl font-bold leading-tight mb-4">
                Módulos de Aprendizaje
              </h1>
              <p className="text-[#a7a8ae] text-lg max-w-2xl mx-auto">
                Explora nuestros módulos educativos diseñados para llevarte desde los fundamentos 
                hasta conceptos avanzados de inteligencia artificial.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6 text-center">
                  <BookOpen className="w-8 h-8 text-[#4FBDBA] mx-auto mb-2" />
                  <div className="text-2xl font-bold text-white">{modules.length}</div>
                  <div className="text-sm text-[#a7a8ae]">Módulos</div>
                </CardContent>
              </Card>
              
              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6 text-center">
                  <Clock className="w-8 h-8 text-[#FFB703] mx-auto mb-2" />
                  <div className="text-2xl font-bold text-white">
                    {modules.reduce((sum, module) => sum + module.lessons.length, 0)}
                  </div>
                  <div className="text-sm text-[#a7a8ae]">Lecciones</div>
                </CardContent>
              </Card>
              
              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6 text-center">
                  <Play className="w-8 h-8 text-green-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-white">
                    {modules.reduce((sum, module) => sum + module.practices.length, 0)}
                  </div>
                  <div className="text-sm text-[#a7a8ae]">Prácticas</div>
                </CardContent>
              </Card>
              
              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6 text-center">
                  <Award className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-white">
                    {Object.values(progress).filter(p => p.completed).length}
                  </div>
                  <div className="text-sm text-[#a7a8ae]">Completados</div>
                </CardContent>
              </Card>
            </div>

            {/* Modules Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {modules.map((module) => {
                const moduleProgress = progress[module.id];
                const isCompleted = moduleProgress?.completed || false;
                const progressPercentage = moduleProgress?.overallProgress || 0;

                return (
                  <Card 
                    key={module.id} 
                    className="bg-[#1e202f] border-[#2f2f32] hover:border-[#4FBDBA]/50 transition-all duration-200 hover:shadow-lg"
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-2xl">{getDifficultyIcon(module.difficulty)}</span>
                            <Badge className={getDifficultyColor(module.difficulty)}>
                              {module.difficulty}
                            </Badge>
                          </div>
                          <CardTitle className="text-white text-lg leading-tight mb-2">
                            {module.title}
                          </CardTitle>
                          <CardDescription className="text-[#a7a8ae] line-clamp-2">
                            {module.description}
                          </CardDescription>
                        </div>
                        {isCompleted && (
                          <div className="flex-shrink-0">
                            <Award className="w-6 h-6 text-green-500" />
                          </div>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Module Stats */}
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <div className="text-lg font-semibold text-white">{module.lessons.length}</div>
                          <div className="text-xs text-[#a7a8ae]">Lecciones</div>
                        </div>
                        <div>
                          <div className="text-lg font-semibold text-white">{module.practices.length}</div>
                          <div className="text-xs text-[#a7a8ae]">Prácticas</div>
                        </div>
                        <div>
                          <div className="text-lg font-semibold text-white">{module.exam.questions.length}</div>
                          <div className="text-xs text-[#a7a8ae]">Preguntas</div>
                        </div>
                      </div>

                      {/* Progress */}
                      {moduleProgress && (
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-[#a7a8ae]">Progreso</span>
                            <span className="text-white font-medium">{progressPercentage}%</span>
                          </div>
                          <Progress value={progressPercentage} className="h-2" />
                        </div>
                      )}

                      {/* Action Button */}
                      <Button
                        className={`w-full ${isCompleted ? 'bg-green-600 hover:bg-green-700' : 'bg-[#4FBDBA] hover:bg-[#4FBDBA]/90'} text-white pointer-events-auto`}
                        onClick={() => isCompleted ? viewCertificate(module.id) : startModule(module.id)}
                      >
                        {isCompleted ? (
                          <>
                            <Award className="w-4 h-4 mr-2" />
                            Ver Certificado
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            {progressPercentage > 0 ? 'Continuar' : 'Comenzar'}
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}