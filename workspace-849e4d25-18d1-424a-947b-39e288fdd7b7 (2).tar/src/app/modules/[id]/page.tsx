"use client";

import { useState, useEffect } from "react";
import { useRouter, useParams } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth.tsx";
import { ArrowLeft, Play, Clock, BookOpen, FileText, Award, CheckCircle, Circle } from "lucide-react";

interface Module {
  id: string;
  title: string;
  description: string;
  difficulty: "Principiante" | "Intermedio" | "Avanzado";
  duration: string;
  lessons: Array<{
    id: string;
    title: string;
    description: string;
    duration: string;
    type: string;
    content: string;
  }>;
  practices: Array<{
    id: string;
    title: string;
    description: string;
    difficulty: string;
    instructions: string;
  }>;
  exam: {
    id: string;
    title: string;
    description: string;
    timeLimit: string;
    questions: Array<{
      id: string;
      question: string;
      type: string;
      options: string[];
      correct: number;
      explanation: string;
    }>;
  };
}

interface ModuleProgress {
  moduleId: string;
  completedLessons: string[];
  completedPractices: string[];
  examCompleted: boolean;
  overallProgress: number;
  lastAccessed: string;
}

export default function ModulePage() {
  const router = useRouter();
  const params = useParams();
  const { toast } = useToast();
  const { user } = useAuth();
  const [module, setModule] = useState<Module | null>(null);
  const [progress, setProgress] = useState<ModuleProgress | null>(null);
  const [loading, setLoading] = useState(true);

  const moduleId = params.id as string;

  useEffect(() => {
    if (moduleId) {
      fetchModule();
      fetchProgress();
    }
  }, [moduleId]);

  const fetchModule = async () => {
    try {
      const response = await fetch("/api/modules");
      if (response.ok) {
        const data = await response.json();
        const foundModule = data.modules.find((m: Module) => m.id === moduleId);
        setModule(foundModule || null);
      } else {
        throw new Error("Failed to load module");
      }
    } catch (error) {
      console.error("Error fetching module:", error);
      toast({
        title: "Error de carga",
        description: "No se pudo cargar el módulo. Por favor intenta nuevamente.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchProgress = () => {
    if (typeof window !== 'undefined' && moduleId) {
      const savedProgress = localStorage.getItem('ai-pathfinders-progress');
      if (savedProgress) {
        try {
          const progressData = JSON.parse(savedProgress);
          const moduleProgress = progressData.modules?.find((m: any) => m.moduleId === moduleId);
          
          if (moduleProgress) {
            setProgress({
              moduleId: moduleProgress.moduleId,
              completedLessons: moduleProgress.completedLessons || [],
              completedPractices: moduleProgress.completedPractices || [],
              examCompleted: moduleProgress.examCompleted || false,
              overallProgress: moduleProgress.overallProgress || 0,
              lastAccessed: moduleProgress.lastAccessed
            });
          } else {
            // Initialize progress for this module
            const newProgress: ModuleProgress = {
              moduleId,
              completedLessons: [],
              completedPractices: [],
              examCompleted: false,
              overallProgress: 0,
              lastAccessed: new Date().toISOString()
            };
            setProgress(newProgress);
            saveProgress(newProgress);
          }
        } catch (error) {
          console.error("Error parsing progress:", error);
        }
      }
    }
  };

  const saveProgress = (newProgress: ModuleProgress) => {
    if (typeof window !== 'undefined') {
      const savedProgress = localStorage.getItem('ai-pathfinders-progress');
      let progressData = { modules: [] };
      
      if (savedProgress) {
        try {
          progressData = JSON.parse(savedProgress);
        } catch (error) {
          console.error("Error parsing progress:", error);
        }
      }
      
      const existingIndex = progressData.modules.findIndex((m: any) => m.moduleId === moduleId);
      if (existingIndex >= 0) {
        progressData.modules[existingIndex] = newProgress;
      } else {
        progressData.modules.push(newProgress);
      }
      
      localStorage.setItem('ai-pathfinders-progress', JSON.stringify(progressData));
      setProgress(newProgress);
    }
  };

  const completeLesson = (lessonId: string) => {
    if (!progress || !user) return;
    
    const updatedProgress: ModuleProgress = {
      ...progress,
      completedLessons: [...progress.completedLessons, lessonId],
      lastAccessed: new Date().toISOString()
    };
    
    // Calculate new progress
    const totalItems = module?.lessons.length + module?.practices.length + 1 || 1; // +1 for exam
    const completedItems = updatedProgress.completedLessons.length + updatedProgress.completedPractices.length + (updatedProgress.examCompleted ? 1 : 0);
    updatedProgress.overallProgress = Math.round((completedItems / totalItems) * 100);
    
    saveProgress(updatedProgress);
    
    toast({
      title: "Lección completada",
      description: "¡Has completado una lección!",
    });
  };

  const completePractice = (practiceId: string) => {
    if (!progress || !user) return;
    
    const updatedProgress: ModuleProgress = {
      ...progress,
      completedPractices: [...progress.completedPractices, practiceId],
      lastAccessed: new Date().toISOString()
    };
    
    // Calculate new progress
    const totalItems = module?.lessons.length + module?.practices.length + 1 || 1;
    const completedItems = updatedProgress.completedLessons.length + updatedProgress.completedPractices.length + (updatedProgress.examCompleted ? 1 : 0);
    updatedProgress.overallProgress = Math.round((completedItems / totalItems) * 100);
    
    saveProgress(updatedProgress);
    
    toast({
      title: "Práctica completada",
      description: "¡Has completado una práctica!",
    });
  };

  const startExam = () => {
    if (!user) {
      toast({
        title: "Inicia sesión",
        description: "Por favor inicia sesión para acceder al examen.",
        variant: "destructive",
      });
      router.push('/auth/login');
      return;
    }
    router.push(`/exams/${module?.exam.id}`);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Principiante": return "bg-green-100 text-green-800";
      case "Intermedio": return "bg-yellow-100 text-yellow-800";
      case "Avanzado": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (loading) {
    return (
      <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden font-sans">
        <div className="flex h-full grow flex-col items-center justify-center">
          <div className="text-white">Cargando módulo...</div>
        </div>
      </div>
    );
  }

  if (!module) {
    return (
      <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden font-sans">
        <div className="flex h-full grow flex-col items-center justify-center">
          <div className="text-white">Módulo no encontrado</div>
          <Button 
            onClick={() => router.push('/modules')}
            className="mt-4 bg-[#4FBDBA] hover:bg-[#4FBDBA]/90 text-white pointer-events-auto"
          >
            Volver a Módulos
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden font-sans">
      <div className="flex h-full grow flex-col">
        {/* Navigation */}
        <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#2f2f32] px-4 sm:px-6 lg:px-10 py-3">
          <div className="flex items-center gap-4 text-white">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => router.back()}
              className="text-[#a7a8ae] hover:text-white p-0 pointer-events-auto"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver
            </Button>
            <div className="size-4">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 45.8096C19.6865 45.8096 15.4698 44.5305 11.8832 42.134C8.29667 39.7376 5.50128 36.3314 3.85056 32.3462C2.19985 28.361 1.76794 23.9758 2.60947 19.7452C3.451 15.5145 5.52816 11.6284 8.57829 8.5783C11.6284 5.52817 15.5145 3.45101 19.7452 2.60948C23.9758 1.76795 28.361 2.19986 32.3462 3.85057C36.3314 5.50129 39.7376 8.29668 42.134 11.8833C44.5305 15.4698 45.8096 19.6865 45.8096 24L24 24L24 45.8096Z" fill="currentColor"></path>
              </svg>
            </div>
            <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">AI Pathfinders 2025</h2>
          </div>
        </header>

        <div className="mx-auto max-w-screen-xl px-4 sm:px-6 lg:px-8 flex flex-1 justify-center py-5">
          <div className="flex flex-col max-w-[1200px] flex-1 w-full space-y-6">
            {/* Module Header */}
            <div className="text-center mb-8">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Badge className={getDifficultyColor(module.difficulty)}>
                  {module.difficulty}
                </Badge>
                <span className="text-[#a7a8ae] text-sm">{module.duration}</span>
              </div>
              <h1 className="text-white text-4xl font-bold leading-tight mb-4">
                {module.title}
              </h1>
              <p className="text-[#a7a8ae] text-lg max-w-2xl mx-auto">
                {module.description}
              </p>
              
              {progress && (
                <div className="mt-6 max-w-md mx-auto">
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-[#a7a8ae]">Progreso general</span>
                    <span className="text-white font-medium">{progress.overallProgress}%</span>
                  </div>
                  <Progress value={progress.overallProgress} className="h-2" />
                </div>
              )}
            </div>

            {/* Module Content */}
            <Tabs defaultValue="lessons" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-[#1e202f] border-[#2f2f32]">
                <TabsTrigger value="lessons" className="data-[state=active]:bg-[#4FBDBA] data-[state=active]:text-white">
                  Lecciones
                </TabsTrigger>
                <TabsTrigger value="practices" className="data-[state=active]:bg-[#4FBDBA] data-[state=active]:text-white">
                  Prácticas
                </TabsTrigger>
                <TabsTrigger value="exam" className="data-[state=active]:bg-[#4FBDBA] data-[state=active]:text-white">
                  Examen
                </TabsTrigger>
              </TabsList>

              <TabsContent value="lessons" className="space-y-4">
                <div className="grid gap-4">
                  {module.lessons.map((lesson) => {
                    const isCompleted = progress?.completedLessons.includes(lesson.id) || false;
                    
                    return (
                      <Card key={lesson.id} className="bg-[#1e202f] border-[#2f2f32]">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                {isCompleted ? (
                                  <CheckCircle className="w-5 h-5 text-green-500" />
                                ) : (
                                  <Circle className="w-5 h-5 text-[#a7a8ae]" />
                                )}
                                <CardTitle className="text-white text-lg">{lesson.title}</CardTitle>
                              </div>
                              <CardDescription className="text-[#a7a8ae]">
                                {lesson.description}
                              </CardDescription>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-[#a7a8ae]">
                              <Clock className="w-4 h-4" />
                              {lesson.duration}
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center justify-between">
                            <Badge variant="outline" className="bg-[#2f2f32] border-[#45454a] text-white">
                              {lesson.type === 'video' ? 'Video' : 'Lectura'}
                            </Badge>
                            <Button
                              onClick={() => completeLesson(lesson.id)}
                              disabled={isCompleted || !user}
                              className={`${isCompleted ? 'bg-green-600 hover:bg-green-700' : 'bg-[#4FBDBA] hover:bg-[#4FBDBA]/90'} text-white pointer-events-auto`}
                            >
                              {isCompleted ? 'Completado' : 'Completar'}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>

              <TabsContent value="practices" className="space-y-4">
                <div className="grid gap-4">
                  {module.practices.map((practice) => {
                    const isCompleted = progress?.completedPractices.includes(practice.id) || false;
                    
                    return (
                      <Card key={practice.id} className="bg-[#1e202f] border-[#2f2f32]">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                {isCompleted ? (
                                  <CheckCircle className="w-5 h-5 text-green-500" />
                                ) : (
                                  <Circle className="w-5 h-5 text-[#a7a8ae]" />
                                )}
                                <CardTitle className="text-white text-lg">{practice.title}</CardTitle>
                              </div>
                              <CardDescription className="text-[#a7a8ae]">
                                {practice.description}
                              </CardDescription>
                            </div>
                            <Badge variant="outline" className="bg-[#2f2f32] border-[#45454a] text-white">
                              {practice.difficulty}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div className="text-sm text-[#a7a8ae]">
                              <strong>Instrucciones:</strong> {practice.instructions}
                            </div>
                            <Button
                              onClick={() => completePractice(practice.id)}
                              disabled={isCompleted || !user}
                              className={`${isCompleted ? 'bg-green-600 hover:bg-green-700' : 'bg-[#4FBDBA] hover:bg-[#4FBDBA]/90'} text-white pointer-events-auto`}
                            >
                              {isCompleted ? 'Completado' : 'Completar'}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>

              <TabsContent value="exam" className="space-y-4">
                <Card className="bg-[#1e202f] border-[#2f2f32]">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          {progress?.examCompleted ? (
                            <Award className="w-5 h-5 text-green-500" />
                          ) : (
                            <FileText className="w-5 h-5 text-[#a7a8ae]" />
                          )}
                          <CardTitle className="text-white text-lg">{module.exam.title}</CardTitle>
                        </div>
                        <CardDescription className="text-[#a7a8ae]">
                          {module.exam.description}
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-[#a7a8ae]">
                        <Clock className="w-4 h-4" />
                        {module.exam.timeLimit}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <BookOpen className="w-4 h-4 text-[#a7a8ae]" />
                          <span className="text-[#a7a8ae]">Preguntas:</span>
                          <span className="text-white">{module.exam.questions.length}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Award className="w-4 h-4 text-[#a7a8ae]" />
                          <span className="text-[#a7a8ae]">Estado:</span>
                          <span className={progress?.examCompleted ? "text-green-500" : "text-[#a7a8ae]"}>
                            {progress?.examCompleted ? "Completado" : "Pendiente"}
                          </span>
                        </div>
                      </div>
                      
                      <Button
                        onClick={startExam}
                        disabled={progress?.examCompleted || !user}
                        className={`${progress?.examCompleted ? 'bg-green-600 hover:bg-green-700' : 'bg-[#4FBDBA] hover:bg-[#4FBDBA]/90'} text-white pointer-events-auto w-full`}
                      >
                        {progress?.examCompleted ? (
                          <>
                            <Award className="w-4 h-4 mr-2" />
                            Examen Completado
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Comenzar Examen
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}