import { NextRequest, NextResponse } from 'next/server';
import { readFileSync } from 'fs';
import { join } from 'path';

interface Trend {
  id: string;
  title: string;
  description: string;
  source: string;
  authors: string[];
  published: string;
  url: string;
  category: string;
  summary: string;
}

// Cache control constants
const CACHE_DURATION = 1800; // 30 minutes in seconds
const STALE_WHILE_REVALIDATE = 3600; // 1 hour
const MAX_RETRIES = 2;
const RETRY_DELAY = 1000; // 1 second

// Function to fetch trends from arXiv API using fast-xml-parser
async function fetchArXivTrends(retryCount = 0): Promise<Trend[]> {
  try {
    // Import fast-xml-parser dynamically
    const { XMLParser } = await import('fast-xml-parser');
    
    // Using arXiv API to get AI-related papers
    const query = 'cat:cs.AI OR ti:"artificial intelligence" OR ti:"machine learning" OR ti:"deep learning" OR ti:"neural networks"';
    const url = `http://export.arxiv.org/api/query?search_query=${encodeURIComponent(query)}&start=0&max_results=6&sortBy=submittedDate&sortOrder=descending`;
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'AI-Pathfinders-2025/1.0',
        'Accept': 'application/xml',
      },
      signal: AbortSignal.timeout(15000), // 15 seconds timeout
    });

    if (!response.ok) {
      throw new Error(`arXiv API error: ${response.status} ${response.statusText}`);
    }

    const xmlText = await response.text();
    
    // Parse XML using fast-xml-parser
    const parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: "@_",
      textNodeName: "#text",
      removeNSPrefix: true,
      parseAttributeValue: false,
      arrayMode: false
    });
    
    const result = parser.parse(xmlText);
    const papers = result.feed?.entry || [];
    
    if (!Array.isArray(papers)) {
      return [];
    }
    
    const trends: Trend[] = papers.map((paper: any, index: number) => {
      const authors = Array.isArray(paper.author) 
        ? paper.author.map((author: any) => author.name || author['#text'] || 'Unknown')
        : paper.author 
          ? [paper.author.name || paper.author['#text'] || 'Unknown']
          : [];
      
      const categories = Array.isArray(paper.category) 
        ? paper.category.map((cat: any) => cat['@_term'] || cat.term || 'cs.AI')
        : paper.category 
          ? [paper.category['@_term'] || paper.category.term || 'cs.AI']
          : ['cs.AI'];
      
      const links = Array.isArray(paper.link) 
        ? paper.link
        : paper.link 
          ? [paper.link]
          : [];
      
      const pdfLink = links.find((link: any) => link['@_title'] === 'pdf');
      const id = paper.id ? paper.id.split('/').pop() || `paper-${index}` : `paper-${index}`;
      
      return {
        id: id,
        title: paper.title || 'Sin título',
        description: paper.summary ? (paper.summary.length > 200 
          ? paper.summary.substring(0, 200) + '...' 
          : paper.summary) : 'Sin descripción disponible',
        source: `arXiv:${id}`,
        authors: authors,
        published: paper.published || new Date().toISOString(),
        url: pdfLink?.['@_href'] || `https://arxiv.org/abs/${id}`,
        category: categories[0] || 'cs.AI',
        summary: paper.summary || 'Sin resumen disponible'
      };
    });
    
    return trends;
  } catch (error) {
    console.error(`Error fetching from arXiv (attempt ${retryCount + 1}/${MAX_RETRIES + 1}):`, error);
    
    // Implement retry logic
    if (retryCount < MAX_RETRIES) {
      console.log(`Retrying in ${RETRY_DELAY}ms...`);
      await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
      return fetchArXivTrends(retryCount + 1);
    }
    
    // If all retries failed, use fallback
    console.log('All retries failed, using fallback data');
    return getFallbackTrends();
  }
}

// Fallback trends data
function getFallbackTrends(): Trend[] {
  try {
    const filePath = join(process.cwd(), 'data', 'trends.mock.json');
    const fileContent = readFileSync(filePath, 'utf-8');
    const fallbackData = JSON.parse(fileContent);
    return fallbackData.trends || [];
  } catch (error) {
    console.error('Error loading fallback trends:', error);
    return [];
  }
}

export async function GET(request: NextRequest) {
  try {
    const startTime = Date.now();
    
    // Try to fetch real data from arXiv API with retry mechanism
    const trends = await fetchArXivTrends();
    
    const response = NextResponse.json({
      trends,
      source: trends.length > 0 && trends[0].source.startsWith('arXiv') ? 'arXiv' : 'fallback',
      cached: false,
      timestamp: new Date().toISOString(),
      responseTime: Date.now() - startTime,
      totalResults: trends.length
    });
    
    // Set enhanced caching headers
    response.headers.set('Cache-Control', `public, s-maxage=${CACHE_DURATION}, stale-while-revalidate=${STALE_WHILE_REVALIDATE}`);
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    response.headers.set('X-Response-Time', `${Date.now() - startTime}`);
    
    console.log(`Trends API: ${trends.length} trends returned in ${Date.now() - startTime}ms`);
    
    return response;
  } catch (error) {
    console.error('Critical error in trends API:', error);
    
    // Emergency fallback - always return something
    const fallbackTrends = getFallbackTrends();
    const response = NextResponse.json({
      trends: fallbackTrends,
      source: 'emergency-fallback',
      cached: false,
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
      totalResults: fallbackTrends.length
    });
    
    // Set shorter cache for error responses
    response.headers.set('Cache-Control', `public, s-maxage=300, stale-while-revalidate=600`);
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    return response;
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400', // 24 hours
    },
  });
}