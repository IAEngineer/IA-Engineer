import { NextRequest, NextResponse } from 'next/server';
import { readFileSync } from 'fs';
import { join } from 'path';

// Cache control constants
const CACHE_DURATION = 3600; // 1 hour in seconds
const STALE_WHILE_REVALIDATE = 7200; // 2 hours

export async function GET(request: NextRequest) {
  try {
    const startTime = Date.now();
    
    // Read modules data from JSON file
    const filePath = join(process.cwd(), 'data', 'modules.json');
    const fileContent = readFileSync(filePath, 'utf-8');
    const modulesData = JSON.parse(fileContent);
    
    const response = NextResponse.json({
      modules: modulesData.modules || [],
      source: 'local-json',
      cached: false,
      timestamp: new Date().toISOString(),
      responseTime: Date.now() - startTime,
      totalModules: modulesData.modules?.length || 0
    });
    
    // Set caching headers
    response.headers.set('Cache-Control', `public, s-maxage=${CACHE_DURATION}, stale-while-revalidate=${STALE_WHILE_REVALIDATE}`);
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    response.headers.set('X-Response-Time', `${Date.now() - startTime}`);
    
    console.log(`Modules API: ${modulesData.modules?.length || 0} modules returned in ${Date.now() - startTime}ms`);
    
    return response;
  } catch (error) {
    console.error('Critical error in modules API:', error);
    
    // Emergency fallback - return empty modules array
    const response = NextResponse.json({
      modules: [],
      source: 'error-fallback',
      cached: false,
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
      totalModules: 0
    });
    
    // Set shorter cache for error responses
    response.headers.set('Cache-Control', `public, s-maxage=60, stale-while-revalidate=120`);
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    return response;
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400', // 24 hours
    },
  });
}