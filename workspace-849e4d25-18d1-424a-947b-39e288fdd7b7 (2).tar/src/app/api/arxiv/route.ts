import { NextRequest, NextResponse } from 'next/server';

interface ArXivPaper {
  id: string;
  title: string;
  summary: string;
  authors: string[];
  published: string;
  updated: string;
  categories: string[];
  links: {
    pdf?: string;
    doi?: string;
  };
}

interface Trend {
  id: string;
  title: string;
  description: string;
  source: string;
  authors: string[];
  published: string;
  url: string;
  category: string;
  summary: string;
}

// Cache control constants
const CACHE_DURATION = 3600; // 1 hour in seconds
const STALE_WHILE_REVALIDATE = 7200; // 2 hours
const MAX_RETRIES = 2;
const RETRY_DELAY = 1000; // 1 second

// Function to fetch papers from arXiv API with retry mechanism
async function fetchArXivPapers(retryCount = 0): Promise<ArXivPaper[]> {
  try {
    // Using arXiv API to get AI-related papers
    const query = 'cat:cs.AI OR ti:"artificial intelligence" OR ti:"machine learning" OR ti:"deep learning" OR ti:"neural networks"';
    const url = `http://export.arxiv.org/api/query?search_query=${encodeURIComponent(query)}&start=0&max_results=10&sortBy=submittedDate&sortOrder=descending`;
    
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'AI-Pathfinders-2025/1.0',
        'Accept': 'application/xml',
      },
      // Add timeout to prevent hanging requests
      signal: AbortSignal.timeout(15000), // 15 seconds timeout
    });

    if (!response.ok) {
      throw new Error(`arXiv API error: ${response.status} ${response.statusText}`);
    }

    const xmlText = await response.text();
    
    // Parse XML response
    const papers = parseArXivXML(xmlText);
    
    if (papers.length === 0) {
      console.warn('No papers found in arXiv response');
      return getFallbackPapers();
    }

    return papers;
  } catch (error) {
    console.error(`Error fetching from arXiv (attempt ${retryCount + 1}/${MAX_RETRIES + 1}):`, error);
    
    // Implement retry logic
    if (retryCount < MAX_RETRIES) {
      console.log(`Retrying in ${RETRY_DELAY}ms...`);
      await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
      return fetchArXivPapers(retryCount + 1);
    }
    
    // If all retries failed, use fallback
    console.log('All retries failed, using fallback data');
    return getFallbackPapers();
  }
}

// Function to parse arXiv XML response
function parseArXivXML(xmlText: string): ArXivPaper[] {
  const papers: ArXivPaper[] = [];
  
  try {
    // Simple XML parsing (in production, use a proper XML parser)
    const entries = xmlText.split('<entry>').slice(1); // Remove first empty element
    
    for (const entry of entries) {
      try {
        const idMatch = entry.match(/<id>(.*?)<\/id>/);
        const titleMatch = entry.match(/<title>(.*?)<\/title>/);
        const summaryMatch = entry.match(/<summary>(.*?)<\/summary>/);
        const publishedMatch = entry.match(/<published>(.*?)<\/published>/);
        const updatedMatch = entry.match(/<updated>(.*?)<\/updated>/);
        
        const authorMatches = entry.match(/<name>(.*?)<\/name>/g);
        const categoryMatches = entry.match(/<term>(.*?)<\/term>/g);
        const pdfMatch = entry.match(/<link title="pdf" href="(.*?)"/);
        
        if (idMatch && titleMatch && summaryMatch) {
          const paper: ArXivPaper = {
            id: idMatch[1],
            title: titleMatch[1].trim(),
            summary: summaryMatch[1].trim(),
            authors: authorMatches ? authorMatches.map(match => match.replace(/<name>|<\/name>/g, '')) : [],
            published: publishedMatch ? publishedMatch[1] : new Date().toISOString(),
            updated: updatedMatch ? updatedMatch[1] : new Date().toISOString(),
            categories: categoryMatches ? categoryMatches.map(match => match.replace(/<term>|<\/term>/g, '')) : [],
            links: {
              pdf: pdfMatch ? pdfMatch[1] : undefined
            }
          };
          
          papers.push(paper);
        }
      } catch (error) {
        console.error('Error parsing arXiv entry:', error);
      }
    }
  } catch (error) {
    console.error('Error parsing arXiv XML:', error);
  }
  
  return papers;
}

// Fallback papers data
function getFallbackPapers(): ArXivPaper[] {
  const now = new Date();
  return [
    {
      id: "fallback-1",
      title: "Avances en Modelos de Lenguaje Grandes",
      summary: "Los LLMs continúan revolucionando la industria con capacidades de razonamiento mejoradas y comprensión contextual sin precedentes. Nuevas arquitecturas permiten un procesamiento más eficiente del lenguaje natural.",
      authors: ["Smith, J.", "Johnson, M.", "Williams, K."],
      published: new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      updated: new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      categories: ["cs.CL", "cs.AI"],
      links: {}
    },
    {
      id: "fallback-2",
      title: "IA Multimodal: El Futuro de la Interacción",
      summary: "La integración de texto, imagen y audio en un solo modelo está cambiando la experiencia de usuario y creando nuevas posibilidades en aplicaciones empresariales y creativas.",
      authors: ["Chen, L.", "Rodriguez, S.", "Kim, H."],
      published: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      updated: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      categories: ["cs.CV", "cs.MM"],
      links: {}
    },
    {
      id: "fallback-3",
      title: "MLOps: Escalando Modelos en Producción",
      summary: "Nuevas herramientas y prácticas para desplegar modelos de IA a escala empresarial con monitoreo continuo, automatización y gestión de ciclos de vida completo.",
      authors: ["Brown, A.", "Davis, R.", "Miller, T."],
      published: new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      updated: new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      categories: ["cs.LG", "cs.DC"],
      links: {}
    },
    {
      id: "fallback-4",
      title: "IA Ética y Gobernanza",
      summary: "Las empresas implementan marcos de ética en IA para garantizar transparencia, equidad y responsabilidad en sistemas automatizados y toma de decisiones.",
      authors: ["Wilson, E.", "Garcia, M.", "Anderson, P."],
      published: new Date(now.getTime() - 4 * 24 * 60 * 60 * 1000).toISOString(),
      updated: new Date(now.getTime() - 4 * 24 * 60 * 60 * 1000).toISOString(),
      categories: ["cs.CY", "cs.AI"],
      links: {}
    },
    {
      id: "fallback-5",
      title: "AutoML: Democratizando el Machine Learning",
      summary: "Plataformas de AutoML están haciendo que el machine learning sea accesible para profesionales sin experiencia técnica profunda, acelerando la adopción empresarial.",
      authors: ["Taylor, J.", "Martinez, C.", "Lee, S."],
      published: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      updated: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      categories: ["cs.LG", "cs.AI"],
      links: {}
    },
    {
      id: "fallback-6",
      title: "IA en Edge Computing",
      summary: "El procesamiento de IA en dispositivos edge está reduciendo latencia y mejorando la privacidad en aplicaciones móviles, IoT y sistemas embebidos.",
      authors: ["White, R.", "Thompson, K.", "Clark, L."],
      published: new Date(now.getTime() - 6 * 24 * 60 * 60 * 1000).toISOString(),
      updated: new Date(now.getTime() - 6 * 24 * 60 * 60 * 1000).toISOString(),
      categories: ["cs.DC", "cs.AR"],
      links: {}
    }
  ];
}

// Transform arXiv papers to our trend format
function transformPapersToTrends(papers: ArXivPaper[]): Trend[] {
  return papers.map((paper, index) => ({
    id: paper.id,
    title: paper.title,
    description: paper.summary.length > 200 
      ? paper.summary.substring(0, 200) + '...' 
      : paper.summary,
    source: `arXiv:${paper.id.split('/').pop()}`,
    authors: paper.authors,
    published: paper.published,
    url: paper.links.pdf || `https://arxiv.org/abs/${paper.id.split('/').pop()}`,
    category: paper.categories[0] || 'cs.AI',
    summary: paper.summary
  }));
}

export async function GET(request: NextRequest) {
  try {
    const startTime = Date.now();
    
    // Try to fetch real data from arXiv API with retry mechanism
    const papers = await fetchArXivPapers();
    const trends = transformPapersToTrends(papers);
    
    const response = NextResponse.json({
      trends,
      source: papers[0]?.id.startsWith('fallback-') ? 'fallback' : 'arXiv',
      cached: false,
      timestamp: new Date().toISOString(),
      responseTime: Date.now() - startTime,
      totalResults: trends.length
    });
    
    // Set enhanced caching headers
    response.headers.set('Cache-Control', `public, s-maxage=${CACHE_DURATION}, stale-while-revalidate=${STALE_WHILE_REVALIDATE}`);
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    response.headers.set('X-Response-Time', `${Date.now() - startTime}`);
    
    console.log(`arXiv API: ${trends.length} trends returned in ${Date.now() - startTime}ms`);
    
    return response;
  } catch (error) {
    console.error('Critical error in arXiv API:', error);
    
    // Emergency fallback - always return something
    const fallbackPapers = getFallbackPapers();
    const fallbackTrends = transformPapersToTrends(fallbackPapers);
    const response = NextResponse.json({
      trends: fallbackTrends,
      source: 'emergency-fallback',
      cached: false,
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
      totalResults: fallbackTrends.length
    });
    
    // Set shorter cache for error responses
    response.headers.set('Cache-Control', `public, s-maxage=300, stale-while-revalidate=600`);
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    return response;
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400', // 24 hours
    },
  });
}