export interface params {
  id: string;
}