import { NextRequest, NextResponse } from 'next/server';

interface CertificateRequest {
  userId: string;
  moduleId: string;
  userName: string;
  userEmail: string;
  score: number;
  completionDate: string;
}

interface CertificateResponse {
  success: boolean;
  certificateId?: string;
  downloadUrl?: string;
  message: string;
}

// Mock certificate generation function
function generateCertificate(data: CertificateRequest): CertificateResponse {
  // In a real application, this would:
  // 1. Generate a PDF certificate
  // 2. Save it to cloud storage (AWS S3, Google Cloud Storage, etc.)
  // 3. Send email with certificate attached
  // 4. Return the download URL
  
  const certificateId = `cert_${data.userId}_${data.moduleId}_${Date.now()}`;
  const downloadUrl = `/api/certificate/download/${certificateId}`;
  
  // Simulate email sending
  console.log(`Sending certificate to ${data.userEmail} for module ${data.moduleId}`);
  
  return {
    success: true,
    certificateId,
    downloadUrl,
    message: "Certificado generado y enviado exitosamente"
  };
}

// Mock email sending function
async function sendCertificateEmail(userEmail: string, userName: string, certificateUrl: string, moduleName: string) {
  // In a real application, you would use a service like:
  // - SendGrid
  // - AWS SES
  // - Mailgun
  // - Resend
  
  console.log(`Email sent to ${userEmail}`);
  console.log(`Subject: ¡Felicidades ${userName}! Has completado el módulo ${moduleName}`);
  console.log(`Certificate URL: ${certificateUrl}`);
  
  return true;
}

export async function POST(request: NextRequest) {
  try {
    const body: CertificateRequest = await request.json();
    
    // Validate required fields
    const requiredFields = ['userId', 'moduleId', 'userName', 'userEmail', 'score', 'completionDate'];
    for (const field of requiredFields) {
      if (!body[field as keyof CertificateRequest]) {
        return NextResponse.json(
          { success: false, message: `El campo ${field} es requerido` },
          { status: 400 }
        );
      }
    }
    
    // Validate score (must be 70 or higher to pass)
    if (body.score < 70) {
      return NextResponse.json(
        { success: false, message: "Se requiere una puntuación mínima de 70% para obtener el certificado" },
        { status: 400 }
      );
    }
    
    // Generate certificate
    const certificateResult = generateCertificate(body);
    
    if (!certificateResult.success) {
      return NextResponse.json(
        { success: false, message: "Error al generar el certificado" },
        { status: 500 }
      );
    }
    
    // Send email with certificate
    try {
      await sendCertificateEmail(
        body.userEmail,
        body.userName,
        certificateResult.downloadUrl || '',
        body.moduleId
      );
    } catch (emailError) {
      console.error('Error sending email:', emailError);
      // Don't fail the request if email fails, just log it
    }
    
    // Return success response
    const response = NextResponse.json({
      success: true,
      certificateId: certificateResult.certificateId,
      downloadUrl: certificateResult.downloadUrl,
      message: "Certificado generado exitosamente y enviado a tu correo electrónico"
    });
    
    // Add CORS headers
    response.headers.set('Access-Control-Allow-Origin', '*');
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    
    return response;
    
  } catch (error) {
    console.error('Error generating certificate:', error);
    return NextResponse.json(
      { success: false, message: "Error interno del servidor" },
      { status: 500 }
    );
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}