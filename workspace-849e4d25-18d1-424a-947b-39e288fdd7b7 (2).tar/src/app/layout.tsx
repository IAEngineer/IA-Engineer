import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { AuthProviderWrapper } from "@/components/auth-provider";

export const metadata: Metadata = {
  title: "AI Pathfinders 2025 - Programa Educativo de Inteligencia Artificial",
  description: "Conviértete en experto de IA con nuestro programa educativo modular. Domina machine learning, deep learning, NLP y más con cursos prácticos y certificados.",
  keywords: ["AI Pathfinders", "Inteligencia Artificial", "Machine Learning", "Deep Learning", "NLP", "Curso IA", "Educación IA", "AI 2025"],
  authors: [{ name: "AI Pathfinders 2025 Team" }],
  openGraph: {
    title: "AI Pathfinders 2025 - Programa Educativo",
    description: "El programa educativo más completo para convertirte en experto de inteligencia artificial",
    url: "https://ai-pathfinders-2025.com",
    siteName: "AI Pathfinders 2025",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "AI Pathfinders 2025 - Programa Educativo",
    description: "Conviértete en experto de IA con nuestro programa educativo modular y práctico",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className="antialiased bg-background text-foreground font-sans"
      >
        <AuthProviderWrapper>
          <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden font-sans">
            {children}
          </div>
          <Toaster />
        </AuthProviderWrapper>
      </body>
    </html>
  );
}