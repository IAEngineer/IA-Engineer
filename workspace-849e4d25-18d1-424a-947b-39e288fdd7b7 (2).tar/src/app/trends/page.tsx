"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { RefreshCw, ExternalLink, Calendar, Users, TrendingUp } from "lucide-react";

interface Trend {
  id: string;
  title: string;
  description: string;
  source: string;
  authors: string[];
  published: string;
  url: string;
  category: string;
  summary: string;
}

export default function TrendsPage() {
  const { toast } = useToast();
  const [trends, setTrends] = useState<Trend[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchTrends();
  }, []);

  const fetchTrends = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetch("/api/trends");
      if (response.ok) {
        const data = await response.json();
        if (data.trends && Array.isArray(data.trends)) {
          setTrends(data.trends);
          console.log(`Loaded ${data.trends.length} trends from ${data.source}`);
        } else {
          throw new Error("Invalid response format");
        }
      } else {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
    } catch (error) {
      console.error("Error fetching trends:", error);
      setError(error instanceof Error ? error.message : "Unknown error");
      toast({
        title: "Error de carga",
        description: "No se pudieron cargar las tendencias de IA. Por favor intenta nuevamente.",
        variant: "destructive",
      });
      
      // Load fallback data
      try {
        const fallbackResponse = await fetch("/data/trends.mock.json");
        if (fallbackResponse.ok) {
          const fallbackData = await fallbackResponse.json();
          setTrends(fallbackData.trends);
        }
      } catch (fallbackError) {
        console.error("Error loading fallback data:", fallbackError);
      }
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return dateString;
    }
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'cs.AI': 'bg-blue-100 text-blue-800',
      'cs.CL': 'bg-purple-100 text-purple-800',
      'cs.CV': 'bg-green-100 text-green-800',
      'cs.LG': 'bg-yellow-100 text-yellow-800',
      'cs.DC': 'bg-red-100 text-red-800',
      'cs.CY': 'bg-indigo-100 text-indigo-800',
      'cs.MM': 'bg-pink-100 text-pink-800',
      'cs.AR': 'bg-teal-100 text-teal-800'
    };
    return colors[category] || 'bg-gray-100 text-gray-800';
  };

  const openTrend = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="relative flex size-full min-h-screen flex-col bg-[#141415] dark group/design-root overflow-x-hidden font-sans">
      <div className="flex h-full grow flex-col">
        {/* Navigation */}
        <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#2f2f32] px-4 sm:px-6 lg:px-10 py-3">
          <div className="flex items-center gap-4 text-white">
            <div className="size-4">
              <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M24 45.8096C19.6865 45.8096 15.4698 44.5305 11.8832 42.134C8.29667 39.7376 5.50128 36.3314 3.85056 32.3462C2.19985 28.361 1.76794 23.9758 2.60947 19.7452C3.451 15.5145 5.52816 11.6284 8.57829 8.5783C11.6284 5.52817 15.5145 3.45101 19.7452 2.60948C23.9758 1.76795 28.361 2.19986 32.3462 3.85057C36.3314 5.50129 39.7376 8.29668 42.134 11.8833C44.5305 15.4698 45.8096 19.6865 45.8096 24L24 24L24 45.8096Z" fill="currentColor"></path>
              </svg>
            </div>
            <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">AI Pathfinders 2025</h2>
          </div>
          <div className="flex flex-1 justify-end gap-4 sm:gap-8">
            <div className="flex items-center gap-4 sm:gap-9">
              <button 
                onClick={() => window.location.href = '/'}
                className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors cursor-pointer pointer-events-auto"
              >
                Inicio
              </button>
              <button 
                onClick={() => window.location.href = '/modules'}
                className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors cursor-pointer pointer-events-auto"
              >
                Módulos
              </button>
              <button 
                onClick={() => window.location.href = '/trends'}
                className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors cursor-pointer pointer-events-auto"
              >
                Tendencias
              </button>
              <a className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors" href="#">Comunidad</a>
              <a className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors" href="#">Recursos</a>
            </div>
          </div>
        </header>

        <div className="mx-auto max-w-screen-xl px-4 sm:px-6 lg:px-8 flex flex-1 justify-center py-5">
          <div className="flex flex-col max-w-[1200px] flex-1 w-full space-y-6">
            {/* Header */}
            <div className="text-center mb-8">
              <h1 className="text-white text-4xl font-bold leading-tight mb-4">
                Tendencias IA 2025
              </h1>
              <p className="text-[#a7a8ae] text-lg max-w-2xl mx-auto">
                Las últimas investigaciones y avances en inteligencia artificial directamente desde arXiv, 
                la fuente principal de papers académicos en IA.
              </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6 text-center">
                  <TrendingUp className="w-8 h-8 text-[#4FBDBA] mx-auto mb-2" />
                  <div className="text-2xl font-bold text-white">{trends.length}</div>
                  <div className="text-sm text-[#a7a8ae]">Artículos</div>
                </CardContent>
              </Card>
              
              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6 text-center">
                  <Users className="w-8 h-8 text-[#FFB703] mx-auto mb-2" />
                  <div className="text-2xl font-bold text-white">
                    {trends.reduce((sum, trend) => sum + trend.authors.length, 0)}
                  </div>
                  <div className="text-sm text-[#a7a8ae]">Autores</div>
                </CardContent>
              </Card>
              
              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6 text-center">
                  <Calendar className="w-8 h-8 text-green-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-white">
                    {new Set(trends.map(t => t.category)).size}
                  </div>
                  <div className="text-sm text-[#a7a8ae]">Categorías</div>
                </CardContent>
              </Card>
              
              <Card className="bg-[#1e202f] border-[#2f2f32]">
                <CardContent className="p-6 text-center">
                  <ExternalLink className="w-8 h-8 text-purple-500 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-white">arXiv</div>
                  <div className="text-sm text-[#a7a8ae]">Fuente</div>
                </CardContent>
              </Card>
            </div>

            {/* Refresh Button */}
            <div className="flex justify-center">
              <Button
                onClick={fetchTrends}
                disabled={loading}
                className="bg-[#4FBDBA] hover:bg-[#4FBDBA]/90 text-white pointer-events-auto"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                {loading ? 'Actualizando...' : 'Actualizar Tendencias'}
              </Button>
            </div>

            {/* Error Message */}
            {error && (
              <Card className="bg-red-900/20 border-red-500/50">
                <CardContent className="p-4">
                  <div className="text-red-400 text-center">
                    <p className="font-medium">Error al cargar tendencias desde arXiv</p>
                    <p className="text-sm">Mostrando datos locales. {error}</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Trends Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {loading ? (
                // Loading skeletons
                Array.from({ length: 6 }).map((_, index) => (
                  <Card key={index} className="bg-[#1e202f] border-[#2f2f32]">
                    <CardHeader>
                      <Skeleton className="h-6 w-3/4 bg-[#2f2f32]" />
                      <Skeleton className="h-4 w-full bg-[#2f2f32]" />
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <Skeleton className="h-4 w-full bg-[#2f2f32]" />
                        <Skeleton className="h-4 w-5/6 bg-[#2f2f32]" />
                        <div className="flex gap-2">
                          <Skeleton className="h-6 w-20 bg-[#2f2f32]" />
                          <Skeleton className="h-6 w-24 bg-[#2f2f32]" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : trends.length > 0 ? (
                // Actual trends
                trends.map((trend) => (
                  <Card key={trend.id} className="bg-[#1e202f] border-[#2f2f32] hover:border-[#4FBDBA]/50 transition-colors">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-white text-lg leading-tight mb-2 line-clamp-2">
                            {trend.title}
                          </CardTitle>
                          <CardDescription className="text-[#a7a8ae] line-clamp-3">
                            {trend.description}
                          </CardDescription>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => openTrend(trend.url)}
                          className="text-[#4FBDBA] hover:text-[#4FBDBA]/80 p-2 pointer-events-auto"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <p className="text-sm text-[#a7a8ae] line-clamp-4">
                          {trend.summary}
                        </p>
                        
                        <div className="flex flex-wrap items-center gap-2">
                          <Badge className={getCategoryColor(trend.category)}>
                            {trend.category}
                          </Badge>
                          
                          <div className="flex items-center gap-1 text-xs text-[#a7a8ae]">
                            <Calendar className="w-3 h-3" />
                            <span>{formatDate(trend.published)}</span>
                          </div>
                          
                          <div className="flex items-center gap-1 text-xs text-[#a7a8ae]">
                            <Users className="w-3 h-3" />
                            <span>{trend.authors.slice(0, 2).join(', ')}</span>
                            {trend.authors.length > 2 && <span>+{trend.authors.length - 2}</span>}
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between pt-2 border-t border-[#2f2f32]">
                          <span className="text-xs text-[#a7a8ae]">{trend.source}</span>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openTrend(trend.url)}
                            className="bg-[#2f2f32] border-[#45454a] text-white hover:bg-[#45454a] text-xs pointer-events-auto"
                          >
                            Leer Artículo
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                // No trends available
                <Card className="bg-[#1e202f] border-[#2f2f32] col-span-2">
                  <CardContent className="p-8 text-center">
                    <h3 className="text-white text-lg font-semibold mb-2">No hay tendencias disponibles</h3>
                    <p className="text-[#a7a8ae] mb-4">
                      No se pudieron cargar las tendencias de IA en este momento.
                    </p>
                    <Button
                      onClick={fetchTrends}
                      className="bg-[#4FBDBA] hover:bg-[#4FBDBA]/90 text-white pointer-events-auto"
                    >
                      Reintentar
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Info Footer */}
            <Card className="bg-[#1e202f] border-[#2f2f32]">
              <CardContent className="p-6 text-center">
                <h3 className="text-white text-lg font-semibold mb-2">Sobre arXiv</h3>
                <p className="text-[#a7a8ae] text-sm max-w-2xl mx-auto">
                  arXiv es un repositorio de preprints académicos accesibles gratuitamente en los campos de la física, 
                  las matemáticas, la informática, la biología cuantitativa, las finanzas cuantitativas, 
                  la estadística, la ingeniería eléctrica y la ciencia de sistemas, y la economía.
                </p>
                <div className="flex justify-center gap-4 mt-4">
                  <Button
                    variant="outline"
                    onClick={() => window.open('https://arxiv.org/', '_blank')}
                    className="bg-[#2f2f32] border-[#45454a] text-white hover:bg-[#45454a] pointer-events-auto"
                  >
                    Visitar arXiv
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => window.open('https://arxiv.org/list/cs.AI/recent', '_blank')}
                    className="bg-[#2f2f32] border-[#45454a] text-white hover:bg-[#45454a] pointer-events-auto"
                  >
                    Ver Últimos Papers
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}