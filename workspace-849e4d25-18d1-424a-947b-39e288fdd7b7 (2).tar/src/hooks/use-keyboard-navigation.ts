'use client';

import { useEffect, useRef, useCallback } from 'react';

export interface KeyboardNavigationOptions {
  enabled?: boolean;
  loop?: boolean;
  orientation?: 'horizontal' | 'vertical';
  selector?: string;
}

export function useKeyboardNavigation(
  items: string[] | HTMLElement[],
  options: KeyboardNavigationOptions = {}
) {
  const {
    enabled = true,
    loop = true,
    orientation = 'vertical',
    selector
  } = options;

  const activeIndexRef = useRef(-1);
  const containerRef = useRef<HTMLElement>(null);

  const getFocusableElements = useCallback(() => {
    if (!containerRef.current) return [];

    const focusableSelector = selector || [
      'button:not([disabled])',
      'input:not([disabled])',
      'select:not([disabled])',
      'textarea:not([disabled])',
      'a[href]',
      '[tabindex]:not([tabindex="-1"])',
      '[contenteditable="true"]'
    ].join(', ');

    return Array.from(containerRef.current.querySelectorAll(focusableSelector));
  }, [selector]);

  const focusElement = useCallback((index: number) => {
    const elements = getFocusableElements();
    if (elements[index]) {
      (elements[index] as HTMLElement).focus();
      activeIndexRef.current = index;
    }
  }, [getFocusableElements]);

  const moveFocus = useCallback((direction: 'next' | 'previous') => {
    const elements = getFocusableElements();
    if (elements.length === 0) return;

    const currentIndex = elements.findIndex(el => el === document.activeElement);
    let newIndex;

    if (currentIndex === -1) {
      newIndex = direction === 'next' ? 0 : elements.length - 1;
    } else {
      newIndex = direction === 'next' ? currentIndex + 1 : currentIndex - 1;
    }

    if (loop) {
      if (newIndex >= elements.length) newIndex = 0;
      if (newIndex < 0) newIndex = elements.length - 1;
    } else {
      newIndex = Math.max(0, Math.min(elements.length - 1, newIndex));
    }

    focusElement(newIndex);
  }, [getFocusableElements, focusElement, loop]);

  const handleKeyDown = useCallback((event: KeyboardEvent) => {
    if (!enabled) return;

    switch (event.key) {
      case 'Tab':
        // Let default tab behavior work
        break;
      case 'ArrowDown':
        if (orientation === 'vertical') {
          event.preventDefault();
          moveFocus('next');
        }
        break;
      case 'ArrowUp':
        if (orientation === 'vertical') {
          event.preventDefault();
          moveFocus('previous');
        }
        break;
      case 'ArrowRight':
        if (orientation === 'horizontal') {
          event.preventDefault();
          moveFocus('next');
        }
        break;
      case 'ArrowLeft':
        if (orientation === 'horizontal') {
          event.preventDefault();
          moveFocus('previous');
        }
        break;
      case 'Home':
        event.preventDefault();
        focusElement(0);
        break;
      case 'End':
        event.preventDefault();
        const elements = getFocusableElements();
        focusElement(elements.length - 1);
        break;
      case 'Enter':
      case ' ':
        if (document.activeElement instanceof HTMLElement) {
          const activeElement = document.activeElement;
          if (activeElement.tagName === 'BUTTON' || activeElement.tagName === 'A') {
            event.preventDefault();
            activeElement.click();
          }
        }
        break;
      case 'Escape':
        // Blur the active element
        if (document.activeElement instanceof HTMLElement) {
          document.activeElement.blur();
        }
        break;
    }
  }, [enabled, orientation, moveFocus, focusElement, getFocusableElements]);

  useEffect(() => {
    if (!enabled) return;

    const container = containerRef.current;
    if (!container) return;

    container.addEventListener('keydown', handleKeyDown);
    return () => {
      container.removeEventListener('keydown', handleKeyDown);
    };
  }, [enabled, handleKeyDown]);

  return {
    containerRef,
    focusElement,
    moveFocus,
    getFocusableElements
  };
}

// Hook for managing focus trap within a container
export function useFocusTrap(enabled: boolean = true) {
  const containerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (!enabled) return;

    const container = containerRef.current;
    if (!container) return;

    const focusableElements = container.querySelectorAll(
      'button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href], [tabindex]:not([tabindex="-1"]), [contenteditable="true"]'
    );

    if (focusableElements.length === 0) return;

    const firstElement = focusableElements[0] as HTMLElement;
    const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'Tab') return;

      if (event.shiftKey) {
        if (document.activeElement === firstElement) {
          event.preventDefault();
          lastElement.focus();
        }
      } else {
        if (document.activeElement === lastElement) {
          event.preventDefault();
          firstElement.focus();
        }
      }
    };

    container.addEventListener('keydown', handleKeyDown);
    
    // Focus the first element when trap is enabled
    if (enabled && focusableElements.length > 0) {
      firstElement.focus();
    }

    return () => {
      container.removeEventListener('keydown', handleKeyDown);
    };
  }, [enabled]);

  return containerRef;
}

// Hook for managing ARIA announcements
export function useAnnouncements() {
  const announceRef = useRef<HTMLDivElement>(null);

  const announce = useCallback((message: string, priority: 'polite' | 'assertive' = 'polite') => {
    if (!announceRef.current) return;

    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', priority);
    announcement.setAttribute('aria-atomic', 'true');
    announcement.className = 'sr-only';
    announcement.textContent = message;

    announceRef.current.appendChild(announcement);

    // Remove after announcement
    setTimeout(() => {
      announcement.remove();
    }, 1000);
  }, []);

  const setupAnnouncer = useCallback(() => {
    if (!announceRef.current) {
      const announcer = document.createElement('div');
      announcer.setAttribute('aria-live', 'polite');
      announcer.setAttribute('aria-atomic', 'true');
      announcer.className = 'sr-only';
      announcer.style.position = 'absolute';
      announcer.style.left = '-10000px';
      announcer.style.width = '1px';
      announcer.style.height = '1px';
      announcer.style.overflow = 'hidden';
      document.body.appendChild(announcer);
      announceRef.current = announcer;
    }
  }, []);

  useEffect(() => {
    setupAnnouncer();
    return () => {
      if (announceRef.current) {
        announceRef.current.remove();
      }
    };
  }, [setupAnnouncer]);

  return { announce, setupAnnouncer };
}