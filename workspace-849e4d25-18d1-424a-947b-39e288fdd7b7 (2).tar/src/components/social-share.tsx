"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { SocialShareManager, SocialShareData } from "@/lib/social";
import { useToast } from "@/hooks/use-toast";
import { 
  Twitter, 
  Linkedin, 
  Facebook, 
  MessageCircle, 
  Send, 
  Mail, 
  Link2,
  Share2 
} from "lucide-react";

interface SocialShareProps {
  data: SocialShareData;
  className?: string;
  showLabels?: boolean;
  variant?: "default" | "compact" | "dropdown";
}

export function SocialShare({ 
  data, 
  className = "", 
  showLabels = true, 
  variant = "default" 
}: SocialShareProps) {
  const { toast } = useToast();
  const [isCopied, setIsCopied] = useState(false);

  const handleShare = async (platform: string) => {
    try {
      switch (platform) {
        case 'twitter':
          SocialShareManager.shareOnTwitter(data);
          break;
        case 'linkedin':
          SocialShareManager.shareOnLinkedIn(data);
          break;
        case 'facebook':
          SocialShareManager.shareOnFacebook(data);
          break;
        case 'whatsapp':
          SocialShareManager.shareOnWhatsApp(data);
          break;
        case 'telegram':
          SocialShareManager.shareOnTelegram(data);
          break;
        case 'email':
          SocialShareManager.shareByEmail(data);
          break;
        case 'copy':
          await SocialShareManager.copyToClipboard(data);
          setIsCopied(true);
          toast({
            title: "Enlace copiado",
            description: "El enlace ha sido copiado al portapapeles.",
          });
          setTimeout(() => setIsCopied(false), 2000);
          break;
        default:
          break;
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo compartir. Por favor intenta nuevamente.",
        variant: "destructive",
      });
    }
  };

  const socialPlatforms = [
    { id: 'twitter', icon: Twitter, label: 'Twitter', color: 'hover:text-blue-400' },
    { id: 'linkedin', icon: Linkedin, label: 'LinkedIn', color: 'hover:text-blue-600' },
    { id: 'facebook', icon: Facebook, label: 'Facebook', color: 'hover:text-blue-500' },
    { id: 'whatsapp', icon: MessageCircle, label: 'WhatsApp', color: 'hover:text-green-500' },
    { id: 'telegram', icon: Send, label: 'Telegram', color: 'hover:text-blue-400' },
    { id: 'email', icon: Mail, label: 'Email', color: 'hover:text-gray-400' },
    { id: 'copy', icon: Link2, label: 'Copiar', color: 'hover:text-gray-300' },
  ];

  if (variant === 'compact') {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => handleShare('twitter')}
          className="text-gray-400 hover:text-blue-400"
          aria-label="Compartir en Twitter"
        >
          <Twitter className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => handleShare('linkedin')}
          className="text-gray-400 hover:text-blue-600"
          aria-label="Compartir en LinkedIn"
        >
          <Linkedin className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => handleShare('facebook')}
          className="text-gray-400 hover:text-blue-500"
          aria-label="Compartir en Facebook"
        >
          <Facebook className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => handleShare('copy')}
          className="text-gray-400 hover:text-gray-300"
          aria-label="Copiar enlace"
        >
          {isCopied ? <Link2 className="w-4 h-4 text-green-500" /> : <Link2 className="w-4 h-4" />}
        </Button>
      </div>
    );
  }

  if (variant === 'dropdown') {
    return (
      <Card className={`${className}`}>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Share2 className="w-4 h-4 text-[#4FBDBA]" />
            <span className="text-white font-medium">Compartir</span>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {socialPlatforms.map((platform) => (
              <Button
                key={platform.id}
                variant="ghost"
                size="sm"
                onClick={() => handleShare(platform.id)}
                className={`flex flex-col items-center gap-1 h-auto p-2 ${platform.color}`}
                aria-label={`Compartir en ${platform.label}`}
              >
                <platform.icon className="w-4 h-4" />
                <span className="text-xs">{platform.label}</span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`${className}`}>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <Share2 className="w-4 h-4 text-[#4FBDBA]" />
          <span className="text-white font-medium">Compartir en redes sociales</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {socialPlatforms.map((platform) => (
            <Button
              key={platform.id}
              variant="outline"
              onClick={() => handleShare(platform.id)}
              className={`bg-[#2f2f32] border-[#45454a] text-white hover:bg-[#45454a] ${platform.color}`}
              aria-label={`Compartir en ${platform.label}`}
            >
              <platform.icon className="w-4 h-4 mr-2" />
              {showLabels && platform.label}
              {platform.id === 'copy' && isCopied && (
                <span className="text-green-500 text-xs ml-1">¡Copiado!</span>
              )}
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}