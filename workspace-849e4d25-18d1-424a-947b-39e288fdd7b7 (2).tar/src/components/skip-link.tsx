"use client";

import { usePathname } from 'next/navigation';

interface SkipLinkProps {
  href: string;
  children: React.ReactNode;
  className?: string;
}

export function SkipLink({ href, children, className = "" }: SkipLinkProps) {
  const pathname = usePathname();

  return (
    <a
      href={href}
      className={`skip-link ${className}`}
      onClick={(e) => {
        e.preventDefault();
        const target = document.querySelector(href);
        if (target) {
          target.scrollIntoView({ behavior: 'smooth' });
          (target as HTMLElement).focus();
        }
      }}
    >
      {children}
    </a>
  );
}

export function MainSkipLinks() {
  return (
    <>
      <SkipLink href="#main-content">
        Saltar al contenido principal
      </SkipLink>
      <SkipLink href="#navigation">
        Saltar a la navegación
      </SkipLink>
      <SkipLink href="#search">
        Saltar a la búsqueda
      </SkipLink>
    </>
  );
}