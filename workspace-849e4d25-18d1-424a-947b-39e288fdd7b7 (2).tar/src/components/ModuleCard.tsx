"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Clock, Users, Star, ArrowLeft, Play, Award } from "lucide-react";

interface Module {
  id: string;
  title: string;
  description: string;
  difficulty: "Principiante" | "Intermedio" | "Avanzado";
  duration: string;
  level: string;
  weeks: number;
  summary: string;
  cover?: string;
  progress?: number;
  completed?: boolean;
}

interface ModuleCardProps {
  module: Module;
  onClick?: () => void;
}

export function ModuleCard({ module, onClick }: ModuleCardProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Principiante": return "bg-green-100 text-green-800";
      case "Intermedio": return "bg-yellow-100 text-yellow-800";
      case "Avanzado": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getDifficultyIcon = (difficulty: string) => {
    switch (difficulty) {
      case "Principiante": return "🌱";
      case "Intermedio": return "🌿";
      case "Avanzado": return "🌳";
      default: return "📚";
    }
  };

  return (
    <Card 
      className="bg-[#1e202f] border-[#2f2f32] hover:border-[#4FBDBA]/50 transition-all duration-200 hover:shadow-lg cursor-pointer group"
      onClick={onClick}
    >
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">{getDifficultyIcon(module.difficulty)}</span>
              <Badge className={getDifficultyColor(module.difficulty)}>
                {module.difficulty}
              </Badge>
            </div>
            <CardTitle className="text-white text-lg leading-tight mb-2 group-hover:text-[#4FBDBA] transition-colors">
              {module.title}
            </CardTitle>
            <CardDescription className="text-[#a7a8ae] line-clamp-2">
              {module.description}
            </CardDescription>
          </div>
          {module.completed && (
            <div className="flex-shrink-0">
              <Award className="w-6 h-6 text-green-500" />
            </div>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Module Stats */}
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-lg font-semibold text-white">{module.weeks}</div>
            <div className="text-xs text-[#a7a8ae]">Semanas</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-white">{module.level}</div>
            <div className="text-xs text-[#a7a8ae]">Nivel</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-white">
              {module.progress || 0}%
            </div>
            <div className="text-xs text-[#a7a8ae]">Progreso</div>
          </div>
        </div>

        {/* Progress Bar */}
        {module.progress !== undefined && module.progress > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#a7a8ae]">Progreso</span>
              <span className="text-white font-medium">{module.progress}%</span>
            </div>
            <Progress value={module.progress} className="h-2" />
          </div>
        )}

        {/* Action Button */}
        <Button 
          className={`w-full ${module.completed ? 'bg-green-600 hover:bg-green-700' : 'bg-[#4FBDBA] hover:bg-[#4FBDBA]/90'} text-white pointer-events-auto`}
          onClick={(e) => {
            e.stopPropagation();
            onClick?.();
          }}
        >
          {module.completed ? (
            <>
              <Award className="w-4 h-4 mr-2" />
              Revisar
            </>
          ) : (
            <>
              <Play className="w-4 h-4 mr-2" />
              {module.progress ? 'Continuar' : 'Comenzar'}
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}