"use client";

import { useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { NavAuthButtons } from "./NavAuthButtons";

export function NavBar() {
  const router = useRouter();

  return (
    <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[#2f2f32] px-4 sm:px-6 lg:px-10 py-3">
      <div className="flex items-center gap-4 text-white">
        <div className="size-4">
          <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M24 45.8096C19.6865 45.8096 15.4698 44.5305 11.8832 42.134C8.29667 39.7376 5.50128 36.3314 3.85056 32.3462C2.19985 28.361 1.76794 23.9758 2.60947 19.7452C3.451 15.5145 5.52816 11.6284 8.57829 8.5783C11.6284 5.52817 15.5145 3.45101 19.7452 2.60948C23.9758 1.76795 28.361 2.19986 32.3462 3.85057C36.3314 5.50129 39.7376 8.29668 42.134 11.8833C44.5305 15.4698 45.8096 19.6865 45.8096 24L24 24L24 45.8096Z" fill="currentColor"></path>
          </svg>
        </div>
        <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">AI Pathfinders 2025</h2>
      </div>
      <div className="flex flex-1 justify-end gap-4 sm:gap-8">
        <div className="flex items-center gap-4 sm:gap-9">
          <button 
            onClick={() => router.push('/')}
            className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors cursor-pointer pointer-events-auto"
          >
            Inicio
          </button>
          <button 
            onClick={() => router.push('/modules')}
            className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors cursor-pointer pointer-events-auto"
            data-testid="nav-modules"
          >
            Módulos
          </button>
          <button 
            onClick={() => router.push('/trends')}
            className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors cursor-pointer pointer-events-auto"
            data-testid="nav-trends"
          >
            Tendencias
          </button>
          <a className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors" href="#">Comunidad</a>
          <a className="text-white text-sm font-medium leading-normal hover:text-[#4FBDBA] transition-colors" href="#">Recursos</a>
        </div>
        <NavAuthButtons />
      </div>
    </header>
  );
}