"use client";

import { useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { BookOpen, Users, Award, TrendingUp } from "lucide-react";

export function HeroCTA() {
  const router = useRouter();

  return (
    <section className="relative py-16 sm:py-24 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#4FBDBA]/10 via-transparent to-[#4FBDBA]/5 pointer-events-none"></div>
      
      <div className="relative max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 break-words">
            Transforma tu Futuro con
            <span className="text-[#4FBDBA] block sm:inline"> Inteligencia Artificial</span>
          </h1>
          
          <p className="text-xl sm:text-2xl text-[#a7a8ae] mb-8 max-w-3xl mx-auto leading-relaxed break-words">
            Aprende de los expertos en IA con nuestro programa educativo completo. 
            Desde fundamentos hasta técnicas avanzadas, todo en un solo lugar.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Button 
              onClick={() => router.push('/modules')}
              size="lg"
              className="bg-[#4FBDBA] hover:bg-[#4FBDBA]/90 text-white text-lg px-8 py-4 rounded-lg font-semibold pointer-events-auto relative z-10"
              data-testid="cta-explorar"
            >
              <BookOpen className="w-5 h-5 mr-2" />
              Explorar Módulos
            </Button>
            <Button 
              variant="outline"
              size="lg"
              className="bg-transparent border-[#4FBDBA] text-[#4FBDBA] hover:bg-[#4FBDBA]/10 text-lg px-8 py-4 rounded-lg font-semibold pointer-events-auto"
            >
              Ver Plan de Estudios
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <BookOpen className="w-8 h-8 text-[#4FBDBA]" />
              </div>
              <div className="text-3xl font-bold text-white mb-1">8+</div>
              <div className="text-[#a7a8ae]">Módulos Expertos</div>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Users className="w-8 h-8 text-[#FFB703]" />
              </div>
              <div className="text-3xl font-bold text-white mb-1">5000+</div>
              <div className="text-[#a7a8ae]">Estudiantes</div>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Award className="w-8 h-8 text-purple-500" />
              </div>
              <div className="text-3xl font-bold text-white mb-1">95%</div>
              <div className="text-[#a7a8ae]">Tasa de Éxito</div>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-10 left-10 w-20 h-20 bg-[#4FBDBA]/20 rounded-full blur-xl pointer-events-none"></div>
      <div className="absolute bottom-10 right-10 w-32 h-32 bg-purple-500/20 rounded-full blur-xl pointer-events-none"></div>
    </section>
  );
}