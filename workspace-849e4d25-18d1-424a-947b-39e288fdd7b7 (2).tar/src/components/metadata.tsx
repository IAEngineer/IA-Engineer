"use client";

import Head from 'next/head';
import { SocialShareData } from '@/lib/social';

interface MetadataProps {
  title: string;
  description: string;
  url?: string;
  imageUrl?: string;
  type?: 'website' | 'article';
  siteName?: string;
  locale?: string;
  noIndex?: boolean;
  keywords?: string[];
  author?: string;
  publishedTime?: string;
  modifiedTime?: string;
  section?: string;
  tags?: string[];
}

export function Metadata({
  title,
  description,
  url,
  imageUrl,
  type = 'website',
  siteName = 'AI Pathfinders 2025',
  locale = 'es_ES',
  noIndex = false,
  keywords = [],
  author,
  publishedTime,
  modifiedTime,
  section,
  tags
}: MetadataProps) {
  const fullTitle = `${title} | ${siteName}`;
  const currentUrl = url || (typeof window !== 'undefined' ? window.location.href : '');
  const currentImageUrl = imageUrl || 'https://ai-pathfinders-2025.com/og-default.jpg';

  const structuredData = {
    "@context": "https://schema.org",
    "@type": type === 'article' ? 'Article' : 'WebSite',
    "name": title,
    "headline": title,
    "description": description,
    "url": currentUrl,
    "image": currentImageUrl,
    "author": author ? {
      "@type": "Person",
      "name": author
    } : undefined,
    "publisher": {
      "@type": "Organization",
      "name": siteName,
      "logo": {
        "@type": "ImageObject",
        "url": "https://ai-pathfinders-2025.com/logo.png"
      }
    },
    ...(type === 'article' && {
      "datePublished": publishedTime,
      "dateModified": modifiedTime || publishedTime,
      "articleSection": section,
      "keywords": tags ? tags.join(', ') : keywords.join(', ')
    }),
    "potentialAction": {
      "@type": "ReadAction",
      "target": currentUrl
    }
  };

  return (
    <Head>
      {/* Basic Meta Tags */}
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords.join(', ')} />
      <meta name="author" content={author || siteName} />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta name="robots" content={noIndex ? 'noindex, nofollow' : 'index, follow'} />
      <meta name="googlebot" content={noIndex ? 'noindex, nofollow' : 'index, follow'} />
      
      {/* Open Graph Tags */}
      <meta property="og:type" content={type} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={currentUrl} />
      <meta property="og:image" content={currentImageUrl} />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:image:alt" content={title} />
      <meta property="og:site_name" content={siteName} />
      <meta property="og:locale" content={locale} />
      
      {/* Twitter Card Tags */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content="@AIPathfinders" />
      <meta name="twitter:creator" content={author ? `@${author}` : '@AIPathfinders'} />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={currentImageUrl} />
      <meta name="twitter:image:alt" content={title} />
      
      {/* Additional Meta Tags */}
      <meta name="theme-color" content="#141415" />
      <meta name="msapplication-TileColor" content="#141415" />
      <meta name="msapplication-config" content="/browserconfig.xml" />
      
      {/* Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(structuredData)
        }}
      />
      
      {/* Favicon */}
      <link rel="icon" href="/favicon.ico" />
      <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
      <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
      <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
      <link rel="manifest" href="/site.webmanifest" />
      
      {/* Canonical URL */}
      <link rel="canonical" href={currentUrl} />
      
      {/* Language and Region */}
      <meta httpEquiv="Content-Language" content="es" />
      <meta name="geo.region" content="ES" />
      
      {/* Security Headers */}
      <meta httpEquiv="X-Content-Type-Options" content="nosniff" />
      <meta httpEquiv="X-Frame-Options" content="DENY" />
      <meta httpEquiv="X-XSS-Protection" content="1; mode=block" />
      
      {/* Article specific tags */}
      {type === 'article' && publishedTime && (
        <meta property="article:published_time" content={publishedTime} />
      )}
      {type === 'article' && modifiedTime && (
        <meta property="article:modified_time" content={modifiedTime} />
      )}
      {type === 'article' && section && (
        <meta property="article:section" content={section} />
      )}
      {type === 'article' && tags && tags.map((tag, index) => (
        <meta key={index} property="article:tag" content={tag} />
      ))}
    </Head>
  );
}

// Hook to generate social share data from current page
export function useSocialShareData(customData?: Partial<SocialShareData>): SocialShareData {
  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';
  const currentTitle = typeof document !== 'undefined' ? document.title : '';
  
  const defaultData: SocialShareData = {
    title: currentTitle.replace(' | AI Pathfinders 2025', ''),
    description: 'Aprende inteligencia artificial con AI Pathfinders 2025 - La plataforma educativa más completa de IA.',
    url: currentUrl,
    hashtags: ['AI', 'MachineLearning', 'Educacion', 'Tecnologia'],
    via: 'AIPathfinders'
  };

  return { ...defaultData, ...customData };
}