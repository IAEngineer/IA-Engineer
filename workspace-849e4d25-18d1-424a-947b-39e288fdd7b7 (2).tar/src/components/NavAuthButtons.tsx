"use client";

import { useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Bell } from "lucide-react";

export function NavAuthButtons() {
  const router = useRouter();

  return (
    <>
      <button className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 bg-[#2f2f32] text-white gap-2 text-sm font-bold leading-normal tracking-[0.015em] min-w-0 px-2.5">
        <Bell className="w-5 h-5" />
      </button>
      <div className="flex gap-2">
        <Button 
          variant="ghost"
          onClick={() => router.push('/auth/login')}
          className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#1e202f] text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-[#2f2f32] pointer-events-auto"
          data-testid="nav-login"
        >
          Iniciar Sesión
        </Button>
        <Button 
          onClick={() => router.push('/auth/register')}
          className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-[#4FBDBA] text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-[#4FBDBA]/90 pointer-events-auto"
          data-testid="nav-register"
        >
          Registrarse
        </Button>
      </div>
    </>
  );
}