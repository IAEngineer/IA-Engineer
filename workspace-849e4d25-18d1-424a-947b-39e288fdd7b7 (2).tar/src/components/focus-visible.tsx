"use client";

import { useEffect } from 'react';

// This component ensures focus visible styles work properly
export function FocusVisibleStyles() {
  useEffect(() => {
    // Add focus visible styles if they don't exist
    if (!document.getElementById('focus-visible-styles')) {
      const style = document.createElement('style');
      style.id = 'focus-visible-styles';
      style.textContent = `
        /* Focus visible styles for better keyboard navigation */
        .focus-visible:focus {
          outline: 2px solid #4FBDBA !important;
          outline-offset: 2px !important;
        }
        
        /* Remove outline for mouse users */
        .js-focus-visible :focus:not(.focus-visible) {
          outline: none !important;
        }
        
        /* High contrast focus indicators */
        button:focus-visible,
        input:focus-visible,
        select:focus-visible,
        textarea:focus-visible,
        a:focus-visible {
          box-shadow: 0 0 0 3px rgba(79, 189, 186, 0.3) !important;
        outline: 2px solid #4FBDBA !important;
          outline-offset: 2px !important;
        }
        
        /* Skip link styles */
        .skip-link {
          position: absolute;
          top: -40px;
          left: 0;
          background: #4FBDBA;
          color: white;
          padding: 8px;
          text-decoration: none;
          z-index: 100;
        }
        
        .skip-link:focus {
          top: 0;
        }
        
        /* Screen reader only text */
        .sr-only {
          position: absolute;
          width: 1px;
          height: 1px;
          padding: 0;
          margin: -1px;
          overflow: hidden;
          clip: rect(0, 0, 0, 0);
          white-space: nowrap;
          border: 0;
        }
        
        /* Visually hidden but accessible */
        .visually-hidden {
          position: absolute;
          width: 1px;
          height: 1px;
          padding: 0;
          margin: -1px;
          overflow: hidden;
          clip: rect(0, 0, 0, 0);
          white-space: nowrap;
          border: 0;
        }
        
        /* Focus indicators for interactive elements */
        .interactive-element:focus {
          outline: 2px solid #4FBDBA;
          outline-offset: 2px;
        }
        
        /* High contrast mode support */
        @media (prefers-contrast: high) {
          .interactive-element:focus {
            outline: 3px solid white;
            outline-offset: 3px;
          }
        }
        
        /* Reduced motion support */
        @media (prefers-reduced-motion: reduce) {
          * {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
          }
        }
      `;
      document.head.appendChild(style);
    }

    // Add focus-visible polyfill if needed
    if (!('focusVisible' in document.documentElement.style)) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/focus-visible@5.2.0/dist/focus-visible.js';
      script.integrity = 'sha384-xRaazBqfPHjm8I3Ks1dDl73CFLb4z3QK5wQqZj/af1WlCrvsKjBzUsvYQHJ5Sm4oKz';
      script.crossOrigin = 'anonymous';
      document.head.appendChild(script);
    }
  }, []);

  return null;
}